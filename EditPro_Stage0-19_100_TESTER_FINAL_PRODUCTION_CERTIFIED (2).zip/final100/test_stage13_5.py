from stage13_5_editing import Stage13_5EditingEngine, EDIT_FEATURES

ENGINE=Stage13_5EditingEngine()

# Exactly 30 focused test cases for Stage 13.5.
def test_01_smart_trim(): assert 'smart_trim' in ENGINE.plan('remove boring parts and make it tight',10).features
def test_02_reframe(): assert 'auto_reframe' in ENGINE.plan('make a 9:16 reel',10,target_format='reel').features
def test_03_tracking(): assert 'subject_tracking' in ENGINE.plan('track the subject',10).features
def test_04_color_correct(): assert 'ai_color_correction' in ENGINE.plan('fix exposure and white balance',10).features
def test_05_color_grade(): assert 'ai_color_grading' in ENGINE.plan('cinematic color grade',10).features
def test_06_object_remove(): assert 'object_removal' in ENGINE.plan('remove the unwanted person',10).features
def test_07_background(): assert 'background_replacement' in ENGINE.plan('replace background',10).features
def test_08_speed(): assert 'speed_ramp' in ENGINE.plan('add speed ramp',10).features
def test_09_keyframes(): assert 'keyframes' in ENGINE.plan('animate scale with keyframes',10).features
def test_10_transitions(): assert 'advanced_transitions' in ENGINE.plan('add smooth transitions',10).features
def test_11_noise(): assert 'noise_removal' in ENGINE.plan('clean audio noise',10).features
def test_12_voice(): assert 'voice_enhancement' in ENGINE.plan('enhance voice',10).features
def test_13_separation(): assert 'dialogue_music_separation' in ENGINE.plan('separate dialogue and music',10).features
def test_14_ducking(): assert 'auto_ducking' in ENGINE.plan('duck music under voice',10).features
def test_15_beat(): assert 'beat_detection' in ENGINE.plan('sync cuts to beats',10).features
def test_16_captions(): assert 'auto_captions' in ENGINE.plan('add subtitles',10).features
def test_17_word_timing(): assert 'word_timing' in ENGINE.plan('word by word captions',10).features
def test_18_speakers(): assert 'speaker_detection' in ENGINE.plan('identify speakers',10).features
def test_19_caption_place(): assert 'caption_placement' in ENGINE.plan('move captions to safe area',10).features
def test_20_text_track(): assert 'text_tracking' in ENGINE.plan('make text follow the person',10).features
def test_21_platform(): assert 'platform_export' in ENGINE.plan('make a YouTube short',10).features
def test_22_hook(): assert 'hook_detection' in ENGINE.plan('find the strongest hook',10).features
def test_23_long_shorts(): assert 'long_to_shorts' in ENGINE.plan('turn this long video into shorts',120).features
def test_24_thumbnail(): assert 'thumbnail_selection' in ENGINE.plan('pick the best thumbnail',10).features
def test_25_nl_multi_edit():
    p=ENGINE.plan('cut boring parts, add captions, color grade, sync to beat and make a reel',20)
    assert {'smart_trim','auto_captions','ai_color_grading','beat_detection','platform_export','natural_language_editing'} <= set(p.features)
def test_26_non_destructive():
    p=ENGINE.plan('edit this video',20); assert p.contracts['non_destructive'] and p.contracts['original_media_preserved']
def test_27_validation():
    p=ENGINE.plan('edit this video',20); p.validate(); assert ENGINE.inspect(p)['ok']
def test_28_deterministic_digest():
    a=ENGINE.plan('cinematic reel with captions',20); b=ENGINE.plan('cinematic reel with captions',20); assert a.digest==b.digest

def test_29_all_groups_reachable():
    p=ENGINE.plan('remove boring parts, make reel, track subject, clean voice, add captions, thumbnail',60)
    assert set(p.contracts['supported_groups']) >= {'timeline','visual','audio','text','creator','control'}
def test_30_feature_catalog_integrity():
    p=ENGINE.plan('full professional edit with reel captions audio tracking color thumbnail',60)
    assert set(EDIT_FEATURES) >= {'smart_trim','auto_reframe','subject_tracking','ai_color_grading','noise_removal','auto_captions','platform_export','natural_language_editing','quality_gate'}
    assert p.contracts['stage14_boundary']=='preserved'
