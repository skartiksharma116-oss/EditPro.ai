import os, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from stage8_compositor import Stage8Pipeline
from stage8_render import Stage8Renderer

def main():
    p=Stage8Pipeline(); r=Stage8Renderer()
    s=p.plan('3d car with fog dust glow and text',width=320,height=180,fps=10,duration_frames=12)
    with tempfile.TemporaryDirectory() as td:
        png=r.render_png(s,0,Path(td)/'frame.png'); assert png.exists() and png.stat().st_size>100
        mp4=r.render_preview_video(s,Path(td)/'preview.mp4'); assert mp4.exists() and mp4.stat().st_size>1000
    print('Stage 8 raster + ffmpeg preview render: PASS')
if __name__=='__main__': main()
