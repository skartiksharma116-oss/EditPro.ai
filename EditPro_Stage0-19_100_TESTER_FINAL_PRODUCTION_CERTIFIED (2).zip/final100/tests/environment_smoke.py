import os,sys,subprocess,tempfile,json,urllib.request,urllib.parse,threading
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ai.speech import SpeechWorker
from ai.cloud import CloudWorker
from ai.vision import inspect_media
ROOT=Path(__file__).resolve().parents[1]; F=ROOT/'fixtures'; wav=F/'real_speech.wav'; mp4=F/'real_speech.mp4'
if not wav.exists(): subprocess.run(['espeak','-w',str(wav),'EditPro artificial speech integration test. This sentence contains an important moment.'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
if not mp4.exists(): subprocess.run(['ffmpeg','-y','-f','lavfi','-i','color=size=640x360:rate=30:color=black','-i',str(wav),'-t','4','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(mp4)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
s=SpeechWorker(); d,r=s.analyze_audio(mp4); assert d>0 and r>0.1
print('real generated speech audio analysis: PASS')

# Cloud circuit breaker: repeated real HTTP failures must fail closed, never hang.
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
class Bad(BaseHTTPRequestHandler):
 def do_POST(self): self.send_response(503); self.end_headers()
 def log_message(self,*a): pass
srv=ThreadingHTTPServer(('127.0.0.1',0),Bad); threading.Thread(target=srv.serve_forever,daemon=True).start()
c=CloudWorker(endpoint=f'http://127.0.0.1:{srv.server_address[1]}',timeout=.2,retries=1,breaker_limit=3)
for _ in range(10): assert not c.run({'x':1}).ok
assert c.run({'x':1}).error=='circuit_open'; srv.shutdown()
print('cloud failure + circuit-breaker: PASS')

# Human evaluation surface smoke test.
