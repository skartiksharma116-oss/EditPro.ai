from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import random
from stage9_cinematography import Stage9Pipeline, CapabilityRegistry, ShotCandidate, DirectorConfig, ShotPlanner

p=Stage9Pipeline(); checks=0
commands=[
    'cinematic person video', 'emotional dialogue interview', 'fast viral car reel',
    'luxury product cinematic', 'epic landscape trailer', 'calm documentary',
    'romantic face story', 'dramatic action character', 'beat synced energetic reel'
]
for i in range(20000):
    cmd=commands[i%len(commands)]
    timeline={
        'beats':[{'start':0,'end':1.2,'kind':'hook','intensity':.9},{'start':1.2,'end':2.7,'kind':'story','intensity':.55}],
        'music_beats':[.5,1.0,1.5,2.0],
    }
    visual=[{'label':'face','confidence':.92,'x':.25+.5*(i%5)/4,'y':.45,'w':.25,'h':.35,'importance':.95,'motion':.2}]
    plan=p.plan(cmd,visual=visual,speech={'transcript':[{'text':'hello'}], 'segments':[{'start':0,'end':1.0}]},media={'duration':3,'fps':30},fps=30,duration_frames=90,target_format='reel',timeline=timeline)
    assert plan.validate() is None and plan.shots[0].start==0 and plan.shots[-1].end==90
    assert p.inspect(plan)['coverage_ratio']==1.0
    checks+=1

for i in range(10000):
    rng=random.Random(i)
    fmt=rng.choice(['square','portrait','landscape','reel','story','youtube'])
    duration=rng.randint(1,900)
    visual=[{'label':rng.choice(['person','car','product','landscape']), 'confidence':rng.random(), 'x':rng.random(), 'y':rng.random(), 'w':rng.random(), 'h':rng.random(), 'importance':rng.random(), 'motion':rng.random()}]
    plan=p.plan(rng.choice(commands),visual=visual,media={'duration':max(.01,duration/24)},fps=24,duration_frames=duration,target_format=fmt)
    assert plan.shots[-1].end==duration
    checks+=1

# Hostile input validation.
for bad in ['', None, '   ']:
    try: p.plan(bad)
    except ValueError: checks+=1
    else: raise AssertionError('empty command accepted')

# Deterministic digest storm.
for _ in range(50000):
    a=p.plan('cinematic person video',visual=[{'label':'person','confidence':.9,'x':.4,'y':.5}],media={'duration':3},fps=30,duration_frames=90,target_format='landscape')
    b=p.plan('cinematic person video',visual=[{'label':'person','confidence':.9,'x':.4,'y':.5}],media={'duration':3},fps=30,duration_frames=90,target_format='landscape')
    assert a.digest==b.digest
    checks+=1

# Vocabulary validation.
try: ShotCandidate('x',0,1,scale='INVALID').validate(); raise AssertionError
except ValueError: checks+=1

print(f'STAGE9_ULTIMATE_PASS checks={checks}')
print('CAPABILITIES', CapabilityRegistry.available())
