from stage15_generation_execution import Stage15Executor


def test_stage15_capability_surface_is_deep():
    e=Stage15Executor(); a=e.capability_audit()
    assert a["capabilities"] >= 90
    for family in ("runtime","video_generation","image_generation","character","motion","scene","vfx","repair","temporal","quality"):
        assert family in a["families"]


def test_stage15_has_complete_generation_surface():
    e=Stage15Executor()
    r=e.plan("make a legendary cinematic reel with generated shots, character animation, lip sync, VFX, remove object and extend scene", {"duration":30,"width":1920,"height":1080,"fps":30})
    caps=set(r["requested_capabilities"])
    assert {"generation.video.shot","generation.video.text_to_video","character.motion_transfer","character.lipsync","vfx.environment","repair.object_remove","temporal.consistency","quality.final_acceptance"}.issubset(caps)
    assert r["ok"]


def test_stage15_dependency_order_is_deterministic():
    e=Stage15Executor(); r=e.plan("animate cinematic character with lip sync", {"duration":10})
    order=r["execution_order"]
    assert order.index("character.pose") < order.index("character.motion_transfer")
    assert order.index("character.expression") < order.index("character.lipsync")
    assert order.index("temporal.consistency") < order.index("temporal.flicker_repair")
    assert order.index("quality.generation_gate") < order.index("quality.final_acceptance")


def test_external_generation_never_falsely_executes():
    e=Stage15Executor(); r=e.plan("generate a cinematic video shot", {"duration":5})
    j=next(x for x in r["jobs"] if x["capability"]=="generation.video.shot")
    assert j["status"]=="contract" and j["artifact"]["materialized"] is False


def test_explicit_runtime_can_execute_boundary():
    e=Stage15Executor(); r=e.plan("generate a cinematic video shot", {"duration":5}, installed=("stage15:generation.video.shot",))
    j=next(x for x in r["jobs"] if x["capability"]=="generation.video.shot")
    assert j["status"]=="executed" and j["mode"]=="executed"


def test_local_fallback_is_not_fake_generation():
    e=Stage15Executor(); r=e.plan("cinematic VFX with temporal consistency", {"duration":8})
    j=next(x for x in r["jobs"] if x["capability"]=="vfx.environment")
    assert j["mode"]=="local" and j["artifact"]["materialized"] is False


def test_failure_repair():
    e=Stage15Executor(); r=e.plan("cinematic VFX", {"duration":8}, failure_inject=("vfx.environment",))
    j=next(x for x in r["jobs"] if x["capability"]=="vfx.environment")
    assert j["repaired"] is True and j["attempts"]==2


def test_replay_and_stress():
    e=Stage15Executor(); r=e.plan("premium cinematic reel with character animation", {"duration":12})
    assert e.replay(r)["match"]
    s=e.stress("premium cinematic reel", {"duration":5}, iterations=1000)
    assert s["failed"]==0 and s["deterministic"]


def test_matrix_and_edge_cases():
    e=Stage15Executor()
    m=e.audit_matrix([
        {"name":"video","command":"generate cinematic reel","media":{"duration":5}},
        {"name":"image","command":"generate image variation and relight","media":{}},
        {"name":"character","command":"animate character with lip sync","media":{"duration":4}},
        {"name":"repair","command":"remove object and replace background","media":{"duration":4}},
        {"name":"reference","command":"generate image using reference style","media":{}},
        {"name":"upscale","command":"upscale video to 4k","media":{"duration":4}},
    ])
    assert m["failed"]==0
    assert e.plan("", {})["ok"]
    assert e.plan("generate video", {"width":1000000,"height":100000})["ok"] is False


def test_stage15_malformed_inputs_are_safe_and_deterministic():
    e=Stage15Executor()
    for media in ({"duration":-1},{"fps":float("nan")},{"width":"abc"},{"width":1000000,"height":100000}):
        r=e.plan("generate video",media)
        assert r["ok"] is False and r["validation_errors"]


def test_stage15_handoff_preserves_upstream_provenance():
    e=Stage15Executor()
    r=e.plan("generate cinematic shot", {"duration":4,"style_digest":"style-x","editing_digest":"edit-y"}, upstream={"fingerprint":"stage14-x"})
    assert r["provenance"]["upstream_fingerprint"]=="stage14-x"
    assert r["provenance"]["style_digest"]=="style-x"
    assert r["provenance"]["editing_digest"]=="edit-y"
