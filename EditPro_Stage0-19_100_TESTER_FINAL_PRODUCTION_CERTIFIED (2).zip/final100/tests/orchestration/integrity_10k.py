import os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from orchestration import CapabilityRegistry, EditProOrchestrator, ResourceProfile

def main():
 reg=CapabilityRegistry(); names=[p.name for p in reg.providers]
 assert len(names)==len(set(names))
 for p in reg.providers:
  assert 0<=p.quality<=1 and 0<=p.speed<=1 and 0<=p.cost<=1 and 0<=p.privacy<=1
  assert p.name and p.capability and all(x for x in p.requires)
  assert all(a for a in p.alternatives)
 for i in range(10000):
  profile=[ResourceProfile('cpu'),ResourceProfile('gpu',cuda=True,tensorrt=True,max_workers=8,memory_mb=32768),ResourceProfile('amd',migraphx=True,max_workers=8,memory_mb=32768),ResourceProfile('cloud',cloud=True,max_workers=16,memory_mb=65536)][i%4]
  av=reg.availability(profile)
  assert all(isinstance(v['available'],bool) for v in av.values())
  # Deterministic routing for identical input.
  a=EditProOrchestrator(profile).registry.route('vision.detection',profile).name
  b=EditProOrchestrator(profile).registry.route('vision.detection',profile).name
  assert a==b
 print('ORCHESTRATION_INTEGRITY_10K PASS')
if __name__=='__main__': main()
