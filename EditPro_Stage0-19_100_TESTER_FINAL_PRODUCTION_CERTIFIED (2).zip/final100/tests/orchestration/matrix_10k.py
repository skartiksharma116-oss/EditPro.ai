import os, random, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from orchestration import EditProOrchestrator, ResourceProfile

VIDEO_TYPES=['h264','hevc','av1','vp9','prores','10bit','4k','8k','120fps','60fps','portrait','square','landscape','hdr','vfr','longform','shortform','speech','music','silent']
POWER=[
 ResourceProfile('cpu-low',True,False,False,False,False,False,False,False,False,1,2048),
 ResourceProfile('cpu-high',True,False,False,False,True,False,False,False,False,3,8192),
 ResourceProfile('nvidia',True,True,True,False,False,False,False,False,False,8,24576),
 ResourceProfile('amd',True,False,False,True,False,False,False,False,False,8,24576),
 ResourceProfile('intel',True,False,False,False,True,False,False,False,False,4,16384),
 ResourceProfile('apple',True,False,False,False,False,False,True,False,False,6,16384),
 ResourceProfile('webgpu',True,False,False,False,False,False,False,True,False,4,8192),
 ResourceProfile('cloud',True,False,False,False,False,False,False,False,True,16,65536),
]
CAPS=['vision.detection','vision.segmentation','vision.tracking','vision.depth','vision.pose','vision.face','vision.matting','speech.asr','speech.diarization','translation','video.generation','video.editing','image.generation','image.editing','image.upscale','video.interpolation','audio.restoration','audio.separation','audio.voice','audio.music','meme.intelligence','color.management','motion.graphics','vfx','render.gpu','render.cpu','search.project','memory.project','critic.ai','compare.ai','device.optimization','publishing','accessibility','security','command.director','timeline','asset.library','thumbnail.metadata']

def main():
    rng=random.Random(400)
    total=10000; failures=0; max_jobs=0
    for i in range(total):
        profile=POWER[i%len(POWER)]
        v=VIDEO_TYPES[i%len(VIDEO_TYPES)]
        caps=rng.sample(CAPS, rng.randint(4, min(12,len(CAPS))))
        tasks=[]
        for n,cap in enumerate(caps):
            deps=(f'job-{n-1:04d}',) if n and rng.random()<.35 else ()
            tasks.append({'capability':cap,'payload':{'video_type':v,'duration_s':rng.choice([5,15,30,60,300,3600]),'load':rng.randint(1,1000000)},'deps':deps,'priority':rng.choice(['quality','speed','cost'])})
        orch=EditProOrchestrator(profile)
        try:
            out=orch.execute({'tasks':tasks,'privacy':rng.choice(['balanced','local'])})
            if not out['ok']: failures+=1
        except Exception:
            failures+=1
        max_jobs=max(max_jobs,len(tasks))
    print(f'ORCHESTRATION_10K total={total} failures={failures} max_jobs={max_jobs}')
    if failures: raise SystemExit(1)
if __name__=='__main__': main()
