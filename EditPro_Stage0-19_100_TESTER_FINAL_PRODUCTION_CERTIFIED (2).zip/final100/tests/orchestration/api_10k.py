import os,sys,json,threading,urllib.request,time
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from backend.stage4_ui_server import create_server

def main():
 s=create_server('127.0.0.1',0); port=s.server_port; t=threading.Thread(target=s.serve_forever,daemon=True); t.start()
 try:
  for i in range(10000):
   body={'tasks':[{'capability':'vision.detection','payload':{'i':i,'frames':i%1000000}},{'capability':'render.cpu','deps':('job-0000',),'payload':{'i':i}}],'available':('cpu',),'max_workers':1,'memory_mb':1024}
   req=urllib.request.Request(f'http://127.0.0.1:{port}/api/orchestrate',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'},method='POST')
   with urllib.request.urlopen(req,timeout=3) as r:
    out=json.loads(r.read()); assert out['ok'] and len(out['jobs'])==2
 finally: s.shutdown(); s.server_close()
 print('ORCHESTRATION_API_10K PASS')
if __name__=='__main__': main()
