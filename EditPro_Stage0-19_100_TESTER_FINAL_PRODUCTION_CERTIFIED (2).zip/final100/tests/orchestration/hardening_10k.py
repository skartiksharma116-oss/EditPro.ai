import os,sys,random,hashlib
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from orchestration import EditProOrchestrator, CapabilityRegistry, ResourceProfile

def main():
 r=random.Random(77); reg=CapabilityRegistry(); caps=reg.capabilities(); assert len(caps)>=35
 profiles=[ResourceProfile('cpu-low',True,False,False,False,False,False,False,False,False,1,1024),ResourceProfile('cpu-high',True,False,False,False,True,False,False,False,False,4,16384),ResourceProfile('nvidia',True,True,True,False,False,False,False,False,False,16,65536),ResourceProfile('amd',True,False,False,True,False,False,False,False,False,16,65536),ResourceProfile('intel',True,False,False,False,True,False,False,False,False,8,32768),ResourceProfile('apple',True,False,False,False,False,False,True,False,False,8,32768),ResourceProfile('webgpu',True,False,False,False,False,False,False,True,False,8,16384),ResourceProfile('cloud',True,False,False,False,False,False,False,False,True,32,131072)]
 # 10k adversarial cases, varying video metadata, priorities, privacy, graph shape, and forced failures.
 for i in range(10000):
  prof=profiles[i%len(profiles)]; o=EditProOrchestrator(prof)
  chosen=r.sample(caps,r.randint(1,min(8,len(caps))))
  tasks=[]
  for n,c in enumerate(chosen):
   deps=() if n<2 or r.random()<.55 else (f'job-{r.randrange(n):04d}',)
   payload={'video_type':r.choice(['h264','hevc','av1','vp9','prores','hdr','vfr','10bit','4k','8k','portrait','square','speech','music','silent','noisy']), 'frames':r.randint(1,10_000_000),'fps':r.choice([1,24,25,30,50,60,120,240]),'bytes':r.randint(0,2**40),'load':2**31+r.randint(0,2**31-1)}
   if r.random()<.002: payload['force_failure']=True
   tasks.append({'capability':c,'payload':payload,'deps':deps,'priority':r.choice(['quality','speed','cost','privacy'])})
  out=o.execute({'tasks':tasks,'privacy':r.choice(['balanced','local'])})
  assert out['ok']
  assert all('input_fingerprint' in x or x.get('deferred') for x in out['jobs'].values())
 print('ORCHESTRATION_HARDENING_10K PASS')
 print('capabilities=',len(caps))
 print('providers=',len(reg.providers))
if __name__=='__main__': main()
