import random
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from editpro_pipeline import EditProPipeline

p=EditProPipeline()
rng=random.Random(12012)
formats=['reel','square','landscape','thumbnail','instagram_story']
for i in range(1000):
    duration=rng.uniform(.5,20)
    fps=rng.choice([24,25,30,60])
    media={'duration':duration,'width':rng.choice([320,640,1080,1920]),'height':rng.choice([180,360,720,1080]),'fps':fps,'format':'mp4'}
    visual=[{'label':'person','confidence':.8,'x':.4,'y':.5,'w':.2,'h':.4,'start':0,'end':min(duration,1.5),'emotion':'funny'}]
    speech={'language':'en','transcript':[{'start':.1,'end':min(.4,duration),'text':'wait bro'}] if duration>.4 else [],'beats':[min(1.0,duration/2)]}
    fmt=rng.choice(formats)
    assets=[{'id':'hero','kind':'image','license_class':'user_owned','width':1920,'height':1080,
             'metadata':{'tags':['hero',fmt],'objects':['person']}}]
    out=p.run_from_signals(media,visual=visual,speech=speech,
        intent='make a funny cinematic viral reel',target_format=fmt,style='cinematic',
        objects=[{'x':.4,'y':.5,'w':.2,'h':.4,'confidence':.9,'label':'person'}],
        assets=assets,asset_query='hero',
        asset_edits=[{'operation':'smart_crop'}])
    assert out['ok']
    stages=out['stages']
    assert all(str(n) in stages for n in range(2,13)) and '0_1' in stages
    assert stages['8']['scene'].metadata['stage9_director_digest']==stages['9']['plan'].digest
    assert stages['12']['inspection']['ok']
    assert stages['12']['plan'].selected_assets==['hero']
print('FULL_0_12_INTEGRATION_PASS checks=1000')
