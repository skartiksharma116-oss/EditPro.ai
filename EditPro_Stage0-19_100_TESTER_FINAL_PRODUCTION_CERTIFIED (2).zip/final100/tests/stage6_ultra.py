import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from stage6_vfx import *
from stage6_pipeline import Stage6Pipeline
INTENTS=['add fire around the car','remove object','add neon glow and sparks','replace screen','add fog','relight subject','background blur','add lightning energy','camera shake and motion trail','clean sign']
def adversarial():
 for x in ['',None,123,'x'*2001]:
  try: VFXPlanner().plan(x)
  except (ValueError,TypeError): pass
  else: raise AssertionError('bad intent accepted')
 for bad in [VFXMask([MaskPoint(float('nan'),0)]),VFXMask([MaskPoint(0,0),MaskPoint(1,1)])]:
  try: bad.validate()
  except ValueError: pass
  else: raise AssertionError('malformed mask accepted')
def run(n=1000000):
 p=Stage6Pipeline()
 for i in range(n):
  r=p.process(INTENTS[i%len(INTENTS)],(i%17)+1 if i%3==0 else None,(i%120,(i%120)+(i%60)),({'quality':.2 if i%101==0 else .9,'drift':100 if i%173==0 else 0,'leakage':.8 if i%197==0 else 0},),('cpu',))
  assert r['ok'] and r['packet'].validate()
 return n
if __name__=='__main__':
 adversarial(); print(f'PASS {run():,} Stage 6 VFX cycles + adversarial validation')
