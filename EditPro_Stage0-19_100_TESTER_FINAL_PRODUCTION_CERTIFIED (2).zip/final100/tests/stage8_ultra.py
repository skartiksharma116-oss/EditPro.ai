import os, sys, random, math
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from stage8_compositor import *

PASS=[]; FAIL=[]
def check(name, fn):
    try: fn(); PASS.append(name)
    except Exception as e: FAIL.append((name,repr(e)))

check('scene_validation', lambda: Scene().validate())
check('all_formats', lambda: [Scene(*SUPPORTED_FORMATS[f],fps=30,duration_frames=30).validate() for f in SUPPORTED_FORMATS])
check('mask_validation', lambda: (Mask('polygon',[(0,0),(1,0),(0,1)]).validate(), MaskEngine.bounds(Mask('ellipse'),100,100)))
check('chroma_math', lambda: (0 <= ChromaKeyEngine.alpha((0,255,0)) <= 1 and 0 <= ChromaKeyEngine.alpha((255,0,0)) <= 1))
check('tracking', lambda: TrackingEngine.interpolate([(0,0,0),(10,10,20)],5)==(5,10))
check('planner_2d', lambda: Stage8Pipeline().plan('add text and glow to background').validate())
check('planner_hybrid', lambda: Stage8Pipeline().plan('put a 3d car with fog and dust on the road').validate())
check('svg_escape', lambda: '<script>' not in SVGRenderer.render(Stage8Pipeline().plan('add text',duration_frames=2),0))
check('provider_map', lambda: 'threejs' in ProviderRegistry.available() and 'ffmpeg' in ProviderRegistry.available())
check('serialization_digest', lambda: len(SceneSerializer.digest(Stage8Pipeline().plan('car with fog')))==64)

# adversarial validation
for i in range(5000):
    def run(i=i):
        s=Scene(width=random.choice([16,128,1920,8192]),height=random.choice([16,128,1080,8192]),fps=random.choice([1,24,30,60]),duration_frames=random.randint(1,300))
        s.layers.append(SceneLayer('x','image',0,s.duration_frames,Transform(opacity=random.random()),properties={'subject':'x'}))
        s.validate(); SVGRenderer.render(s,random.randrange(s.duration_frames))
    check(f'adversarial_{i}',run)

# 10k planning/render cycles
for i in range(10000):
    def run(i=i):
        cmd=random.choice(['add text glow','car with fog dust','person with shadow','3d product zoom','background with rain'])
        s=Stage8Pipeline().plan(cmd,width=random.choice([320,720,1080,1920]),height=random.choice([320,720,1080,1920]),duration_frames=5)
        s.validate(); SVGRenderer.render(s,i%5); SceneSerializer.digest(s)
    check(f'e2e_{i}',run)

# deterministic million-ish core cycles
s=Stage8Pipeline().plan('3d car with fog and dust',duration_frames=10)
d=SceneSerializer.digest(s)
for i in range(100000):
    if SceneSerializer.digest(s)!=d: FAIL.append(('determinism',i)); break
else: PASS.append('100000_deterministic_cycles')

print('PASS=',len(PASS),'FAIL=',len(FAIL))
if FAIL:
    print('FAILURES',FAIL[:20]); raise SystemExit(1)
