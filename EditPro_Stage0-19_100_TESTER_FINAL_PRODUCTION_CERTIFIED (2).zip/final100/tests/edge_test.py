import sys
sys.path.insert(0,'.')
from ai import Stage2Pipeline
p=Stage2Pipeline()
cases=[
 ({"duration":0,"fps":0,"width":0,"height":0},None),
 ({"duration":0.001,"fps":120,"width":3840,"height":2160},[]),
 ({"duration":1,"fps":23.976,"width":1920,"height":1080},[{"start":0,"end":1,"text":"Never"}]),
 ({"duration":7200,"fps":24,"width":180,"height":3840},[{"start":7199,"end":7200,"text":"This is an important point"}]),
]
for meta,tx in cases:
    r=p.run(meta,tx,style="cinematic")
    assert r["edit_plan"]["safety"]["source_preserved"]
    for a in r["edit_plan"]["actions"]: assert 0<=a["start"]<=a["end"]<=meta["duration"]
print("Edge cases: PASS")
