import sys,subprocess,tempfile,random,os,math,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from ai.vision import inspect_media,sample_visuals
from ai.production_pipeline import ProductionStage2

EXTRA=[
 ('highfps120.mp4','320x180',120,'libx264','yuv420p',True,0.5),
 ('4k.mp4','3840x2160',24,'libx264','yuv420p',True,0.25),
 ('10bit_hevc.mkv','640x360',30,'libx265','yuv420p10le',True,0.5),
]
def make(name,size,fps,codec,pix,audio,d):
 p=ROOT/'fixtures'/name
 if p.exists(): return p
 cmd=['ffmpeg','-y','-f','lavfi','-i',f'testsrc2=size={size}:rate={fps}']
 if audio: cmd+=['-f','lavfi','-i','sine=frequency=440:sample_rate=48000']
 cmd+=['-t',str(d),'-c:v',codec,'-pix_fmt',pix]
 if audio: cmd+=['-c:a','aac','-shortest']
 cmd+=[str(p)]; subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
 return p

files=[]
for x in EXTRA:
 p=make(*x); m=inspect_media(p); assert m['duration']>0 and m['width']>0; files.append((p,m))
print('high-quality media extensions: PASS')

# Render each profile to a canonical MP4 and validate the result with ffprobe.
for p,m in files:
 out=Path(tempfile.mktemp(suffix='.mp4'))
 r=subprocess.run([sys.executable,str(ROOT/'backend/render.py'),str(p),str(out)],capture_output=True,text=True,timeout=120)
 assert r.returncode==0, (p,r.stderr[-1000:])
 om=inspect_media(out); assert om['duration']>0 and om['width']>0
 out.unlink(missing_ok=True)
print(f'{len(files)} high-quality render round trips: PASS')

# 10,000 malformed/perturbed metadata decisions. No crash and no invalid edit interval.
p=files[0][0]; pipe=ProductionStage2(); random.seed(7); base=inspect_media(p)
for i in range(10000):
 m=base.copy(); m['duration']=random.choice([m['duration'],0,-1,float('nan'),float('inf')]); m['fps']=random.choice([m['fps'],0,-2,float('nan')]);
 try: r=pipe.run_from_signals(m,[],None,random.choice(['balanced','cinematic','BAD',None]))
 except Exception as e: raise AssertionError((i,type(e).__name__))
 assert r['edit_plan']['safety']['source_preserved']
print('10,000 hostile metadata decision cases: PASS')
