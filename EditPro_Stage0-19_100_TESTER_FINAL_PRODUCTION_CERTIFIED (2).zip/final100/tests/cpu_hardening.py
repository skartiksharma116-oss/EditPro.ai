import sys, random, math, time
sys.path.insert(0,'.')
from ai.cpu_engine import CPUWorker, cpu_info
from infra.worker_scheduler import WorkerScheduler

random.seed(20260902)
ci=cpu_info(); assert ci.available and ci.logical_cores >= 1
w=CPUWorker(max_workers=min(ci.max_workers,4), max_inflight=16)
try:
    # 10,000 varied tasks, bounded queueing, deterministic outputs.
    for i in range(10000):
        n=random.choice([0,1,2,4,8,16,31])
        items=[random.choice(['frame','audio','scene','speech','4k','120fps',i]) for _ in range(n)]
        r=w.run({'items':items})
        assert r['status']=='ok' and r['items']==n and r['backend']=='cpu'
        assert math.isfinite(r['elapsed_ms']) and r['elapsed_ms'] >= 0
    print('10,000 CPU varied jobs: PASS')
    # Oversized input must fail safely, never allocate it.
    try: w.run({'items':list(range(100001))}); raise AssertionError('oversize accepted')
    except ValueError: pass
    print('CPU memory-bound rejection: PASS')
    # Determinism
    a=w.run({'items':['same']*100})['results']; b=w.run({'items':['same']*100})['results']; assert a==b
    print('CPU deterministic replay: PASS')
finally: w.close()

s=WorkerScheduler(cpu_workers=2)
try:
    for _ in range(1000):
        r=s.dispatch({'items':['speech','vision','director']*3})
        assert r['backend'] in ('cpu','rocm') and r['status'] in ('ok','ready')
    print('1,000 scheduler CPU fallback jobs: PASS')
finally: s.close()
