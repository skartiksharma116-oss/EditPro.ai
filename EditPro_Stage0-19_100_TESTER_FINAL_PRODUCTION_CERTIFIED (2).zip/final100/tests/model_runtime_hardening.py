from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ai.model_runtime import detect_model_runtimes

def main():
    for _ in range(10000):
        r=detect_model_runtimes()
        assert any(x.backend=='cpu' and x.available for x in r)
        assert len({x.backend for x in r})==len(r)
    print('10,000 model-runtime capability probes: PASS')
if __name__=='__main__': main()
