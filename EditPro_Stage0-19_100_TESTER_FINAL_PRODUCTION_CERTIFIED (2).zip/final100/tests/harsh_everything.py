import os,sys,random,math,json,threading,http.server,socketserver,subprocess,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from ai.production_pipeline import ProductionStage2
from ai.speech import SpeechWorker
from ai.cloud import CloudWorker
from ai.providers import SafeProvider
from ai.vision import inspect_media,sample_visuals
from ai.accel import detect_accelerators

random.seed(20260902)
FIX=ROOT/'fixtures'; media=[]
for p in sorted(FIX.iterdir()):
    if p.suffix.lower() in {'.mp4','.mov','.mkv','.webm'}:
        try:
            m=inspect_media(p); sample_visuals(p,3); media.append((p,m))
        except Exception as e: raise AssertionError((p,e))
assert len(media)>=8

# 10k adversarial end-to-end runs, mixing metadata, transcript, scenes, style and media classes.
p=ProductionStage2()
styles=['balanced','fast','cinematic','social','clean','INVALID',None,'']
for i in range(10000):
    path,m=media[i%len(media)]; d=m['duration']
    def rv(): return random.choice([0,-1,d, d+100, random.random()*max(d,1), float('nan'),float('inf'),None])
    tx=random.choice([[],None,'bad',[None,{},'x',{'text':'important however','start':rv(),'end':rv()}]])
    scenes=random.choice([[],None,[None,{'start':rv(),'end':rv(),'label':'x'*500}], [{'start':0,'end':d,'label':'normal'}]])
    r=p.run_from_signals(m,[],type('S',(),{'transcript':tx})() if isinstance(tx,list) else None,random.choice(styles))
    assert r['edit_plan']['safety']['source_preserved']
    for a in r['edit_plan']['actions']:
        assert 0<=a['start']<=a['end']<=d+1e-9
print('10k adversarial E2E: PASS')

# 10k provider storms, including malformed outputs and exceptions.
for i in range(10000):
    mode=i%6
    def fn(_p,mode=mode):
        if mode==0:return {'ok':True,'n':i}
        if mode==1:raise TimeoutError()
        if mode==2:return []
        if mode==3:return None
        if mode==4:return {'ok':True,'nested':{'x':'y'*10000}}
        raise RuntimeError('boom')
    r=SafeProvider('stress',fn).run({'i':i}); assert r.ok==(mode in (0,4))
print('10k provider storms: PASS')

# Speech: exercise every real audio fixture once, then 10k provider-failure calls with cached audio analysis.
for path,m in media:
    if m.get('audio'):
        r=SpeechWorker(endpoint='http://127.0.0.1:9/unreachable',timeout=0.05).transcribe(path)
        assert r.provider=='audio-signal-fallback' and r.audio_duration>=0 and 0<=r.speech_ratio<=1
sw=SpeechWorker(endpoint='http://127.0.0.1:9/unreachable',timeout=0.001)
path,m=next(x for x in media if x[1].get('audio'))
key=(str(path), path.stat().st_mtime, path.stat().st_size); sw._audio_cache={key:(m['duration'],0.5)}
for i in range(10000):
    r=sw.transcribe(path)
    assert r.provider=='audio-signal-fallback'
print('real speech fallback matrix + 10k provider-failure runs: PASS')

# 10k cloud failure/fallback calls. Use one isolated worker with a high breaker limit
# so the test exercises the failure contract without spending time constructing 10k workers.
import ai.cloud as _c
_original_urlopen = _c.urllib.request.urlopen
_original_sleep = _c.time.sleep
_c.time.sleep = lambda *_args, **_kwargs: None
_c.urllib.request.urlopen=lambda *a,**k: (_ for _ in ()).throw(TimeoutError())
try:
    w=CloudWorker(endpoint='http://127.0.0.1:9/unreachable',timeout=0.001,retries=0,breaker_limit=20000)
    for i in range(10000):
        r=w.run({'i':i,'kind':random.choice(['speech','vision','render'])})
        assert not r.ok and r.error
finally:
    _c.urllib.request.urlopen=_original_urlopen
    _c.time.sleep=_original_sleep
print('10k cloud failure runs: PASS')

# 10k scheduler/accelerator decisions, plus detection must never invent hardware.
for i in range(10000):
    acc=detect_accelerators(); assert isinstance(acc,list); assert all(a in {'rocm','cuda','oneapi'} for a in acc)
print('10k accelerator detection runs: PASS', detect_accelerators())

# Corruption and malformed media probes.
for i in range(100):
    with tempfile.NamedTemporaryFile(suffix='.mp4',delete=False) as f:
        f.write(os.urandom(random.randint(1,50000))); name=f.name
    try:
        try: inspect_media(name)
        except Exception: pass
        else: raise AssertionError('random bytes accepted as valid media')
    finally: os.unlink(name)
print('100 corrupted-media rejection probes: PASS')
