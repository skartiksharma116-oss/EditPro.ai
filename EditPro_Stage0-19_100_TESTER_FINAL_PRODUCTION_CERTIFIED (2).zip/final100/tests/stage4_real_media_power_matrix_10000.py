from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json, os, random, subprocess
from orchestration.advanced import AdvancedOrchestrator
from orchestration.core import ResourceProfile

ROOT=os.path.dirname(os.path.dirname(__file__)); FIX=os.path.join(ROOT,'fixtures')
FILES=[os.path.join(FIX,x) for x in os.listdir(FIX) if x.lower().endswith(('.mp4','.mov','.mkv','.webm'))]
POWERS=[
 ResourceProfile('cpu-low',cpu=True,max_workers=1,memory_mb=1024),
 ResourceProfile('cpu-high',cpu=True,max_workers=8,memory_mb=16384),
 ResourceProfile('nvidia-cuda',cpu=True,cuda=True,tensorrt=True,max_workers=8,memory_mb=32768),
 ResourceProfile('amd-migraphx',cpu=True,migraphx=True,max_workers=8,memory_mb=32768),
 ResourceProfile('intel-openvino',cpu=True,openvino=True,max_workers=8,memory_mb=16384),
 ResourceProfile('apple-coreml',cpu=True,coreml=True,max_workers=8,memory_mb=16384),
 ResourceProfile('webgpu',cpu=True,webgpu=True,max_workers=4,memory_mb=8192),
 ResourceProfile('cloud-gpu',cpu=True,cloud=True,max_workers=16,memory_mb=65536),
]

def probe(path):
    out=subprocess.check_output(['ffprobe','-v','error','-print_format','json','-show_streams','-show_format',path],text=True)
    d=json.loads(out); vs=next((x for x in d.get('streams',[]) if x.get('codec_type')=='video'),None); a=any(x.get('codec_type')=='audio' for x in d.get('streams',[]))
    if not vs: raise ValueError('no video')
    fps=30.0
    try:
        n,dn=(vs.get('r_frame_rate') or '30/1').split('/'); fps=float(n)/float(dn)
    except Exception: pass
    dur=float(vs.get('duration') or d.get('format',{}).get('duration') or 1)
    w=int(vs.get('width') or 1); h=int(vs.get('height') or 1)
    return {'codec':str(vs.get('codec_name','unknown')),'width':w,'height':h,'fps':fps,'duration_s':max(dur,0.01),'bit_depth':10 if '10' in str(vs.get('pix_fmt','')) else 8,'hdr': '10' in str(vs.get('pix_fmt','')),'vfr':False,'audio':a,'speech':a,'music':False,'noisy_audio':False,'portrait':h>w,'resolution_class':'8k' if max(w,h)>=7680 else ('4k' if max(w,h)>=3840 else '1080p')}

CAT=[probe(f) for f in FILES]

def run():
    rng=random.Random(983421)
    for i in range(10000):
        m=dict(rng.choice(CAT)); p=rng.choice(POWERS)
        # Max-load shape every 17th case, normal shape otherwise.
        tasks=None
        if i%17==0:
            caps=['vision.detection','vision.tracking','vision.depth','speech.asr','speech.diarization','audio.music','color.management','vfx','meme.intelligence','thumbnail.metadata']
            tasks=[{'capability':c,'payload':{}} for c in caps]*6  # 60 bounded tasks
        req={'project_id':str(i%31),'media':m,'command':rng.choice(['make this cinematic','add memes','translate captions','sync to beat','clean audio','reframe subject','']), 'priority':rng.choice(['quality','speed','cost']), 'privacy':rng.choice(['balanced','local']), 'max_competitors':rng.choice([1,2,3]), 'tasks':tasks}
        o=AdvancedOrchestrator(profile=p); out=o.execute(req)
        assert out['ok'] and out['chunks']>=1 and len(out['jobs'])<=64
    return f'PASS 10,000 real-media-profile x power-profile orchestration cycles across {len(CAT)} fixture videos and {len(POWERS)} power profiles'
if __name__=='__main__': print(run())
