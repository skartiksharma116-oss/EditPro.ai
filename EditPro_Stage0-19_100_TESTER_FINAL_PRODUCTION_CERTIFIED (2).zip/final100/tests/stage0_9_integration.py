import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from editpro_pipeline import EditProPipeline

p=EditProPipeline()
checks=0
for i in range(1000):
    media={'duration':3.0,'width':1920,'height':1080,'fps':30,'format':'mp4'}
    visual=[{'label':'person','confidence':.9,'x':.42,'y':.45,'w':.22,'h':.38,'importance':.9,'motion':.2}]
    speech={'language':'en','transcript':[{'text':'hello world'}], 'segments':[{'start':0,'end':1.2}]}
    out=p.run_from_signals(media,visual,speech,intent='make a cinematic emotional person reel',target_format='reel',style='cinematic',raw_words=speech['transcript'])
    assert out['ok']
    s8=out['stages']['8']['scene']; s9=out['stages']['9']['plan']
    assert s9.shots[-1].end==90
    assert s8.metadata['stage9_director_digest']==s9.digest
    assert s8.camera_keyframes
    checks+=1
print('STAGE0_9_INTEGRATION_PASS checks='+str(checks))
