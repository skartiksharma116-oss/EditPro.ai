from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import math, random
from stage4.router import SpeechRouter
from stage4.asr import ASRRegistry, ASRConfig
from stage4.translation import TranslationEngine

def run():
    r=SpeechRouter(); reg=ASRRegistry(); tr=TranslationEngine()
    for i in range(10000):
        lang=random.choice(['en','hi','bn','mr','ta','te','gu','pa','ur','hi-en',None])
        avail=random.choice([('cpu',),('cpu','cloud'),('cpu','cuda'),('cpu','tensorrt','cloud'),(),('cpu','migraphx')])
        p=r.choose(lang,avail,privacy=random.choice(['balanced','local']),needs=random.choice([('asr',),('asr','diarization'),('asr','translation')]))
        assert p.name in r.providers
        report=r.capability_report(avail); assert set(report)==set(r.providers)
        for n in report:
            assert 0<=report[n]['quality']<=1 and 0<=report[n]['speed']<=1
        assert all(isinstance(v,bool) for v in reg.availability().values())
        req=tr.normalize_request('en','hi'); assert req['target']=='hi'
        assert tr.select_provider('en','hi',avail) in {'identity','seamless-m4t-v2','cloud-translation','translation-unavailable'}
    # hostile inputs
    for bad in [None,'',{},[],float('nan'),float('inf')]:
        try:r.choose(language=bad,available=('cpu',))
        except Exception: pass
    return 'PASS 10,000 alternative-routing cycles'
if __name__=='__main__': print(run())
