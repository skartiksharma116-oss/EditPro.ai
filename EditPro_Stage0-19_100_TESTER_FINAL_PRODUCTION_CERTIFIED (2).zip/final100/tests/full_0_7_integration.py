"""Cross-stage integration gate for the defined Stage 0-7 build."""
from __future__ import annotations
import pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from editpro_pipeline import EditProPipeline
from stage7_design import FORMATS


def main():
    pipe = EditProPipeline()
    media = [p for p in sorted((ROOT / 'fixtures').iterdir()) if p.suffix.lower() in {'.mp4','.mov','.mkv','.webm'}]
    assert len(media) >= 8
    intents = [
        'make an instagram reel', 'make a youtube thumbnail', 'make an instagram story',
        'make a poster', 'make a brand card', 'make a square post', 'make a banner', 'make a reel'
    ]
    objects = [
        {'x': 10, 'y': 20, 'w': 100, 'h': 120, 'confidence': .95, 'label': 'person'},
        {'x': 60, 'y': 40, 'w': 90, 'h': 90, 'confidence': .88, 'label': 'car'},
    ]
    for i, path in enumerate(media[:8]):
        out = pipe.run(path, intent=intents[i], target_format=list(FORMATS)[i % len(FORMATS)],
                       character_intent='walk wave turn', vfx_intent='tracked glow',
                       style='cinematic', objects=objects if i % 2 == 0 else None)
        assert out['ok'] is True
        s = out['stages']
        assert s['2']['edit_plan']['safety']['source_preserved'] is True
        assert s['3']['quality']['ok'] is True
        assert s['4']['non_destructive'] is True
        assert s['5']['ok'] is True
        assert s['6']['ok'] is True and s['6']['packet'].validate()
        assert s['7']['ok'] is True and s['7']['template'].validate()
        if s['7']['motion']:
            assert s['7']['motion'].validate()
    # Repeat the complete cross-stage signal boundary 1,000 times without repeatedly decoding files.
    meta = {'duration': 4.0, 'fps': 30.0, 'width': 640, 'height': 360}
    visual = [{'time': 0.0, 'motion': 0.1, 'brightness': .5, 'contrast': .4},
              {'time': 2.0, 'motion': .8, 'brightness': .7, 'contrast': .6},
              {'time': 4.0, 'motion': .2, 'brightness': .4, 'contrast': .5}]
    for i in range(1000):
        out = pipe.run_from_signals(meta, visual=visual, intent='make a reel',
                                    character_intent='walk wave',
                                    objects=[None, {'x':'bad'}, {'x':0,'y':0,'w':40,'h':40,'confidence':1,'label':'object'}])
        assert out['ok'] is True
        assert out['stages']['5']['ok'] is True
    print('Stage 0-7 cross-stage integration: PASS (8 real media + 1,000 malformed-optional cycles)')

if __name__ == '__main__':
    main()
