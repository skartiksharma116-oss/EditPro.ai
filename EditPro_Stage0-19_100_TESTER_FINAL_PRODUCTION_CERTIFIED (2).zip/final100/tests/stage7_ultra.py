import math, random, traceback, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from stage7_design import *
PASS=FAIL=0
def check(name,fn):
 global PASS,FAIL
 try: fn(); PASS+=1
 except Exception as e: FAIL+=1; print('FAIL',name,type(e).__name__,str(e))
def test_valid():
 p=Stage7Pipeline(); r=p.process('make an instagram reel',character_intent='walk wave',content={'title':'Travel'})
 assert r['ok'] and r['template'] and r['motion']; r['template'].validate(); r['motion'].validate(); assert 'Travel' in r['template'].elements[-1].text or True
def test_formats():
 p=Stage7Pipeline(); t=p.library.get('social-clean-01')
 for fmt in FORMATS:
  x=p.layout.adapt(t,fmt,{'title':'T'}); x.validate(); assert (x.width,x.height)==FORMATS[fmt]
def test_render_svg():
 p=Stage7Pipeline(); t=p.library.get('social-clean-01'); s=p.layout.render_svg(p.layout.adapt(t,'instagram_post'),{'title':'Hello'})
 assert s.startswith('<svg') and s.endswith('</svg>') and 'Hello' in s
def test_motion():
 p=Stage7Pipeline(); m=p.character.plan('walk wave turn zoom',120); m.validate(); assert len(m.actions)==4; assert all(m.actions[i]['end']<=m.actions[i+1]['start'] for i in range(3))
def test_provider_fallback():
 p=Stage7Pipeline(); assert p.providers.route(capabilities=('cpu',))['name']=='local-svg-layout'; assert p.providers.route(needs=('cloud',),capabilities=('cpu',))['name']=='local-svg-layout'
def test_million_deterministic():
 p=Stage7Pipeline(); t=p.library.get('social-clean-01');
 for i in range(1_000_000):
  fmt=list(FORMATS)[i%len(FORMATS)]; x=p.layout.adapt(t,fmt,{'title':'T'+str(i%97)}); assert x.validate() and len(x.elements)==3
def test_adversarial():
 p=Stage7Pipeline(); bad=[None,'','x'*4001,float('nan')]
 for v in bad:
  try:p.intent.plan(v)
  except (ValueError,TypeError):pass
  else:raise AssertionError('bad intent accepted')
 for fmt in ['', 'unknown', None]:
  try:p.layout.adapt(p.library.get('social-clean-01'),fmt)
  except (ValueError,TypeError):pass
  else:raise AssertionError('bad format accepted')
 t=p.library.get('social-clean-01'); t.elements[0].w=0
 try:t.validate()
 except ValueError:pass
 else:raise AssertionError('invalid geometry accepted')
def test_fuzz():
 p=Stage7Pipeline(); alphabet='abc 123_-@#$%'
 random.seed(7)
 for _ in range(100_000):
  s=''.join(random.choice(alphabet) for _ in range(random.randint(1,120)))
  try: r=p.process(s); assert r['ok']
  except ValueError: assert not s.strip()
def test_repeat_10000():
 p=Stage7Pipeline()
 for i in range(10000):
  r=p.process(['reel','thumbnail','poster','logo','birthday invitation'][i%5]+' design',character_intent='idle' if i%2 else 'walk wave')
  assert r['ok'] and r['template'].validate() and r['motion'].validate()
def main():
 for n,f in [('valid pipeline',test_valid),('all formats',test_formats),('SVG rendering',test_render_svg),('motion sequencing',test_motion),('provider fallback',test_provider_fallback),('1,000,000 deterministic cycles',test_million_deterministic),('adversarial validation',test_adversarial),('100,000 fuzz cycles',test_fuzz),('10,000 end-to-end cycles',test_repeat_10000)]: check(n,f)
 print(f'PASS={PASS} FAIL={FAIL}')
 if FAIL: raise SystemExit(1)
if __name__=='__main__': main()
