import sys, random, copy
sys.path.insert(0,'.')
from ai import Stage2Pipeline

p=Stage2Pipeline(); random.seed(42)
styles=["balanced","fast","cinematic","social","clean"]
for i in range(10000):
    dur=random.uniform(.01,3600)
    meta={"duration":dur,"fps":random.choice([23.976,24,25,29.97,30,50,59.94,60,120]),
          "width":random.choice([180,240,320,480,640,720,1080,1280,1920,3840]),
          "height":random.choice([180,240,320,360,480,720,1080,2160])}
    tx=[]
    for _ in range(random.randint(0,12)):
        s=random.uniform(0,dur); e=min(dur,s+random.uniform(0,60))
        tx.append({"start":s,"end":e,"text":random.choice([
            "This is an important point", "normal sentence", "Never do this",
            "However this changed everything", "", "Always check the result"] )})
    scenes=[]
    if dur:
        cuts=sorted(set([0.0,dur]+[random.uniform(0,dur) for _ in range(random.randint(0,6))]))
        scenes=[{"id":j+1,"start":cuts[j],"end":cuts[j+1],"label":f"scene_{j+1}"} for j in range(len(cuts)-1) if cuts[j+1]>cuts[j]]
    result=p.run(meta,tx,scenes,random.choice(styles))
    vm=result["video_map"]; plan=result["edit_plan"]
    assert vm.width==meta["width"] and vm.height==meta["height"]
    assert vm.duration==dur
    assert plan["safety"]=={"source_preserved":True,"destructive":False}
    assert plan["version"]==1
    for a in plan["actions"]:
        assert 0 <= a["start"] <= a["end"] <= dur
print("10,000 full Analyzer -> Director -> Validator integration runs: PASS")
