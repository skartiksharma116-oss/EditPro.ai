import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from editpro_pipeline import EditProPipeline
import random

def main():
    p=EditProPipeline(); rng=random.Random(111)
    for i in range(1000):
        duration=rng.uniform(.5,30)
        visual=[]
        if i%2==0: visual=[{'label':'person','confidence':.8,'x':.4,'y':.5,'w':.2,'h':.4,'start':1,'end':2,'emotion':'funny'}]
        speech={'transcript':[{'start':.1,'end':.4,'text':'wait bro'}], 'beats':[1.0,2.0]} if i%3==0 else {}
        out=p.run_from_signals({'duration':duration,'width':1920,'height':1080,'fps':30,'energy':.6},visual=visual,speech=speech,intent='make a funny viral reel',target_format='reel')
        assert out['ok'] and out['stages']['11']['ok']
        out['stages']['11']['plan'].validate()
    print('STAGE0_11_INTEGRATION_PASS checks=1000')
if __name__=='__main__': main()
