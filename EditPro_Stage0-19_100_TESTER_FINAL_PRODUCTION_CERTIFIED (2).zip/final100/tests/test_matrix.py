import sys, pathlib, subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from ai.vision import inspect_media, sample_visuals
from ai.speech import SpeechWorker

def main():
 for p in sorted((ROOT/'fixtures').iterdir()):
  if p.suffix.lower() in {'.mp4','.mov','.mkv','.webm'}:
   m=inspect_media(p); assert m['duration']>0 and m['width']>0
   sample_visuals(p,4)
 print('media matrix: PASS')
if __name__=='__main__': main()
