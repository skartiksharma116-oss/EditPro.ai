from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json, random
from stage9_cinematography import Stage9Pipeline, ShotCandidate, DirectorConfig, ShotPlanner

p=Stage9Pipeline()
checks=0
for i in range(10000):
    moods=["cinematic","emotional","fast viral reel","dramatic car edit","calm landscape","romantic"]
    cmd=moods[i%len(moods)]
    plan=p.plan(cmd, media={"duration":3.0}, fps=30, duration_frames=90, target_format="reel")
    assert plan.shots and plan.shots[-1].end<=90 and plan.digest
    assert p.inspect(plan)["coverage_frames"]==90
    checks+=1

for i in range(5000):
    rng=random.Random(i)
    cmd="make a " + rng.choice(["cinematic","energetic","emotional","dark","calm"]) + " video " + rng.choice(["person","car","product","landscape"])
    plan=p.plan(cmd, speech={"transcript":[{"text":"hello"}] if i%2 else []}, media={"duration":rng.random()*20+0.1}, fps=24, duration_frames=rng.randint(1,500))
    assert plan.validate() is None
    checks+=1

# Determinism
for _ in range(100000):
    a=p.plan("cinematic person video",media={"duration":3},fps=30,duration_frames=90,target_format="landscape")
    b=p.plan("cinematic person video",media={"duration":3},fps=30,duration_frames=90,target_format="landscape")
    assert a.digest==b.digest
    checks+=1
print(f"STAGE9_ULTRA_PASS checks={checks}")
