from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from stage11_meme import *
import random

def catalog():
    return [
        MemeAsset('reaction-ok',asset_type='image',license_class='app_approved',tags=['reaction','relatable','wait'],emotions=['funny','shock'],style='reaction'),
        MemeAsset('caption-ok',asset_type='text',license_class='public_domain',tags=['seriously','funny'],emotions=['awkward','funny'],style='caption'),
        MemeAsset('audio-ok',asset_type='audio_reaction',license_class='user_owned',tags=['beat','reaction'],emotions=['funny','excited'],style='classic',audio=True,duration=.7),
        MemeAsset('licensed-video',asset_type='video',license_class='licensed',tags=['dramatic'],emotions=['dramatic','shock'],style='cinematic',audio=True,duration=1.0),
    ]

def main():
    p=Stage11Pipeline(catalog())
    base=dict(command='make this reel funny and viral with reactions',duration=30,target_format='reel',visual=[{'start':2,'end':3,'emotion':'funny','confidence':.9,'keywords':['wait','bro']}],speech=[{'start':5,'end':6,'text':'seriously bro','confidence':.9}],beats=[2.5,7.0])
    plan=p.plan(**base); assert plan.validate() is None and plan.selected_count>=1
    assert plan.digest==p.digest(plan)
    # no-meme intent must be non-destructive
    no=p.plan('make a cinematic luxury video',30,visual=[{'start':1,'end':2,'emotion':'dramatic'}]); assert no.selected_count==0
    # no assets must skip safely
    empty=Stage11Pipeline().plan(**base); assert empty.selected_count==0 and empty.warnings
    # bad assets must be rejected
    try: MemeAsset('bad',license_class='random')
    except ValueError: pass
    else: raise AssertionError('bad license accepted')
    # deterministic 100k digest cycles
    d=plan.digest
    for _ in range(100000):
        q=p.plan(**base)
        assert q.digest==d
    # randomized adversarial inputs
    rng=random.Random(11011)
    for _ in range(20000):
        dur=rng.uniform(.1,120)
        vis=[]
        for j in range(rng.randrange(0,5)):
            a=rng.uniform(-10,dur+10); b=rng.uniform(-10,dur+10)
            vis.append({'start':a,'end':b,'emotion':rng.choice(list(EMOTIONS)),'confidence':rng.uniform(-2,2),'keywords':['x','wait']})
        speech=[{'start':rng.uniform(-5,dur+5),'end':rng.uniform(-5,dur+5),'text':'haha bro'}]
        beats=[rng.uniform(-5,dur+5), 'bad', {'time':rng.uniform(-2,dur+2)}]
        q=p.plan('funny meme reel',dur,'reel','reaction',vis,speech,beats,max_memes=8)
        q.validate()
        assert all(0<=d.moment_start<=d.moment_end<=dur+1e-9 for d in q.decisions)
    print('STAGE11_ULTRA_PASS checks=120000')
if __name__=='__main__': main()
