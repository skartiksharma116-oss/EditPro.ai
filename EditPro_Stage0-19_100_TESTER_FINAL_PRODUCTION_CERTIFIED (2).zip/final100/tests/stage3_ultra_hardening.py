import sys, pathlib, random, tempfile, hashlib, json, statistics, time
ROOT=pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from stage3.production_bridge import ModelRegistry, PerformanceBudget, environment_report
from stage3.pipeline import Stage3Pipeline
from stage3.scheduler import ResponsiveScheduler
from ai.plugin_registry import PluginRegistry, PluginSpec

def model_registry_tests():
    d=pathlib.Path(tempfile.mkdtemp()); p=d/'model.bin'; p.write_bytes(b'EDITPRO-TEST-MODEL'*100)
    r=ModelRegistry(d/'registry'); a=r.register('vision','1',p); assert r.verify(a)
    p.write_bytes(b'CORRUPTED'); assert not r.verify(a)
    for bad in ['../escape','a/b','', 'a'*101]:
        try: r.register(bad,'1',p); raise AssertionError('invalid model name accepted')
        except ValueError: pass
    for i in range(10000):
        p.write_bytes((str(i)+'-model').encode()); a=r.register('vision',str(i),p); assert r.verify(a)
    print('10,000 model artifact integrity cycles: PASS')

def pipeline_mutations():
    rng=random.Random(123); good=bad=0
    for i in range(10000):
        frames=[]
        n=rng.randint(0,30)
        for j in range(n):
            frames.append({'time':rng.uniform(-1,5),'motion':rng.uniform(-2,2),'brightness':rng.uniform(-2,2),'contrast':rng.uniform(-2,2)})
        try:
            out=Stage3Pipeline().run(5,1920,1080,frames=frames,target=rng.choice([(9,16),(16,9),(1,1),(4,5)]),available_runtimes=rng.choice([('cpu',),('cuda','cpu'),('migraphx','cpu'),('tensorrt','cuda','cpu')]))
            assert out['quality']['ok'] and out['reframe']['w']>0 and out['reframe']['h']>0
            good+=1
        except (ValueError,TypeError): bad+=1
    assert good+bad==10000
    print(f'10,000 hostile Stage-3 pipeline mutations: PASS ({good} accepted, {bad} rejected)')

def scheduler_stress():
    # Queue saturation must fail safely, not silently drop work.
    s=ResponsiveScheduler(workers=4,max_queue=256); fs=[]; rejected=0
    for i in range(10000):
        try: fs.append(s.submit(lambda x:x*x,i,priority=i%20))
        except RuntimeError as e:
            assert str(e)=='scheduler_queue_full'; rejected+=1
            for f in fs: f.result(timeout=10)
            fs=[]
    for f in fs: f.result(timeout=10)
    assert rejected>0
    s.shutdown(); print(f'10,000 scheduler submissions with bounded backpressure: PASS ({rejected} expected queue-full events)')

def plugin_mutations():
    r=PluginRegistry(); r.register(PluginSpec('p','1','foundation',lambda p:{'ok':True,'n':p['n']}))
    for i in range(10000): assert r.run('foundation','p',{'n':i})['n']==i
    for x in [None,[],1,'bad',{'unexpected':1}]:
        try: r.run('foundation','p',x); raise AssertionError('invalid payload accepted')
        except (TypeError,KeyError): pass
    print('10,000 plugin executions + mutation rejection: PASS')

def performance_budget_tests():
    b=PerformanceBudget()
    for i in range(10000):
        m={'preview_p95_ms':random.random()*99,'interaction_p95_ms':random.random()*999,'export_start_p95_ms':random.random()*4999}
        assert all(b.check(m).values())
    for bad in [{'preview_p95_ms':float('nan'),'interaction_p95_ms':1,'export_start_p95_ms':1},{'preview_p95_ms':-1,'interaction_p95_ms':1,'export_start_p95_ms':1}]:
        try: b.check(bad); raise AssertionError('invalid metric accepted')
        except ValueError: pass
    print('10,000 performance-budget checks + invalid-metric rejection: PASS')

def main():
    model_registry_tests(); pipeline_mutations(); scheduler_stress(); plugin_mutations(); performance_budget_tests()
    print('External environment availability:', environment_report())
    print('Stage 3 ultra hardening: PASS')
if __name__=='__main__': main()
