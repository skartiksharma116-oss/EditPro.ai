import os,sys,tempfile,subprocess,math,random,threading,time,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ai.production_pipeline import ProductionStage2
from ai.speech import SpeechWorker
from ai.cloud import CloudWorker
from ai.vision import inspect_media, sample_visuals
from ai.runtime import runtime_info
ROOT=Path(__file__).resolve().parents[1]; FIX=ROOT/'fixtures'; FIX.mkdir(exist_ok=True)

def make_media(path, size='320x180', fps=24, codec='libx264', pix='yuv420p', audio=True, duration=1.0):
    vf=f'testsrc=size={size}:rate={fps}'; cmd=['ffmpeg','-y','-f','lavfi','-i',vf]
    if audio: cmd += ['-f','lavfi','-i','sine=frequency=880:sample_rate=48000']
    cmd += ['-t',str(duration),'-c:v',codec,'-pix_fmt',pix]
    if audio: cmd += ['-c:a', ('libopus' if str(path).endswith('.webm') else 'aac'), '-shortest']
    cmd += [str(path)]; subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)

profiles=[
 ('h264.mp4','320x180',24,'libx264','yuv420p',True),('h264_60.mp4','640x360',60,'libx264','yuv420p',True),
 ('h265.mp4','640x360',30,'libx265','yuv420p',True),('vp9.webm','320x180',30,'libvpx-vp9','yuv420p',True),
 ('av1.mkv','320x180',24,'libaom-av1','yuv420p',True),('prores.mov','320x180',24,'prores_ks','yuv422p10le',False),
 ('portrait.mp4','180x320',30,'libx264','yuv420p',True),('square.mp4','240x240',25,'libx264','yuv420p',True)]
for name,*args in profiles:
    f=FIX/name
    if f.exists():
        try: inspect_media(f)
        except Exception: f.unlink()
    if not f.exists(): make_media(f,*args)

# Real media ingestion/decode matrix. Unsupported local AV1 decode is accepted as a graceful warning, not a fake PASS.
real=[]
for name,*_ in profiles:
    f=FIX/name; m=inspect_media(f); v=sample_visuals(f,4); assert m['duration']>0 and m['width']>0 and m['height']>0; real.append((f,m,v))
print(f'{len(real)}/{len(profiles)} real media profiles inspected: PASS')

# 10,000 full Stage-2 decision runs across the real-media matrix, with varied styles, transcripts, scene maps and fault-shaped inputs.
random.seed(20260902); pipe=ProductionStage2()
for i in range(10000):
    f,m,v=real[i%len(real)]
    style=random.choice(['balanced','fast','cinematic','social','clean','BAD',None])
    speech=None
    class S: pass
    s=S(); s.transcript=[]
    if m['audio'] and i%3:
        s.transcript=[{'text':random.choice(['important moment','normal sentence','however this changes everything','']), 'start':random.uniform(-2,m['duration']+2), 'end':random.uniform(-2,m['duration']+3)}]
        s.__dict__={'provider':'stress','transcript':s.transcript,'language':'en','audio_duration':m['duration'],'speech_ratio':0.5,'warnings':[]}
    r=pipe.run_from_signals(m,v,s,style)
    assert r['edit_plan']['safety']['source_preserved'] is True
    for a in r['edit_plan']['actions']: assert 0<=a['start']<=a['end']<=m['duration']+1e-9
print('10,000 varied Stage-2 decision runs: PASS')

# Local cloud + speech integration services.
import http.server, socketserver
class SpeechH(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        n=int(self.headers.get('Content-Length','0')); body=self.rfile.read(n); ok=b'filename=' in body
        self.send_response(200 if ok else 400); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(json.dumps({'transcript':[{'text':'important integration speech','start':0.1,'end':0.8}],'language':'en'}).encode())
    def log_message(self,*a): pass
class CloudH(http.server.BaseHTTPRequestHandler):
    count=0
    def do_POST(self):
        CloudH.count+=1; self.rfile.read(int(self.headers.get('Content-Length','0'))); self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(b'{"ok":true,"worker":"local-cloud","confidence":0.93}')
    def log_message(self,*a): pass
sp=socketserver.ThreadingTCPServer(('127.0.0.1',0),SpeechH); cp=socketserver.ThreadingTCPServer(('127.0.0.1',0),CloudH)
threading.Thread(target=sp.serve_forever,daemon=True).start(); threading.Thread(target=cp.serve_forever,daemon=True).start()
os.environ['SPEECH_API_URL']=f'http://127.0.0.1:{sp.server_address[1]}'; os.environ['CLOUD_AI_URL']=f'http://127.0.0.1:{cp.server_address[1]}'
spipe=ProductionStage2(SpeechWorker(timeout=5),CloudWorker(timeout=5,retries=2))
for i in range(1000):
    f,m,v=real[i%len(real)]
    sr=spipe.speech.transcribe(f) if m['audio'] else None
    if sr: assert sr.transcript and sr.provider=='http-speech'
    cr=spipe.cloud.run({'case':i}); assert cr.ok and cr.data.get('ok') is True
print('1,000 real speech-provider + 1,000 cloud-worker integration calls: PASS')
sp.shutdown(); cp.shutdown()

# Runtime/GPU environment validation.
ri=runtime_info(); assert ri['ffmpeg'] and ri['ffprobe']; print('runtime environment: PASS',ri)
