from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from stage13_style import *

def test_deterministic():
    e=Stage13StyleEngine(); a=e.plan("make a luxury cinematic reel", mode="balanced"); b=e.plan("make a luxury cinematic reel", mode="balanced")
    assert a.digest==b.digest and a.profile.digest==b.profile.digest

def test_all_handoffs():
    e=Stage13StyleEngine(); p=e.plan("neon energetic instagram reel")
    h=e.handoff(p)
    assert h["deterministic"] is True
    assert set(["stage7","stage8","stage9","stage10","stage11","stage12"]).issubset(h["targets"])
    assert len(h["palette"]["colors"])>=3

def test_invalid_color_rejected():
    e=Stage13StyleEngine()
    try: e.create_profile("clean", overrides={"palette":{"colors":["not-a-color"]}})
    except ValueError: return
    raise AssertionError("invalid color accepted")

def test_bounds():
    p=Stage13StyleEngine().create_profile("balanced", overrides={"vfx_intensity":1,"grain":0,"glow":.9,"audio_energy":.1,"meme_energy":.8})
    p.validate()

def test_provider_fallback():
    e=Stage13StyleEngine(providers=[])
    assert "deterministic style path" in e.plan("clean").warnings[0]
