import random,sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from stage5_tracking import Box,Detection,PersistentTracker
from stage5_pipeline import TrackingPipeline
from orchestration.core import ResourceProfile
VIDEOS=[('h264',1920,1080,30),('hevc',3840,2160,60),('av1',7680,4320,30),('vp9',1080,1920,120),('prores',4096,2160,24),('h264',1080,1080,29.97),('h265',1280,720,24),('av1',2560,1440,144),('webm',720,1280,60),('hdr10',3840,2160,30),('vfr',1920,1080,59.94),('low',640,360,15)]
POWERS=[ResourceProfile('cpu-low',memory_mb=1024,max_workers=1),ResourceProfile('cpu-high',memory_mb=16384,max_workers=8),ResourceProfile('nvidia',cuda=True,tensorrt=True,memory_mb=32768),ResourceProfile('amd',migraphx=True,memory_mb=32768),ResourceProfile('intel',openvino=True,memory_mb=16384),ResourceProfile('apple',coreml=True,memory_mb=16384),ResourceProfile('webgpu',webgpu=True,memory_mb=8192),ResourceProfile('cloud',cloud=True,memory_mb=65536)]
def run():
 r=random.Random(505050)
 for n in range(10000):
  _,w,h,fps=r.choice(VIDEOS); power=r.choice(POWERS); frames=[]
  for k in range(r.randint(3,20)):
   ds=[]
   for j in range(r.randint(0,12)):
    x=(j*37+k*3)%max(1,w-80); y=(j*19+k*2)%max(1,h-80); bw=r.randint(20,120); bh=r.randint(20,120)
    if r.random()<.08: continue
    ds.append(Detection(Box(x,y,bw,bh),r.choice(['person','car','product','animal']),r.random()*.5+.5))
   frames.append(ds)
  out=TrackingPipeline(power).process(frames,priority=r.choice(['quality','speed','cost']))
  assert out['ok'] and out['provider'] and 0<=out['critic']['score']<=1
  tr=PersistentTracker(); ids=[]
  for d in [Detection(Box(10,10,40,40),'car'),Detection(Box(12,10,40,40),'car'),Detection(Box(14,10,40,40),'car')]: ids.append(tr.update([d])[0].track_id)
  assert ids[0]==ids[1]==ids[2]
 try: PersistentTracker().update([Detection(Box(float('nan'),0,1,1))]); raise AssertionError
 except ValueError: pass
 try: PersistentTracker().update('bad'); raise AssertionError
 except ValueError: pass
 return 'PASS 10,000 mixed tracking/media/power cycles + adversarial checks'
if __name__=='__main__': print(run())
