import sys, random, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from editpro_pipeline import EditProPipeline

p=EditProPipeline()
commands=['make an instagram reel with a 3d car, fog, dust, glow and text','make a youtube thumbnail with a product and shadow','make a poster with a person and rain','make a cinematic reel with logo and zoom']
for i in range(10000):
    meta={'duration':random.choice([0.1,1,4,10,30]),'fps':random.choice([24,25,30,60]),'width':random.choice([320,640,1080,1920]),'height':random.choice([180,360,720,1080])}
    out=p.run_from_signals(meta, visual=[{'time':0,'motion':0.1}], speech={'language':'en','transcript':[]}, intent=random.choice(commands), objects=[None,{'x':'bad'}, {'x':0,'y':0,'w':20,'h':20,'confidence':.9,'label':'car'}])
    assert out['ok'] and out['stages']['8']['ok']
print('Stage 0-8 signal integration 10,000: PASS')
