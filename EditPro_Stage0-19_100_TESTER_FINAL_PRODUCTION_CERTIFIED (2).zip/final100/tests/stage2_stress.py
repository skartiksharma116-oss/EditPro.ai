import random,sys
sys.path.insert(0,'.')
from ai.analyzer import VideoUnderstandingEngine
from ai.director import EditingDirector
random.seed(20260901);e=VideoUnderstandingEngine();d=EditingDirector()
for _ in range(10000):
 dur=random.uniform(.01,7200); meta={'duration':dur,'fps':random.choice([23.976,24,25,30,50,60,120]),'width':random.choice([180,320,640,1280,1920,3840]),'height':random.choice([180,320,360,720,1080,2160])}
 tx=[]
 for _ in range(random.randrange(8)):
  s=random.uniform(0,dur); tx.append({'start':s,'end':min(dur,s+random.uniform(0,30)),'text':random.choice(['important point','normal sentence','Never do this','However this can change',''])})
 vm=e.analyze(meta,tx); plan=d.plan(vm,random.choice(['balanced','fast','cinematic','social','clean']))
 assert vm.duration==dur and plan['safety']['source_preserved'] and not plan['safety']['destructive']
 for a in plan['actions']: assert 0<=a['start']<=a['end']<=dur
print('10,000 Stage 2 AI scenarios: PASS')
