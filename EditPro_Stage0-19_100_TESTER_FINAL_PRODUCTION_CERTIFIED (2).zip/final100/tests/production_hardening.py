import sys, random, math, threading, urllib.request, time
sys.path.insert(0,'.')
from ai import Stage2Pipeline
from ai.providers import SafeProvider

# 10k adversarial pipeline cases
p=Stage2Pipeline(); random.seed(20260902)
for i in range(10000):
    vals=[random.uniform(0.001,7200), 0, -1, float('nan'), float('inf'), -float('inf')]
    dur=random.choice(vals)
    meta={'duration':dur,'fps':random.choice([0,24,29.97,60,120,float('nan')]),'width':random.choice([0,180,720,1920,-4,float('inf')]),'height':random.choice([0,180,1080,-9,float('nan')])}
    tx=[None,{}, {'text':'important point','start':-5,'end':999999}, {'text':'normal','start':float('nan'),'end':float('inf')}, 'bad']
    scenes=[None,{}, {'start':-9,'end':99999,'label':'x'*1000}, {'start':float('nan'),'end':float('inf')}]
    r=p.run(meta,tx,scenes,random.choice(['balanced','fast','cinematic','social','clean','BAD',None]))
    assert math.isfinite(r['video_map'].duration)
    for a in r['edit_plan']['actions']:
        assert 0 <= a['start'] <= a['end'] <= r['video_map'].duration + 1e-9
print('10,000 adversarial pipeline runs: PASS')

# Provider failure/return-shape storm
for i in range(10000):
    mode=i%4
    def fn(payload, mode=mode):
        if mode==0: return {'ok':True}
        if mode==1: raise TimeoutError()
        if mode==2: return ['wrong']
        raise RuntimeError()
    r=SafeProvider('mock',fn).run({})
    if mode==0: assert r.ok
    else: assert not r.ok
print('10,000 AI-provider failure/fallback simulations: PASS')
