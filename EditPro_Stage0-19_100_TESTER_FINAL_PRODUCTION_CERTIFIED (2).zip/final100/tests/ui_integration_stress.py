import json, pathlib, subprocess, sys, time, urllib.request, random, signal
ROOT=pathlib.Path(__file__).resolve().parents[1]
p=subprocess.Popen([sys.executable,str(ROOT/'backend/stage3_ui_server.py')],env={**__import__('os').environ,'PYTHONPATH':str(ROOT),'PORT':'4184'})
try:
    for _ in range(100):
        try: urllib.request.urlopen('http://127.0.0.1:4184/api/health',timeout=1); break
        except Exception: time.sleep(.02)
    req=urllib.request.Request('http://127.0.0.1:4184/api/stage3/analyze',method='POST',headers={'Content-Type':'application/json'})
    for i in range(10000):
        frames=[{'time':0.1,'motion':random.random(),'brightness':.5,'contrast':.5},{'time':.2,'motion':.8,'brightness':.6,'contrast':.7}]
        body=json.dumps({'duration':1,'width':1920,'height':1080,'frames':frames,'target':[9,16],'available_runtimes':['cpu']}).encode()
        req.data=body
        with urllib.request.urlopen(req,timeout=5) as r:
            x=json.loads(r.read()); assert x['ok'] and x['result']['quality']['ok']
    # malformed request matrix
    for body in [b'not-json',b'{}',json.dumps({'duration':-1}).encode(),json.dumps({'width':'x','height':1080,'duration':1}).encode()]:
        req.data=body
        try:
            with urllib.request.urlopen(req,timeout=5) as r: code=r.status
        except urllib.error.HTTPError as e: code=e.code
        assert code in (400,500)
    print('10,000 UI -> Stage 3 API integration requests + malformed request matrix: PASS')
finally:
    p.terminate(); p.wait(timeout=5)
