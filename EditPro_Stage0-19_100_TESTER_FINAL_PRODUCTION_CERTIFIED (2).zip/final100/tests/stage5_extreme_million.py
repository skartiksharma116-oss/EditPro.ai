import random,sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from stage5_tracking import Box,Detection,AdaptivePersistentTracker
from stage5_pipeline import TrackingPipeline
from orchestration.core import ResourceProfile
VIDEOS=[('h264',640,360,15),('h264',1920,1080,30),('hevc',3840,2160,60),('av1',7680,4320,30),('vp9',1080,1920,120),('prores',4096,2160,24),('square',1080,1080,30),('hdr10',3840,2160,30),('vfr',1920,1080,59.94),('tiny',320,240,12),('8k',7680,4320,60),('highfps',1920,1080,240)]
POWERS=[ResourceProfile('cpu-low',memory_mb=1024,max_workers=1),ResourceProfile('cpu-high',memory_mb=16384,max_workers=8),ResourceProfile('nvidia',cuda=True,tensorrt=True,memory_mb=32768),ResourceProfile('amd',migraphx=True,memory_mb=32768),ResourceProfile('intel',openvino=True,memory_mb=16384),ResourceProfile('apple',coreml=True,memory_mb=16384),ResourceProfile('webgpu',webgpu=True,memory_mb=8192),ResourceProfile('cloud',cloud=True,memory_mb=65536)]
def run(n=1_000_000):
 r=random.Random(918273645); total=0
 for i in range(n):
  _,w,h,fps=r.choice(VIDEOS); power=r.choice(POWERS)
  tracker=AdaptivePersistentTracker(max_tracks=r.randint(4,24),max_misses=r.randint(1,8))
  ds=[]
  for j in range(r.randint(0, min(5,tracker.max_tracks))):
   bw=r.randint(5,max(6,min(120,w))); bh=r.randint(5,max(6,min(120,h))); x=r.random()*max(1,w-bw); y=r.random()*max(1,h-bh)
   if r.random()<.015:
    try: tracker.update([Detection(Box(float('nan'),y,bw,bh),'object')]); raise AssertionError('invalid detection accepted')
    except ValueError: pass
    continue
   app=tuple(r.uniform(-1,1) for _ in r.choice([(),(1,2,3,4),(1,2,3,4,5,6,7,8)]))
   ds.append(Detection(Box(x,y,bw,bh),r.choice(['person','car','product','animal','text']),r.random()*.5+.5,app))
  tracker.update(ds); total+=1
  if i % 50000 == 0 and i:
   # Periodically exercise a difficult recovery path.
   tracker.update([]); tracker.update(ds)
  if i and i%250000==0: print('completed',i,flush=True)
 # Deterministic ID stability and bounded state checks.
 t=AdaptivePersistentTracker(max_tracks=8,history_limit=16); ids=[]
 for x in (10,12,14,16): ids.append(t.update([Detection(Box(x,10,40,40),'car')])[0].track_id)
 assert len(set(ids))==1 and all(len(v.history)<=16 for v in t.tracks.values())
 return f'PASS {n:,} mixed adversarial tracking scenarios'
def is_finite_detection(*v):
 import math
 return all(math.isfinite(x) for x in v)
if __name__=='__main__': print(run())
