import sys,threading,time,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ai.production_pipeline import ProductionStage2
from ai.cloud import CloudWorker
from ai.speech import SpeechWorker
from ai.runtime import runtime_info
ROOT=Path(__file__).resolve().parents[1]; f=ROOT/'fixtures'/'h264.mp4'
# 1,000 concurrent cloud requests against deterministic local-style function.
class FakeCloud:
 def __init__(self): self.n=0; self.lock=threading.Lock()
 def run(self,p):
  with self.lock:self.n+=1
  return type('R',(),{'ok':True,'data':{'ok':True},'attempts':1})()

pipe=ProductionStage2(cloud=FakeCloud()); errors=[]
def worker(start):
 try:
  for i in range(100):
   r=pipe.run_from_signals({'duration':1,'fps':24,'width':320,'height':180},[],None,'balanced'); assert r['edit_plan']['safety']['source_preserved']
 except Exception as e: errors.append(e)
ts=[threading.Thread(target=worker,args=(i,)) for i in range(10)]
for t in ts:t.start()
for t in ts:t.join()
assert not errors,errors
print('1,000 concurrent pipeline calls: PASS')
