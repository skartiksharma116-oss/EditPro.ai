import os,sys,math,time
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from stage3.plugins import PluginRegistry
from stage3.camera import VirtualCamera
from stage3.critic import EditSelfCritic
from stage3.pipeline import Stage3Pipeline

def main():
 t=time.perf_counter(); reg=PluginRegistry(); reg.register('core','3.0',['tracking','reframe'])
 for i in range(10000):
  assert reg.get('core')['version']=='3.0'; assert reg.list()[0]['name']=='core'
 print('plugin_registry_10k=PASS')
 cam=VirtualCamera(); crit=EditSelfCritic(); p=Stage3Pipeline()
 for i in range(10000):
  r=p.run(10,1920,1080,objects=[{'x':400,'y':200,'w':600,'h':500,'confidence':.95,'label':'person'}],target=(9,16),available_runtimes=('cpu',))
  assert r['critic']['accept'] and r['virtual_camera']['mode']=='follow'
  r2=p.run(10,1920,1080,objects=[{'x':400,'y':200,'w':600,'h':500,'confidence':.05,'label':'person'}],target=(9,16),available_runtimes=('cpu',))
  assert r2['virtual_camera']['mode']=='original' and r2['quality']['action']=='fallback_original'
 print('camera_critic_pipeline_20k=PASS')
 print('final_stage3_foundation_elapsed_s=%.3f'%(time.perf_counter()-t))
main()
