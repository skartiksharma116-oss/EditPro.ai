import os,sys,time,concurrent.futures,math
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from stage3.scheduler import ResponsiveScheduler
from stage3.detection import SafeDetectionProvider
from stage3.quality import EditQualityGate
from stage3.pipeline import Stage3Pipeline

def main():
 t=time.perf_counter(); s=ResponsiveScheduler(workers=4,max_queue=10000)
 futs=[s.submit(lambda x:x*x,i,priority=(i%5)) for i in range(10000)]
 assert [f.result() for f in futs]==[i*i for i in range(10000)]; s.shutdown(); print('scheduler_10k=PASS')
 d=SafeDetectionProvider(); q=EditQualityGate(); p=Stage3Pipeline()
 for i in range(10000):
  assert d.detect({'detections':[{'x':1,'y':2,'w':3,'h':4,'confidence':.9,'label':'person'}]})
  r=p.run(5,1920,1080,objects=[{'x':400,'y':200,'w':500,'h':500,'confidence':.9,'label':'person'}],available_runtimes=('cpu',))
  assert q.check(r['reframe'],r['tracks'])['ok']
 print('foundation_combo_10k=PASS'); print('smoothness_elapsed_s=%.3f'%(time.perf_counter()-t))
main()
