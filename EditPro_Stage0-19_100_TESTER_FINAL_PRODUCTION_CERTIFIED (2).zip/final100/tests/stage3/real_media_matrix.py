import os,sys,time,glob
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from stage3.stage3_production import Stage3Production

def main():
 root=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),'fixtures')
 files=sorted(glob.glob(root+'/*'))
 p=Stage3Production(); good=0
 for f in files:
  if os.path.isdir(f): continue
  try:
   r=p.run(f,target=(9,16),available_runtimes=('cpu',))
   assert r['media']['duration']>=0 and r['quality']['ok']
   good+=1; print('PASS',os.path.basename(f))
  except ValueError as e:
   if os.path.basename(f).endswith('.wav') and str(e)=='no_video_stream': good+=1; print('PASS expected audio-only rejection',os.path.basename(f)); continue
   print('FAIL',os.path.basename(f),type(e).__name__,e); raise
  except Exception as e: print('FAIL',os.path.basename(f),type(e).__name__,e); raise
 print('real_media=%d/%d PASS'%(good,len(files)))
main()
