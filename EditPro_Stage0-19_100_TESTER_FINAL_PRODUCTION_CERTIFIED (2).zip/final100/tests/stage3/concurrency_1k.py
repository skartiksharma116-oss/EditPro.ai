import os,sys,concurrent.futures
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from stage3.pipeline import Stage3Pipeline

def one(i):
 p=Stage3Pipeline(); r=p.run(8,1280,720,frames=[{'time':0,'motion':.1,'brightness':.5,'contrast':.5},{'time':1,'motion':.8,'brightness':.6,'contrast':.8}],objects=[{'x':100+i%50,'y':100,'w':300,'h':200,'confidence':.9,'label':'person'}],available_runtimes=('cuda','cpu')); return r['quality']['ok'] and r['critic']['accept']
with concurrent.futures.ThreadPoolExecutor(max_workers=32) as ex:
 assert all(ex.map(one,range(1000)))
print('concurrent_1000=PASS')
