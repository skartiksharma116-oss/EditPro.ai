import os,sys,random,time,math,concurrent.futures
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from stage3.pipeline import Stage3Pipeline
from stage3.scheduler import ResponsiveScheduler
from stage3.detection import SafeDetectionProvider
from stage3.quality import EditQualityGate
from ai.orchestrator import Stage2Pipeline

N=10000; random.seed(98765)
def main():
 t=time.perf_counter(); p=Stage3Pipeline(); s2=Stage2Pipeline(); det=SafeDetectionProvider(); gate=EditQualityGate()
 for i in range(N):
  dur=random.uniform(.1,120); w=random.choice([240,320,720,1080,1920,3840]); h=random.choice([180,320,720,1080,2160]);
  frames=[{'time':random.uniform(0,dur),'motion':random.random(),'brightness':random.random(),'contrast':random.random()} for _ in range(random.randint(0,12))]
  objs=[{'x':random.uniform(0,w),'y':random.uniform(0,h),'w':random.uniform(1,max(2,w/2)),'h':random.uniform(1,max(2,h/2)),'confidence':random.random(),'label':random.choice(['person','car','product'])} for _ in range(random.randint(0,4))]
  r=p.run(dur,w,h,frames,objs,target=random.choice([(9,16),(16,9),(1,1),(4,5)]),available_runtimes=random.choice([('cpu',),('cuda','cpu'),('migraphx','cpu')]))
  assert r['runtime'] in ('cpu','cuda','migraphx') and r['quality']['ok']
  # Stage 2 regression contract
  vm=s2.run({'duration':dur,'fps':30,'width':w,'height':h},[],[]); assert vm['edit_plan']['safety']['source_preserved']
 print('randomized_stage2_stage3_10k=PASS')
 # provider/detection adversarial
 bad=[None,{}, {'x':'x'}, {'x':0,'y':0,'w':1,'h':1,'confidence':float('nan')},{'x':0,'y':0,'w':1,'h':1,'confidence':2}]
 for _ in range(N): assert det.detect(random.choice(bad))==[]
 print('detection_adversarial_10k=PASS')
 # cancellation / queue / exceptions
 sch=ResponsiveScheduler(workers=4,max_queue=20000)
 fs=[sch.submit(lambda x:x+1,i) for i in range(N)]
 assert sum(f.result() for f in fs)==N*(N+1)//2
 sch.shutdown(); print('scheduler_result_10k=PASS')
 sch=ResponsiveScheduler(workers=2,max_queue=100)
 fs=[sch.submit(lambda: time.sleep(.001),priority=1) for _ in range(100)]
 cancelled=0
 for f in fs[50:]:
  if f.cancel(): cancelled+=1
 sch.shutdown(wait=True,cancel_pending=True); assert cancelled>=0
 print('scheduler_cancellation=PASS')
 print('ultra_elapsed_s=%.3f'%(time.perf_counter()-t))
main()
