import os,time,random,math,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from stage3.pipeline import Stage3Pipeline
from stage3.tracking import PersistentTracker
from stage3.intelligence import VisualIntelligence
from stage3.runtime import LRUCache,DependencyGraph,ModelRouter

N=10000
random.seed(303)

def assert_finite(obj):
    if isinstance(obj,float): assert math.isfinite(obj)
    elif isinstance(obj,dict):
        for v in obj.values(): assert_finite(v)
    elif isinstance(obj,list):
        for v in obj: assert_finite(v)

def main():
    t=time.perf_counter()
    vi=VisualIntelligence(sample_cap=240)
    frames=[{'time':1.0,'motion':.7,'brightness':.5,'contrast':.8},{'time':0.0,'motion':.1,'brightness':.4,'contrast':.2},{'time':2.0,'motion':.9,'brightness':.9,'contrast':.7}]
    objs=[{'x':100,'y':50,'w':200,'h':150,'confidence':.95,'label':'person'}, {'x':350,'y':80,'w':120,'h':90,'confidence':.8,'label':'car'}]
    for i in range(N):
        sig=vi.frame_signals(frames,10); assert len(sig)==3 and sig[0]['time']==0
        cuts=vi.shot_boundaries(sig); assert all(x>=0 for x in cuts)
        zones=vi.attention_zones(objs,720,1280); crop=vi.safe_reframe(zones,9,16); assert 0<=crop['x']<=1 and 0<=crop['y']<=1
        assert_finite(crop)
    print('visual_10k=PASS')

    tr=PersistentTracker()
    for i in range(N):
        r=tr.update([{'x':10+i%3,'y':20,'w':100,'h':100,'confidence':.9,'label':'person'}]); assert r and r[0]['track_id']==1
    print('tracking_10k=PASS')

    p=Stage3Pipeline()
    expected=None
    for i in range(N):
        r=p.run(10,720,1280,frames,objs,available_runtimes=('cuda','cpu'))
        assert r['runtime']=='cuda' and r['affected_on_tracking_change']==['attention','reframe','tracking','validation','virtual_camera']
        assert r['tracks'][0]['track_id']==1
        sig=repr(r)
        if expected is None: expected=sig
        else: assert sig==expected
    print('pipeline_10k=PASS')

    c=LRUCache(2)
    for i in range(N):
        c.put(i,i); assert c.get(i)==i
    g=DependencyGraph(); g.set('b',['a']);g.set('c',['b']);g.set('d',['x']); assert g.affected(['a'])==['a','b','c']
    router=ModelRouter()
    for _ in range(N): assert router.route(['cpu'])=='cpu'; assert router.route(['migraphx','cpu'])=='migraphx'; assert router.route(['tensorrt','cuda'])=='tensorrt'
    print('runtime_10k=PASS')

    bad=[None,{}, {'time':float('nan'),'motion':float('inf')}, {'x':-1,'y':0,'w':0,'h':2,'confidence':99}]
    for _ in range(N):
        assert vi.frame_signals(bad,10)==[]
        assert tr.update(bad)==[] or isinstance(tr.update(bad),list)
    print('adversarial_10k=PASS')
    print('elapsed_s=%.3f'%(time.perf_counter()-t))
main()
