import sys
sys.path.insert(0,'.')
from stage4.transcript import TranscriptEngine
te=TranscriptEngine(); langs=['en','hi','hinglish','Hindi','English','bn','mr','ta','te','gu','pa','ur','xx',None]
for i in range(10000):
    x=te.normalize_language(langs[i%len(langs)])
    assert x is None or isinstance(x,str)
print('STAGE4_LANGUAGE_10K_PASS')
