import sys
sys.path.insert(0,'.')
from stage4.commands import TextCommandPlanner
p=TextCommandPlanner(); cmds=['make captions cinematic','make captions smaller','highlight important words','remove filler words','use hindi subtitles','make bilingual captions','avoid face','make captions subtle','static captions','nonsense command']
for i in range(10000):
    r=p.plan(cmds[i%len(cmds)]); assert isinstance(r['actions'],list) and 0<=r['confidence']<=1
print('STAGE4_COMMANDS_10K_PASS')
