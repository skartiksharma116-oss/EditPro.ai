import sys,random,math
sys.path.insert(0,'.')
from stage4.pipeline import Stage4Pipeline
p=Stage4Pipeline(); random.seed(4)
for i in range(10000):
    n=1+(i%24); words=[]; t=0.05
    for j in range(n):
        d=0.08+(j%5)*0.03; text=['hello','EditPro','AI','works','great','today'][j%6]
        words.append({'text':text,'start':t,'end':t+d,'confidence':0.75+((i+j)%25)/100}) ; t+=d+0.03
    r=p.run(words,t+0.2,'en',command='make captions cinematic and highlight important words')
    assert r['captions'] and r['qa']['ok']
print('STAGE4_FOUNDATION_10K_PASS')
