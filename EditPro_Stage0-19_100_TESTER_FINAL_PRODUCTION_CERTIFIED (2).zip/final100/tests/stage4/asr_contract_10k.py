import sys
sys.path.insert(0,'.')
from stage4.asr import ASRRegistry,ASRConfig
r=ASRRegistry()
for i in range(10000):
    name=('whisper-large-v3-turbo','qwen3-asr-1.7b')[i%2]
    p=r.get(name); assert p is not None and p.name==name
    assert isinstance(p.available(),bool)
print('STAGE4_ASR_CONTRACT_10K_PASS')
