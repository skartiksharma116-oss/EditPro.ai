import sys
sys.path.insert(0,'.')
from stage4.pipeline import Stage4Pipeline
p=Stage4Pipeline()
for i in range(10000):
    words=[{'text':'Hello','start':0.1,'end':0.5,'confidence':0.95},{'text':'EditPro','start':0.55,'end':1.0,'confidence':0.96},{'text':'AI','start':1.05,'end':1.35,'confidence':0.97}]
    r=p.run(words,2.0,'en',visual_context={'occupied_zones':[{'x':.5,'y':.86}]},command='make captions cinematic and avoid face',available=('cpu',))
    assert r['non_destructive'] and r['provider_route'] in ('whisper-large-v3-turbo','whisper-large-v3','qwen3-asr-1.7b','parakeet-tdt','canary-qwen')
    assert r['qa']['ok']
print('STAGE4_INTEGRATION_10K_PASS')
