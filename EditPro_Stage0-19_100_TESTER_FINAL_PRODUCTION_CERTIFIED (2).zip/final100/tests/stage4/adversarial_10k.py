import sys,random,math
sys.path.insert(0,'.')
from stage4.transcript import TranscriptEngine
from stage4.captions import CaptionDirector
from stage4.qa import CaptionCritic
te=TranscriptEngine(); cd=CaptionDirector(); qa=CaptionCritic()
random.seed(44)
for i in range(10000):
    bad=[None,{}, {'text':'','start':0,'end':1}, {'text':'x','start':-1,'end':1},{'text':'x','start':2,'end':1},{'text':'x','start':0,'end':float('nan')},{'text':'x','start':0,'end':float('inf')}][i%7]
    try: te.normalize_words([bad],3)
    except ValueError: pass
    else: raise AssertionError('malformed input unexpectedly accepted')
    r=qa.review([]); assert r['ok']
print('STAGE4_ADVERSARIAL_10K_PASS')
