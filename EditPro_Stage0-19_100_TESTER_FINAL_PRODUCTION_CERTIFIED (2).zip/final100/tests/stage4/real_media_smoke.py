import sys,subprocess
from pathlib import Path
sys.path.insert(0,'.')
from ai.speech import SpeechWorker
p=Path('fixtures/real_speech.wav'); w=SpeechWorker(); d,r=w.analyze_audio(p); assert d>0 and 0<=r<=1
print('STAGE4_REAL_AUDIO_SMOKE_PASS',round(d,3),round(r,3))
