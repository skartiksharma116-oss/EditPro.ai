import sys
sys.path.insert(0,'.')
from stage4.router import SpeechRouter
r=SpeechRouter()
for i in range(10000):
    avail=[('cpu',),('cloud','cpu'),(),('cuda','cpu'),('migraphx','cpu')][i%5]
    p=r.choose(['en','hi',None][i%3],avail,privacy=['balanced','local'][i%2]); assert p.name
print('STAGE4_PROVIDER_10K_PASS')
