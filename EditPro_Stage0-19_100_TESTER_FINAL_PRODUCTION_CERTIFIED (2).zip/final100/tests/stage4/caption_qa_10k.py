import sys
sys.path.insert(0,'.')
from stage4.pipeline import Stage4Pipeline
p=Stage4Pipeline()
for i in range(10000):
    words=[]; t=0.1
    for j in range(4): words.append({'text':'word','start':t,'end':t+.3,'confidence':.9}); t+=.35
    r=p.run(words,t+1,'en',visual_context={'occupied_zones':[{'x':.5,'y':.86}]}); assert r['qa']['ok']
    assert all(0<=c['position']['x']<=1 and 0<=c['position']['y']<=1 for c in r['captions'])
print('STAGE4_CAPTION_QA_10K_PASS')
