import sys,threading,time,json,urllib.request
sys.path.insert(0,'.')
from backend.stage4_ui_server import create_server
s=create_server(port=8796); th=threading.Thread(target=s.serve_forever,daemon=True); th.start(); time.sleep(.05)
payload={'duration':2,'words':[{'text':'hello','start':.1,'end':.5,'confidence':.9},{'text':'world','start':.55,'end':.9,'confidence':.9}]}
for i in range(10000):
    req=urllib.request.Request('http://127.0.0.1:8796/api/stage4/analyze',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=3) as r:
        assert r.status==200
s.shutdown(); print('STAGE4_UI_10K_PASS')
