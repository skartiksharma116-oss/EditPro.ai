from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import random
from stage9_cinematography import Stage9Pipeline, CapabilityRegistry, ShotCandidate

p=Stage9Pipeline(); checks=0
cmds=['cinematic person video','emotional dialogue interview','fast viral car reel','luxury product cinematic','epic landscape trailer','calm documentary','romantic face story','dramatic action character','beat synced energetic reel']
for i in range(5000):
    r=random.Random(i); duration=r.randint(1,900); fps=r.choice([1,12,24,25,30,60,120]); fmt=r.choice(['square','portrait','landscape','reel','story','youtube'])
    visual=[{'label':r.choice(['person','face','car','product','landscape']),'confidence':r.random(),'x':r.random(),'y':r.random(),'w':r.random(),'h':r.random(),'importance':r.random(),'motion':r.random()}]
    plan=p.plan(cmds[i%len(cmds)],visual=visual,speech={'transcript':[{'text':'hello'}],'segments':[{'start':0,'end':min(1,duration/fps)}]},media={'duration':max(.01,duration/fps),'fps':fps},fps=fps,duration_frames=duration,target_format=fmt,timeline={'music_beats':[0.5,1.0,1.5],'beats':[{'start':0,'end':min(duration,30),'kind':'hook','intensity':.9}]})
    plan.validate(); assert plan.shots[0].start==0 and plan.shots[-1].end==duration and p.inspect(plan)['coverage_ratio']==1
    checks+=1
for i in range(10000):
    a=p.plan('cinematic person video',visual=[{'label':'person','confidence':.9,'x':.4,'y':.5}],media={'duration':3},fps=30,duration_frames=90,target_format='landscape')
    b=p.plan('cinematic person video',visual=[{'label':'person','confidence':.9,'x':.4,'y':.5}],media={'duration':3},fps=30,duration_frames=90,target_format='landscape')
    assert a.digest==b.digest
    checks+=1
for bad in ['',None,'   ']:
    try: p.plan(bad)
    except ValueError: checks+=1
    else: raise AssertionError
try: ShotCandidate('x',0,1,scale='bad').validate(); raise AssertionError
except ValueError: checks+=1
print('STAGE9_FINAL_AUDIT_PASS checks='+str(checks))
print('CAPABILITIES='+repr(CapabilityRegistry.available()))
