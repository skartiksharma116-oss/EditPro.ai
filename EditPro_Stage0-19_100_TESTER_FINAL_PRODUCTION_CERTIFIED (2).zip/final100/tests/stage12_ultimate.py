import math, random, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from stage12_asset_studio import *

rng=random.Random(121212)
lib=AssetLibrary([AssetRecord('hero',kind='image',license_class='user_owned',width=1920,height=1080,metadata=AssetMetadata(tags=['hero','thumbnail'],objects=['person']))])
p=Stage12Pipeline(lib)
checks=0
for i in range(100000):
    w=rng.randint(1,4096); h=rng.randint(1,4096); dur=rng.uniform(.001,120)
    a=AssetRecord(f'x{i}',kind='generated',license_class='app_approved',width=w,height=h,duration=dur)
    a.validate(); checks+=1
    q=p.plan('make asset',dur,rng.choice(tuple(FORMATS)),asset_ids=['hero'],edits=[{'operation':rng.choice(tuple(EDIT_OPS))}])
    assert q.digest and p.inspect(q)['ok']; checks+=1
# malformed boundaries
for bad in [lambda: AssetRecord('x',width=1.2),lambda: AssetRecord('x',height=True),lambda: AssetRecord('x',version=0),lambda: EditRequest('NOPE').validate(),lambda: AssetPlan('x',1,'NOPE').validate()]:
    try: bad(); raise AssertionError('malformed input accepted')
    except ValueError: checks+=1
# provider exhaustion and real versioning
p2=Stage12Pipeline(AssetLibrary([AssetRecord('a',width=10,height=10)]),providers=[])
r1=p2.apply_edit('a',{'operation':'resize'}); r2=p2.apply_edit('a',{'operation':'resize'})
assert r1.output_id != r2.output_id and len(p2.library.assets)==3; checks+=3
print(f'STAGE12_ULTIMATE_PASS checks={checks}')
