from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import random
from orchestration.core import ResourceProfile
from orchestration.advanced import AdvancedOrchestrator
from orchestration.intelligence import AdaptiveCreativeEngine

VIDEOS=[
 {'codec':'h264','width':1920,'height':1080,'fps':30,'duration_s':15,'speech':True},
 {'codec':'hevc','width':3840,'height':2160,'fps':60,'duration_s':600,'speech':True,'hdr':True,'bit_depth':10,'resolution_class':'4k'},
 {'codec':'av1','width':7680,'height':4320,'fps':30,'duration_s':3600,'speech':False,'resolution_class':'8k'},
 {'codec':'vp9','width':1080,'height':1920,'fps':120,'duration_s':90,'speech':True,'portrait':True,'resolution_class':'1080p'},
 {'codec':'prores','width':4096,'height':2160,'fps':24,'duration_s':240,'speech':True,'music':True,'resolution_class':'4k'},
 {'codec':'h264','width':1080,'height':1080,'fps':29.97,'duration_s':45,'speech':True,'noisy_audio':True,'resolution_class':'1080p'},
 {'codec':'h265','width':1280,'height':720,'fps':24,'duration_s':3,'speech':False},
 {'codec':'av1','width':2560,'height':1440,'fps':144,'duration_s':1200,'speech':True,'music':True},
]
POWERS=[
 ResourceProfile('cpu-low',cpu=True,max_workers=1,memory_mb=1024),
 ResourceProfile('cpu-high',cpu=True,max_workers=8,memory_mb=16384),
 ResourceProfile('nvidia',cpu=True,cuda=True,tensorrt=True,max_workers=8,memory_mb=32768),
 ResourceProfile('amd',cpu=True,migraphx=True,max_workers=8,memory_mb=32768),
 ResourceProfile('intel',cpu=True,openvino=True,max_workers=8,memory_mb=16384),
 ResourceProfile('apple',cpu=True,coreml=True,max_workers=8,memory_mb=16384),
 ResourceProfile('webgpu',cpu=True,webgpu=True,max_workers=4,memory_mb=8192),
 ResourceProfile('cloud',cpu=True,cloud=True,max_workers=16,memory_mb=65536),
]
COMMANDS=['make this cinematic','make it funny with memes','clean audio and translate to hindi','reframe and follow the subject','make captions','add vfx','sync music to beats','make this fast','make it cinematic and funny','']

def run():
    rng=random.Random(440417)
    for i in range(10000):
        media=dict(rng.choice(VIDEOS)); media['duration_s']=rng.choice([media['duration_s'],1,2,59.9,120,121,9999])
        profile=rng.choice(POWERS)
        base=AdvancedOrchestrator(profile=profile)
        engine=AdaptiveCreativeEngine(base)
        req={'project_id':f'project-{i%31}','media':media,'command':rng.choice(COMMANDS),
             'priority':rng.choice(['quality','speed','cost']),'privacy':rng.choice(['local','balanced']),
             'max_competitors':rng.choice([1,2,3]),'max_repairs':rng.choice([0,1,2]),
             'chunk_s':rng.choice([30,60,120,300])}
        if i%9==0: req['remember']={'style':rng.choice(['cinematic','clean','high-energy']), 'privacy':rng.choice(['local','balanced'])}
        if i%17==0: req['observations']=[{'worker':'demo','media_class':'h264-1080p-sdr-speech','resource':profile.name,'quality':.91,'latency':.2,'success':True,'real_execution':True}]
        out=engine.execute(req)
        assert out['ok']
        assert len(out['jobs'])<=64
        assert 0<=out['outcome']['score']<=1
        assert len(out['creative_orchestration_fingerprint'])==64
        for j in out['jobs']:
            assert 0<=float(j.get('score',0))<=1
            assert isinstance(j.get('issues',[]),list)
            if j.get('provider') is None: assert j.get('status')=='deferred'
        if i%97==0:
            assert len(out['council'])<=64
    # malformed and bounded memory tests
    eng=AdaptiveCreativeEngine(AdvancedOrchestrator())
    try: eng.execute(None); raise AssertionError('None accepted')
    except ValueError: pass
    try: eng.execute({'media':{'width':0,'height':10,'fps':30,'duration_s':1}}); raise AssertionError('bad media accepted')
    except ValueError: pass
    return 'PASS 10,000 mixed creative-intelligence cycles + malformed/boundary checks'

if __name__=='__main__': print(run())
