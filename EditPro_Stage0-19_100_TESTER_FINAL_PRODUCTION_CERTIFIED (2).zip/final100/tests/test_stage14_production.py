from stage14_production_intelligence import Stage14ProductionIntelligence


def test_stage14_basic_plan():
    e = Stage14ProductionIntelligence()
    r = e.plan("make a premium cinematic reel with captions and music", {"speech": True, "music": True})
    assert r["ok"] is True
    caps = set(r["capabilities"])
    assert {"speech.asr", "vision.tracking", "color.management", "vfx", "render.cpu", "critic.ai", "audio.music", "search.project", "memory.project"}.issubset(caps)
    assert r["coverage"]["requested_capabilities"] == len(r["jobs"])


def test_schema_is_complete_for_every_job():
    e = Stage14ProductionIntelligence()
    r = e.plan("legendary cinematic reel", {"speech": True})
    for job in r["jobs"]:
        assert set(e.REQUIRED_JOB_FIELDS).issubset(job)
        assert job["status"] in {"contract", "planned", "deferred"}
        assert 0 <= job["score"] <= 1
        assert isinstance(job["alternatives"], list)
        assert "execution" in job


def test_installed_runtime_changes_execution_boundary():
    e = Stage14ProductionIntelligence()
    a = e.plan("captions", {"speech": True}, installed=())
    b = e.plan("captions", {"speech": True}, installed=("cpu-render", "whisper-large-v3-turbo"))
    ja = next(x for x in a["jobs"] if x["capability"] == "speech.asr")
    jb = next(x for x in b["jobs"] if x["capability"] == "speech.asr")
    assert jb["winner"] == "whisper-large-v3-turbo"
    assert jb["execution"]["mode"] == "contract"  # catalog entry is not falsely executable
    assert ja["execution"]["external_claim_allowed"] is False


def test_cpu_render_can_be_explicitly_executed():
    e = Stage14ProductionIntelligence()
    r = e.plan("premium reel", {"speech": False}, installed=("cpu", "cpu-render"))
    j = next(x for x in r["jobs"] if x["capability"] == "render.cpu")
    assert j["status"] == "planned"
    assert j["execution"]["mode"] == "executed"
    assert j["execution"]["external_claim_allowed"] is True


def test_failure_injection_repairs_to_alternative():
    e = Stage14ProductionIntelligence()
    r = e.plan("premium cinematic reel", {"speech": True}, failure_inject=("yolo-detect",))
    j = next(x for x in r["jobs"] if x["capability"] == "vision.detection")
    assert j["winner"] != "yolo-detect"
    assert j["repaired"] is True
    assert r["repair_count"] >= 1


def test_replay_is_exact():
    e = Stage14ProductionIntelligence()
    r = e.plan("private offline cinematic reel", {"speech": True, "noisy_audio": True})
    replay = e.replay(r)
    assert replay["valid"] is True
    assert replay["match"] is True


def test_dependency_and_privacy_controls():
    e = Stage14ProductionIntelligence()
    r = e.plan("private offline cinematic reel", {"speech": True}, dependency_gap=("vision.segmentation",))
    j = next(x for x in r["jobs"] if x["capability"] == "vision.segmentation")
    assert "dependency-gap" in j["issues"]
    assert "privacy-local-preference" not in j["issues"]  # local providers are preferred
    assert r["privacy_policy"]


def test_matrix_and_stress_are_deterministic():
    e = Stage14ProductionIntelligence()
    cases = [
        {"name": "cinematic", "command": "premium cinematic reel with captions and music", "media": {"speech": True, "music": True}},
        {"name": "offline", "command": "private offline edit", "media": {"speech": True, "noisy_audio": True}},
        {"name": "restoration", "command": "best fast edit", "media": {"speech": False, "low_resolution": True, "interpolation": True}},
        {"name": "repair", "command": "legendary cinematic reel", "media": {"speech": True}, "failure_inject": ("yolo-detect",)},
    ]
    matrix = e.audit_matrix(cases)
    assert matrix["failed"] == 0
    stress = e.stress("premium cinematic reel with captions", {"speech": True}, iterations=2000)
    assert stress["failed"] == 0
    assert stress["deterministic"] is True


def test_upstream_fingerprint_is_inside_stage14_contract():
    e = Stage14ProductionIntelligence()
    r = e.plan("premium reel", {"speech": False}, upstream_fingerprint="abc123")
    assert r["handoff"]["upstream_fingerprint"] == "abc123"
    assert e.replay(r)["match"] is True
