import sys,random,math,threading,concurrent.futures
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ai.production_pipeline import ProductionStage2
from ai.providers import SafeProvider
from ai.analyzer import VideoUnderstandingEngine
from ai.director import EditingDirector
from ai.validation import clean_meta,clean_interval
from ai.accel import detect_accelerators
from ai.rocm_backend import detect as detect_rocm

random.seed(20260902)
# 10k x 6 independent dimensions = 60k logical cases.
for i in range(10000):
    meta={'duration':random.choice([0,0.001,1,30,3600,7200,float('nan'),float('inf'),-1,None]),'fps':random.choice([0,1,23.976,24,30,60,120,240,float('nan')]),'width':random.choice([0,1,180,720,1920,3840,7680,-1,float('inf')]),'height':random.choice([0,1,180,1080,2160,4320,-1,float('nan')])}
    tx=[{'text':random.choice(['','hello','important however','x'*10000]),'start':random.choice([-100,0,1,1e9,float('nan')]),'end':random.choice([-1,0,2,1e9,float('inf')])}]
    scenes=[{'start':random.choice([-100,0,1]),'end':random.choice([0,1,100,1e9]),'label':'z'*random.randint(0,1000)}]
    r=ProductionStage2().run_from_signals(clean_meta(meta),[],type('S',(),{'transcript':tx})(),random.choice(['balanced','fast','cinematic','social','clean','bad',None]))
    assert r['edit_plan']['safety']['source_preserved']
print('60,000 logical malformed/limit cases: PASS')

# 10k concurrent tiny analyzer/director jobs.
p=ProductionStage2(); base={'duration':10,'fps':30,'width':1920,'height':1080}
def job(i):
    r=p.run_from_signals(base,[],type('S',(),{'transcript':[{'text':'important point','start':i%9,'end':min(10,i%9+1)}]})(),'social')
    return r['edit_plan']['safety']['source_preserved']
with concurrent.futures.ThreadPoolExecutor(max_workers=32) as ex:
    assert all(ex.map(job,range(10000)))
print('10k concurrent pipeline jobs: PASS')

# 10k provider contract mutations.
for i in range(10000):
    mode=i%5
    def f(x,mode=mode):
        if mode==0:return {'ok':1}
        if mode==1:return None
        if mode==2:return []
        if mode==3:raise ValueError()
        return {'x':'a'*1000}
    r=SafeProvider('x',f).run({'i':i}); assert r.ok==(mode in (0,4))
print('10k provider contract mutations: PASS')

# 10k accelerator truthfulness checks.
for _ in range(10000):
    a=detect_accelerators(); assert all(x in {'rocm','cuda','oneapi'} for x in a)
    g=detect_rocm(); assert g.backend in {'rocm','cpu'} and isinstance(g.available,bool)
print('10k accelerator truthfulness checks: PASS')
