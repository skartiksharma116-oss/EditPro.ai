import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from ai.external_validation import GPUContractLab, CloudAILab, DeviceFarmLab
from ai.plugin_registry import PluginRegistry, PluginSpec
from ai.cloud import CloudWorker
import random

def main():
    # GPU contract alternatives: 10k each
    for backend in (GPUContractLab.nvidia(), GPUContractLab.amd()):
        for i in range(10000):
            r=backend.run({'job':i})
            assert r.ok and r.data.get('ok') is True
    # Cloud AI healthy/fault shapes: 10k each
    healthy=CloudAILab.healthy()
    for i in range(10000):
        assert healthy.run({'request_id':i}).ok
    for backend in (CloudAILab.failing(),):
        for i in range(10000):
            r=backend.run({'request_id':i})
            assert not r.ok and r.error
    # Device farm contract matrix: 10k per platform, multiple device classes
    devices={'android':['low','mid','flagship'],'ios':['older','current'],'web':['desktop','tablet']}
    for platform, ds in devices.items():
        for i in range(10000):
            d=ds[i%len(ds)]
            assert DeviceFarmLab.run(platform,d,{'job':i}).ok
    # Plugin registry: 10k successful calls + mutation failures
    reg=PluginRegistry(); reg.register(PluginSpec('validator','1','validation',lambda p:{'ok':True,'x':p.get('x')}))
    for i in range(10000):
        assert reg.run('validation','validator',{'x':i})['ok']
    for bad in [None, [], 'x', 1]:
        try: reg.run('validation','validator',bad); raise AssertionError('bad payload accepted')
        except TypeError: pass
    # Cloud breaker semantics: 3 failed calls, each with retries, then open.
    c=CloudWorker(endpoint='http://127.0.0.1:1', timeout=.01, retries=2, breaker_limit=3)
    for _ in range(3):
        r=c.run({'x':1}); assert not r.ok and r.attempts==3
    assert c.run({'x':1}).error=='circuit_open'
    print('external alternative hardening: PASS')

if __name__=='__main__': main()
