from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import random, math
from orchestration.advanced import AdvancedOrchestrator, MediaProfile, ProgressivePlanner, BenchmarkBook
from orchestration.core import ResourceProfile

VIDEOS=[
 {'codec':'h264','width':1920,'height':1080,'fps':30,'duration_s':15,'speech':True},
 {'codec':'hevc','width':3840,'height':2160,'fps':60,'duration_s':600,'speech':True,'hdr':True,'bit_depth':10,'resolution_class':'4k'},
 {'codec':'av1','width':7680,'height':4320,'fps':30,'duration_s':3600,'speech':False,'resolution_class':'8k'},
 {'codec':'vp9','width':1080,'height':1920,'fps':120,'duration_s':90,'speech':True,'portrait':True,'resolution_class':'1080p'},
 {'codec':'prores','width':4096,'height':2160,'fps':24,'duration_s':240,'speech':True,'music':True,'resolution_class':'4k'},
 {'codec':'h264','width':1080,'height':1080,'fps':29.97,'duration_s':45,'speech':True,'noisy_audio':True,'resolution_class':'1080p'},
]
POWERS=[
 ResourceProfile('cpu-low',cpu=True,max_workers=1,memory_mb=1024),
 ResourceProfile('cpu-high',cpu=True,max_workers=8,memory_mb=16384),
 ResourceProfile('nvidia',cpu=True,cuda=True,tensorrt=True,max_workers=8,memory_mb=32768),
 ResourceProfile('amd',cpu=True,migraphx=True,max_workers=8,memory_mb=32768),
 ResourceProfile('intel',cpu=True,openvino=True,max_workers=8,memory_mb=16384),
 ResourceProfile('apple',cpu=True,coreml=True,max_workers=8,memory_mb=16384),
 ResourceProfile('webgpu',cpu=True,webgpu=True,max_workers=4,memory_mb=8192),
 ResourceProfile('cloud',cpu=True,cloud=True,max_workers=16,memory_mb=65536),
]

def run():
    rng=random.Random(400417)
    for i in range(10000):
        v=dict(rng.choice(VIDEOS)); p=rng.choice(POWERS); o=AdvancedOrchestrator(profile=p)
        if i%7==0: v['duration_s']=rng.choice([1,2,119.9,120,121,9999])
        cmd=rng.choice(['make captions','make this cinematic','make it funny with memes','reframe and follow the subject','clean audio and translate to hindi','add vfx',''])
        req={'project_id':f'p{i%17}','media':v,'command':cmd,'priority':rng.choice(['quality','speed','cost']),'privacy':rng.choice(['balanced','local']), 'max_competitors':rng.choice([1,2,3]),'chunk_s':rng.choice([30,60,120,300])}
        if i%13==0: req['remember']={'style':rng.choice(['cinematic','clean','high-energy']),'caption_size':rng.choice(['small','medium','large'])}
        out=o.execute(req)
        assert out['ok'] and out['chunks']>=1
        assert isinstance(out['orchestration_fingerprint'],str) and len(out['orchestration_fingerprint'])==64
        for j in out['jobs']:
            assert 0<=j['score']<=1
            assert j['provider'] or j['status']=='deferred'
    # Progressive boundary matrix
    pp=ProgressivePlanner()
    for d in [0.001,1,59.9,120,121,10000,36000]:
        chunks=pp.chunks(d,120,2)
        assert chunks[0][0]==0 and chunks[-1][1]>=d
    # Benchmark determinism
    b=BenchmarkBook(); b.observe('x','m','cpu',.8,.7); b.observe('x','m','cpu',.9,.9)
    f=b.factor('x','m','cpu'); assert f and .84<f['quality']<.86
    return 'PASS 10,000 mixed adaptive-orchestration cycles + boundary/benchmark matrix'
if __name__=='__main__': print(run())
