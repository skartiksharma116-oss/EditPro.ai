from __future__ import annotations
import hashlib, json, math, os, re, secrets, time, shutil, subprocess, tempfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

STAGE19_VERSION = '19.1-final-production-hardening'
PRODUCTION_MAX_FILE_BYTES = 50 * 1024 * 1024 * 1024
PRODUCTION_ALLOWED_MEDIA_EXTENSIONS = {'.mp4','.mov','.mxf','.mkv','.avi','.webm','.mts','.m2ts','.ts','.m4v','.wav','.aiff','.aif','.flac','.aac','.m4a','.mp3','.png','.jpg','.jpeg','.webp','.heif','.heic','.tif','.tiff','.exr','.psd','.psb','.svg','.pdf'}


def canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False, default=str)


def digest(obj: Any) -> str:
    return hashlib.sha256(canonical(obj).encode('utf-8')).hexdigest()


@dataclass(frozen=True)
class Capability:
    id: str
    family: str
    tier: str = 'pro'
    provider_neutral: bool = True
    editable: bool = True
    reversible: bool = True
    secure_boundary: bool = True
    alternative: str = ''


@dataclass
class Stage19Plan:
    command: str
    capabilities: list[Capability]
    security: dict[str, Any]
    parity: dict[str, Any]
    recovery: dict[str, Any]
    provenance: dict[str, Any]
    test_profile: dict[str, Any]
    upstream: dict[str, Any]
    fingerprint: str = ''


class Stage19FinalMaster:
    """Final feature/certification layer for EditPro.

    This is a provider-neutral contract layer. It never claims proprietary models,
    codecs, GPU backends, plugins, or cloud services are physically installed.
    """
    FAMILY_SPECS = {
        'editorial': ['frame_accurate','ripple_trim','roll_trim','slip_edit','slide_edit','j_cut','l_cut','match_frame','replace_edit','overwrite_edit','insert_edit','trim_history','source_program','pancake_editing','subclips','selects_reel','string_out','advanced_markers','range_markers','keyboard_customization','timeline_presets','track_targeting','sync_lock','nested_sequences','compound_clips'],
        'long_form': ['feature_film','episodic','documentary','script_to_edit','scene_act_structure','take_management','continuity_tracking','scene_metadata','rough_cut','fine_cut','long_form_index','production_notes','review_cuts','versioned_deliverables'],
        'multicam': ['large_camera_sync','timecode_sync','waveform_sync','script_sync','face_sync','speaker_sync','ai_angle_selection','manual_angle_override','reaction_shot','eyeline_continuity','angle_priority','multicam_color_lock','multicam_audio_follow','multicam_recut'],
        'media_intelligence': ['natural_language_search','transcript_search','speaker_search','face_search','object_search','scene_search','emotion_search','location_search','camera_metadata_search','lens_metadata_search','similar_shot_search','duplicate_detection','near_duplicate_detection','bad_take_detection','important_moment_detection','smart_bins','persistent_analysis_index','incremental_reindex'],
        'autopilot': ['best_footage_selection','bad_footage_rejection','dead_space_trim','story_build','pacing_optimization','transition_selection','broll_selection','caption_generation','music_sync','sound_design_suggestion','ending_selection','cta_placement','self_critique','self_repair','multi_version_generation','best_version_selection'],
        'color_finishing': ['node_graph','serial_nodes','parallel_nodes','layer_mixer','lut','cdl','asc_cdl','aces','rec709','hdr10','hlg','dolby_vision_architecture','tone_mapping','gamut_mapping','waveform','vectorscope','parade','histogram','shot_match','reference_still','ai_colorist','skin_tone_protection','32bit_float_architecture','color_management'],
        'photo_design': ['layers','smart_objects','smart_filters','adjustment_layers','clipping_masks','vector_masks','alpha_channels','paths','nondestructive_retouch','perspective_correction','lens_correction','panorama_stitch','hdr_merge','focus_stack','batch_actions','generative_layers','background_generation','generative_fill','generative_expand','generative_upscale'],
        'vfx_3d': ['3d_camera','3d_lights','3d_objects','materials','textures','hdri','reflections','shadows','depth','camera_tracking','object_tracking','planar_tracking','roto','keyer','particles','volumetrics','environment_replace','procedural_geometry','physics_proxy','deep_compositing','cryptomatte','render_passes','aov','node_compositor','composite_compare'],
        'audio_post': ['dialogue_editing','voice_isolation','music_separation','effects_separation','speaker_aware_mix','eq','compressor','limiter','deesser','gate','expander','sidechain','automation','clip_gain','lufs','true_peak','phase_analysis','surround_architecture','immersive_audio_architecture','adr','foley','sound_design','stems','mastering','audio_conform','pro_audio_roundtrip'],
        'music_director': ['bpm_analysis','beat_map','chorus_detection','drop_detection','beat_cut_sync','emotion_matching','music_selection','music_trim','music_retime','dialogue_ducking','music_intensity','audio_continuity'],
        'meme_director': ['context_understanding','emotion_timing','joke_timing','meme_necessity','relatability_score','frequency_control','tone_protection','approved_source_contract','automatic_placement','automatic_sync','meme_quality_gate'],
        'generation': ['text_to_video','image_to_video','video_to_video','text_to_image','inpaint','outpaint','background_generation','object_replace','object_remove','scene_generation','broll_generation','character_animation','motion_transfer','lip_sync','camera_generation','vfx_generation','frame_extend','temporal_repair','identity_consistency','style_consistency','reference_conditioning'],
        'reference_editing': ['reference_image','reference_video','reference_color','reference_composition','reference_character','reference_camera','reference_style','reference_typography','copy_vs_not_copy_constraints'],
        'platform': ['reels','shorts','youtube','stories','square','landscape','cinema','commercial','podcast','documentary','gaming','wedding_event','news','education','auto_reframe','subject_protection','caption_reposition','safe_zones','platform_pacing','platform_export'],
        'localization_accessibility': ['translation','multilingual_subtitles','speaker_aware_captions','caption_qc','audio_description','language_typography','terminology_lock','localized_graphics','lip_sync_architecture','cultural_adaptation','accessibility_qc','keyboard_navigation','flashing_warning','contrast_readability'],
        'media_interchange': ['xml','aaf','edl','omf','otio','psd','psb','ai','svg','pdf','tiff','exr','png','jpeg','webp','heif','mp4','mov','mxf','mkv','wav','aiff','flac','aac','image_sequences','codec_architecture','proxy_workflow','offline_online','relink','conform'],
        'compute': ['cpu_backend','amd_rocm_bridge','nvidia_cuda_bridge','apple_metal_bridge','intel_oneapi_bridge','opencl_bridge','sycl_bridge','cpu_gpu_mixed','multi_gpu_scheduler','gpu_memory_manager','low_memory_mode','thermal_policy','power_policy','device_probe','hardware_fallback','streaming_chunks','partial_render','crash_recovery'],
        'plugins_automation': ['openfx','native_plugin_api','ai_worker_api','import_plugin_boundary','export_plugin_boundary','effect_plugin_boundary','transition_plugin_boundary','python_api','javascript_automation','macros','batch_jobs','watch_folders','event_triggers','conditional_workflows','custom_panels','custom_nodes','template_api','plugin_manifest','capability_probe','plugin_sandbox','plugin_version_gate'],
        'collaboration': ['project_sharing','sequence_locking','bin_locking','conflict_detection','comments','review','approval','version_compare','rbac','shared_storage','remote_workflow','admin_controls','change_history'],
        'security_identity': ['mfa','passkeys_architecture','session_security','device_management','rbac','least_privilege','privilege_separation','reauthentication','secure_logout','revocation'],
        'security_data_app': ['encryption_transit','encryption_rest','key_management','secret_isolation','token_protection','project_isolation','temp_file_protection','secure_delete','encrypted_backup','input_validation','injection_prevention','path_traversal','command_isolation','upload_validation','malformed_media_guard','resource_limits','ssrf_guard','csrf_guard','xss_guard','secure_config'],
        'security_ai_plugin': ['prompt_injection_resistance','malicious_file_isolation','untrusted_output_sandbox','ai_worker_permissions','model_trust_boundary','tool_permission_boundary','generated_file_validation','protected_assets','approval_gates','ai_audit_trail','ai_rollback','ai_provenance','plugin_sandbox','plugin_permissions','plugin_resource_limits','plugin_integrity'],
        'security_monitoring': ['security_event_log','failed_login_monitor','permission_change_monitor','plugin_anomaly_detection','file_integrity_monitor','dependency_scan','security_alerts','rate_limiting','abuse_detection','incident_response_hooks','account_isolation','session_isolation','project_isolation','worker_isolation','credential_rotation'],
        'supply_chain': ['dependency_inventory','sbom','dependency_pinning','vulnerability_scan','package_integrity','build_provenance','signed_release','reproducible_build_architecture','plugin_provenance','model_provenance','license_tracking'],
        'provenance_recovery': ['source_provenance','operation_provenance','model_provenance','version_history','integrity_hash','c2pa_architecture','autosave','checkpoints','snapshots','version_tree','corruption_detection','backup_verification','dependency_recovery','archive_validation','restore_testing','migration_contract','recovery_point_integrity'],
        'qc_certification': ['dropped_frame_qc','corrupt_media_qc','flicker_qc','banding_qc','clipping_qc','temporal_artifact_qc','mask_tracking_qc','audio_clipping_qc','silence_qc','loudness_qc','phase_qc','sync_qc','noise_qc','distortion_qc','story_qc','ai_qc','final_master_qc','broadcast_qc','security_qc','recovery_qc','compatibility_qc','release_gate'],
        'competitive_parity': ['premiere_parity_matrix','resolve_parity_matrix','avid_parity_matrix','final_cut_parity_matrix','top_1_percent_gap_audit','missing_feature_blocker','equivalent_or_better_classification','editpro_native_advantage_audit'],
        'release_operations': ['workspace_layouts','workspace_presets','dual_monitor_layout','color_audio_vfx_workspace','project_templates','custom_project_settings','global_preferences','autosave_preferences','cache_preferences','proxy_preferences','render_presets','export_presets','delivery_profiles','batch_export','background_render_queue','queue_priority','render_pause_resume','failed_job_retry','job_history','notification_center','health_dashboard','project_health_score','performance_dashboard','security_dashboard','license_dashboard','update_channel','offline_update_package','rollback_release','migration_assistant','compatibility_manifest','portable_project_package','diagnostic_bundle','support_bundle','privacy_controls','telemetry_opt_in','telemetry_off_switch','local_only_mode','provider_opt_in','data_retention_controls','final_release_manifest','final_build_fingerprint'],
    }

    ALTERNATIVES = {
        'amd_rocm_bridge':'OpenCL/SYCL/oneAPI-style accelerator abstraction + CPU fallback',
        'nvidia_cuda_bridge':'SYCL/OpenCL abstraction + CPU fallback',
        'apple_metal_bridge':'backend-neutral acceleration abstraction + CPU fallback',
        'intel_oneapi_bridge':'oneAPI/SYCL + OpenCL',
        'opencl_bridge':'OpenCL cross-vendor accelerator backend',
        'sycl_bridge':'SYCL cross-vendor accelerator backend',
        'openfx':'OpenFX-compatible effect boundary + native API',
        'python_api':'native Python automation boundary',
        'javascript_automation':'JS-style automation boundary',
        'custom_panels':'Qt/PySide6-style cross-platform panel architecture',
        'custom_nodes':'native node graph + procedural integration boundary',
        'template_api':'native editable template schema',
        'plugin_sandbox':'process-isolated worker sandbox',
        'plugin_version_gate':'semantic version + schema compatibility gate',
    }

    SECURITY_STANDARDS = ['OWASP Top 10:2025','OWASP ASVS 5.0','NIST SSDF 1.1','SLSA v1.2','C2PA architecture']

    def __init__(self):
        self.capabilities = self._build_registry()
        self.registry_digest = digest([asdict(c) for c in self.capabilities])

    def _build_registry(self) -> list[Capability]:
        out=[]
        for family, names in self.FAMILY_SPECS.items():
            for name in names:
                cid=f'{family}.{name}'
                alt=self.ALTERNATIVES.get(name,'')
                out.append(Capability(cid,family,alternative=alt))
        return out

    def plan(self, command: str, upstream: dict[str, Any] | None = None, media: dict[str, Any] | None = None, installed: tuple[str,...] = ()) -> dict[str, Any]:
        upstream=dict(upstream or {})
        media=dict(media or {})
        safe_command=str(command or '')[:4000]
        installed_set=set(str(x) for x in installed if isinstance(x,str))
        # Capability negotiation is explicit. A capability is not claimed physically
        # available merely because its architecture exists.
        unavailable=[]
        for c in self.capabilities:
            if c.id in installed_set or c.id.split('.',1)[-1] in installed_set:
                continue
            if c.alternative:
                unavailable.append(c.id)
        security=self._security_contract(media)
        recovery=self._recovery_contract(media)
        provenance=self._provenance_contract(upstream)
        parity=self._parity_contract()
        test_profile=self._test_profile()
        plan=Stage19Plan(safe_command,self.capabilities,security,parity,recovery,provenance,test_profile,{
            'stage18_5_fingerprint':str(upstream.get('fingerprint','')),
            'registry_digest':self.registry_digest,
            'installed_count':len(installed_set),
            'negotiated_unavailable':unavailable,
        })
        payload=asdict(plan); payload['fingerprint']=digest(payload)
        plan.fingerprint=payload['fingerprint']
        return asdict(plan)

    def _security_contract(self, media: dict[str,Any]) -> dict[str,Any]:
        return {
            'standards':self.SECURITY_STANDARDS,
            'threat_model': ['untrusted media','malicious project metadata','prompt injection','malicious plugin','dependency compromise','credential theft','resource exhaustion','path traversal','command injection','data exfiltration'],
            'data_policy': 'provider-neutral; no implicit upload; explicit provider boundary; sensitive project data isolated',
            'crypto': {'transport':'TLS architecture','storage':'AEAD/encrypted-at-rest architecture','keys':'isolated key-management boundary'},
            'permissions': ['least privilege','RBAC','worker isolation','plugin sandbox','tool allowlist','sensitive-action approval'],
            'ai_guard': ['prompt injection resistance','untrusted output validation','generated file validation','protected assets','audit trail','rollback'],
            'monitoring': ['security events','integrity events','dependency events','anomaly events','rate-limit events'],
            'containment': ['account','session','project','worker','plugin'],
            'release_policy': 'fail closed on critical security gate',
            'no_unhackable_claim': True,
        }

    def _recovery_contract(self, media: dict[str,Any]) -> dict[str,Any]:
        return {
            'autosave': True,'checkpoints':True,'snapshots':True,'rollback':True,'corruption_detection':True,
            'backup_verification':True,'dependency_recovery':True,'restore_testing':True,
            'recovery_point_integrity':True,'crash_safe_editing':True,
        }

    def _provenance_contract(self, upstream: dict[str,Any]) -> dict[str,Any]:
        return {
            'source_asset':True,'edit_operations':True,'ai_operations':True,'model_provider':True,
            'version_history':True,'export_history':True,'integrity_hash':True,'c2pa_ready':True,
            'upstream_fingerprint':str(upstream.get('fingerprint','')),
        }

    def _parity_contract(self) -> dict[str,Any]:
        products=['Premiere Pro','DaVinci Resolve','Avid Media Composer','Final Cut Pro']
        return {'targets':products,'classification':['missing','partial','equivalent','better','EditPro-native-advantage'],'must_close_major_gaps':True}

    def _test_profile(self) -> dict[str,Any]:
        return {'real_media':True,'malformed_media':True,'hostile_metadata':True,'security_fuzz':True,'stress_iterations':100000,'replay':True,'recovery':True,'cross_stage':True,'hardware_fallback':True}

    def inspect(self, plan: dict[str,Any]) -> dict[str,Any]:
        caps=plan.get('capabilities') or []
        required=['security','parity','recovery','provenance','test_profile','upstream']
        checks={k: bool(plan.get(k)) for k in required}
        checks['capability_registry_nonempty']=len(caps)>0
        checks['all_capabilities_secure_boundary']=all(bool(c.get('secure_boundary')) for c in caps if isinstance(c,dict))
        checks['all_capabilities_editable']=all(bool(c.get('editable')) for c in caps if isinstance(c,dict))
        checks['all_capabilities_reversible']=all(bool(c.get('reversible')) for c in caps if isinstance(c,dict))
        checks['fingerprint_valid']=bool(plan.get('fingerprint'))
        return {'ok': all(checks.values()),'checks':checks,'capability_count':len(caps),'registry_digest':self.registry_digest}

    def handoff(self, plan: dict[str,Any]) -> dict[str,Any]:
        return {'stage':19,'version':STAGE19_VERSION,'fingerprint':plan.get('fingerprint',''),'registry_digest':self.registry_digest,'capability_count':len(plan.get('capabilities',[])),'security_digest':digest(plan.get('security',{})),'parity_digest':digest(plan.get('parity',{})),'recovery_digest':digest(plan.get('recovery',{})),'provenance_digest':digest(plan.get('provenance',{}))}

    def validate_file(self, path: str | Path) -> dict[str,Any]:
        """Validate an imported asset before expensive processing."""
        raw=os.fspath(path)
        result={'path':str(raw),'exists':False,'is_file':False,'symlink':False,'size':0,'sha256':'','extension':Path(raw).suffix.lower(),'ok':False,'checks':{}}
        if '\x00' in raw:
            result['checks']['null_free']=False
            return result
        p=Path(raw)
        try:
            result['exists']=p.exists(); result['is_file']=p.is_file(); result['symlink']=p.is_symlink()
            if not result['exists'] or not result['is_file'] or result['symlink']:
                return result
            resolved=p.resolve(strict=True)
            result['checks']['path_safe']='..' not in p.parts
            result['checks']['extension_allowed']=result['extension'] in PRODUCTION_ALLOWED_MEDIA_EXTENSIONS
            result['size']=resolved.stat().st_size
            result['checks']['size_valid']=0 < result['size'] <= PRODUCTION_MAX_FILE_BYTES
            if not all(result['checks'].values()): return result
            h=hashlib.sha256()
            with resolved.open('rb') as f:
                for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
            result['sha256']=h.hexdigest(); result['checks']['hash_valid']=len(result['sha256'])==64
            result['ok']=all(result['checks'].values())
        except (OSError,ValueError,RuntimeError):
            return result
        return result

    def validate_media_file(self, path: str | Path) -> dict[str,Any]:
        """Validate file plus codec/container parseability when ffprobe is available."""
        result=self.validate_file(path); result['checks']['codec_probe']=False
        if not result['ok']: return result
        ffprobe=shutil.which('ffprobe')
        if ffprobe is None:
            result['checks']['codec_probe']='unavailable'; result['ok']=True; return result
        try:
            proc=subprocess.run([ffprobe,'-v','error','-show_entries','format=format_name,duration,size','-of','json',os.fspath(path)],capture_output=True,text=True,timeout=30,check=False)
            data=json.loads(proc.stdout or '{}'); fmt=data.get('format') or {}
            result['probe']={'format_name':str(fmt.get('format_name','')),'duration':float(fmt.get('duration',0) or 0),'size':float(fmt.get('size',0) or 0)}
            result['checks']['codec_probe']=proc.returncode==0 and bool(fmt.get('format_name')) and result['probe']['size']>0 and result['probe']['duration']>=0
            result['ok']=all(v is True or v=='unavailable' for v in result['checks'].values())
        except (OSError,subprocess.SubprocessError,ValueError,json.JSONDecodeError):
            result['ok']=False
        return result

    def safe_workspace_path(self, workspace: str | Path, relative: str | Path) -> Path:
        root=Path(workspace).resolve(); candidate=(root/Path(relative)).resolve()
        try: candidate.relative_to(root)
        except ValueError as exc: raise PermissionError('workspace path escapes project root') from exc
        return candidate

    def atomic_write_json(self, path: str | Path, payload: Any) -> Path:
        target=Path(path).resolve(); target.parent.mkdir(parents=True,exist_ok=True)
        fd,tmp=tempfile.mkstemp(prefix=f'.{target.name}.',suffix='.tmp',dir=str(target.parent))
        try:
            with os.fdopen(fd,'w',encoding='utf-8') as f:
                json.dump(payload,f,ensure_ascii=False,sort_keys=True,separators=(',',':')); f.flush(); os.fsync(f.fileno())
            os.replace(tmp,target)
        except Exception:
            try: os.unlink(tmp)
            except OSError: pass
            raise
        return target

    def production_health(self) -> dict[str,Any]:
        ffmpeg=shutil.which('ffmpeg'); ffprobe=shutil.which('ffprobe')
        checks={'python':True,'registry':len(self.capabilities)>=500,'ffmpeg_available':bool(ffmpeg),'ffprobe_available':bool(ffprobe),'registry_digest':bool(self.registry_digest),'security_standards':len(self.SECURITY_STANDARDS)>=5}
        return {'ok':all(checks.values()),'checks':checks,'version':STAGE19_VERSION,'capabilities':len(self.capabilities),'registry_digest':self.registry_digest}

    def security_probe(self, payload: Any) -> dict[str,Any]:
        text=canonical(payload)
        patterns=[r'\b(?:rm|del|format|shutdown|powershell|cmd\.exe)\b',r'\.\.[/\\]',r'(?i)ignore\s+(?:all\s+)?previous\s+instructions',r'(?i)exfiltrat',r'(?i)drop\s+table',r'(?i)<script\b']
        hits=[]
        for pat in patterns:
            if re.search(pat,text): hits.append(pat)
        return {'ok':not hits,'threats':hits,'action':'reject' if hits else 'allow'}

    def deterministic_replay(self, plan: dict[str,Any], repeats: int=3) -> bool:
        base={k:v for k,v in plan.items() if k!='fingerprint'}
        expected=digest(base)
        return all(digest(base)==expected for _ in range(max(1,repeats)))

    def final_gate(self, plan: dict[str,Any], regression: dict[str,Any], real_files: list[dict[str,Any]], security_failures: int=0) -> dict[str,Any]:
        inspect=self.inspect(plan)
        gates={
            'feature':inspect['ok'],
            'integration':bool(regression.get('cross_stage',False)),
            'performance':bool(regression.get('stress_pass',False)),
            'security':security_failures==0 and bool(regression.get('security_pass',False)),
            'recovery':bool(regression.get('recovery_pass',False)),
            'compatibility':bool(regression.get('compatibility_pass',False)),
            'real_media':all(x.get('ok') for x in real_files) if real_files else False,
            'provenance':bool(plan.get('provenance')),
            'release':False,
        }
        # Release is the aggregate of all prerequisite gates. Do not include the
        # release flag itself in its own all() calculation, which would make a
        # mathematically impossible self-referential gate.
        gates['release']=all(value for key,value in gates.items() if key != 'release')
        return {'ok':gates['release'],'gates':gates,'status':'FINAL_CERTIFICATION_PASS' if gates['release'] else 'HARDENING_REQUIRED'}
