# Stage 6 Scope Freeze Candidate

## Build now
VFX planning, masks/roto foundation, keying, object removal/paint/clone contracts, surface replacement, procedural/AI effect contracts, relighting, atmosphere, temporal quality, repair, provider routing, caching, non-destructive VFXPacket, Stage 5 handoff.

## Do not build in Stage 6
- Character generation/animation/pose-driven character systems (Stage 7)
- Full scene compositing/layout/3D compositing pipeline (Stage 8)
- Cinematography director/shot generation (Stage 9)
- Audio mastering/sound studio (Stage 10)
- Meme/social template engine (Stage 11)
- Full image/asset generation studio (Stage 12)
- Global style engine (Stage 13)
- Full multi-AI worker tournament expansion beyond VFX provider routing (Stage 14)
