import random, time
from stage18_5_professional_supremacy import Stage18_5ProfessionalSupremacy

def test_registry():
    s=Stage18_5ProfessionalSupremacy(); assert len(s.capabilities)>300 and len(s.capabilities)==len(set(s.capabilities))

def test_plan_and_qa():
    s=Stage18_5ProfessionalSupremacy(); p=s.plan('professional studio finish',project={'target':'timeline'},hardware={'cpu':True}); q=s.qa(p)
    assert q['status']=='PASS' and q['operation_count']<=len(s.capabilities) and p['negotiation']['unavailable_count'] + q['operation_count'] == len(s.capabilities)

def test_determinism():
    s=Stage18_5ProfessionalSupremacy(); a=s.plan('x',project={'target':'p'}); b=s.plan('x',project={'target':'p'}); assert a['fingerprint']==b['fingerprint']

def test_hardware_negotiation():
    s=Stage18_5ProfessionalSupremacy(); p=s.plan('gpu finish',hardware={'cpu':True,'rocm':True}); assert 'hardware.amd_rocm' in p['negotiation']['available'] and 'hardware.nvidia_cuda' in p['negotiation']['unavailable']

def test_tamper_reject():
    s=Stage18_5ProfessionalSupremacy(); p=s.plan('x'); p['editable']=False; assert s.qa(p)['status']=='REJECT'

def test_fuzz():
    s=Stage18_5ProfessionalSupremacy(); r=random.Random(18518); t=time.time()
    for _ in range(5000):
        p=s.plan(''.join(chr(r.randrange(32,127)) for _ in range(80)),project={'target':'project'},hardware={'cpu':True,'rocm':bool(r.randrange(2)),'cuda':bool(r.randrange(2))})
        assert s.qa(p)['status']=='PASS'
    print('5k stage18.5 fuzz:',round(time.time()-t,2),'s')
