# Stage 8 Integration Manifest

This package intentionally contains **Stage 8 only**, not the complete Stage 0–8 application.

Replace the Stage 8 implementation files in the Stage 0–7 baseline with:
- `stage8_compositor.py`
- `stage8_render.py`

The Stage 0–7 orchestrator already exposes `Stage8Pipeline`; the Stage 8 API remains backward compatible for planning, inspection, SVG rendering and scene serialization.

Additional Stage 8 tests are under `tests/`.
