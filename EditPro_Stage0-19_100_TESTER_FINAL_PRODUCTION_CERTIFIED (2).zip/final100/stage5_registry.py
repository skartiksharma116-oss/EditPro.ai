from __future__ import annotations
from dataclasses import dataclass
@dataclass(frozen=True)
class TrackingProvider:
    name:str; capability:str; quality:float; speed:float; requirements:tuple[str,...]=(); alternative:tuple[str,...]=(); reid:bool=False; segmentation:bool=False
class TrackingProviderRegistry:
    def __init__(self):
        self.providers=[
          TrackingProvider('bytetrack','mot',.90,.98,(),('botsort','nvidia-nvsort'),False),
          TrackingProvider('botsort','mot',.94,.88,(),('deepocsort','nvidia-nvdcf'),True),
          TrackingProvider('deepocsort','mot',.95,.76,(),('botsort','nvidia-deepsort'),True),
          TrackingProvider('nvidia-nvsort','mot',.94,.96,('cuda',),('nvidia-deepsort','nvidia-nvdcf'),False),
          TrackingProvider('nvidia-deepsort','mot',.97,.78,('cuda',),('nvidia-nvdcf','botsort'),True),
          TrackingProvider('nvidia-nvdcf','mot',.98,.72,('cuda',),('nvidia-deepsort','sam3-masktracker'),True),
          TrackingProvider('sam3-masktracker','mask-track',.99,.80,('cuda',),('sam2.1-masktracker','nvidia-nvdcf'),True,True),
          TrackingProvider('sam2.1-masktracker','mask-track',.98,.72,('cuda',),('sam2-masktracker','nvidia-nvdcf'),True,True),
          TrackingProvider('sam2-masktracker','mask-track',.97,.68,('cuda',),('sam2-mask','nvidia-nvdcf'),True,True),
          TrackingProvider('sam2-mask','mask-track',.96,.72,(),('sam2-masktracker','pro-matting'),False,True),
          TrackingProvider('cotracker','point-track',.95,.72,(),('tapir','kalman-iou')),
          TrackingProvider('tapir','point-track',.94,.76,(),('cotracker','kalman-iou')),
          TrackingProvider('kalman-iou','predict',.88,.99,(),('nvidia-nvsort','bytetrack')),
        ]
    def route(self,cap,profile,priority='quality',difficulty='normal',reid_required=False,segmentation_required=False):
        caps=profile.capabilities()
        cand=[p for p in self.providers if p.capability==cap and all(r in caps for r in p.requirements)
              and (not reid_required or p.reid) and (not segmentation_required or p.segmentation)]
        if not cand and (reid_required or segmentation_required):
            cand=[p for p in self.providers if p.capability==cap and all(r in caps for r in p.requirements)]
        if not cand: raise RuntimeError('no compatible tracking provider')
        if difficulty in ('severe','crowded') and any(p.reid for p in cand):
            cand=[p for p in cand if p.reid]
        key={'quality':'quality','speed':'speed','cost':'speed'}.get(priority,'quality')
        return max(cand,key=lambda p:(getattr(p,key),p.quality,p.speed))
