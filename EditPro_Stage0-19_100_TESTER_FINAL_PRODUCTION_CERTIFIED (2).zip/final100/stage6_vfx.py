from __future__ import annotations
from dataclasses import dataclass, field
from math import isfinite, sqrt
from typing import Any, Iterable


def finite(v): return isinstance(v,(int,float)) and isfinite(float(v))

def clamp01(v): return max(0.0,min(1.0,float(v)))

@dataclass(frozen=True)
class MaskPoint:
    x: float; y: float
    def valid(self): return finite(self.x) and finite(self.y)

@dataclass
class VFXMask:
    points: list[MaskPoint]
    feather: float=0.0; opacity: float=1.0; expansion: float=0.0; inverted: bool=False
    quality: float=1.0
    def validate(self):
        if not isinstance(self.points,list) or len(self.points)>100000: raise ValueError('invalid mask points')
        if len(self.points) not in (0,) and len(self.points)<3: raise ValueError('malformed mask')
        if not all(isinstance(p,MaskPoint) and p.valid() for p in self.points): raise ValueError('malformed mask')
        if not all(finite(v) for v in (self.feather,self.opacity,self.expansion,self.quality)): raise ValueError('non-finite mask')
        if self.feather<0 or self.opacity<0 or self.opacity>1 or self.quality<0 or self.quality>1: raise ValueError('invalid mask range')
        return True

@dataclass
class SurfaceTransform:
    # Homography-like 3x3 matrix, identity by default.
    matrix: tuple[float,...]=(1,0,0,0,1,0,0,0,1)
    confidence: float=1.0
    def validate(self):
        if not isinstance(self.matrix,tuple) or len(self.matrix)!=9 or not all(finite(v) for v in self.matrix): raise ValueError('invalid surface transform')
        if not finite(self.confidence) or not 0<=self.confidence<=1: raise ValueError('invalid surface confidence')
        a,b,c,d,e,f,g,h,i=self.matrix
        det=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)
        if abs(det)<1e-12: raise ValueError('degenerate surface transform')
        return True

@dataclass
class EffectSpec:
    effect_id: str
    kind: str
    parameters: dict[str,Any]=field(default_factory=dict)
    blend_mode: str='normal'
    intensity: float=1.0
    start_frame: int=0
    end_frame: int=0
    target_track_id: int|None=None
    mask: VFXMask|None=None
    surface: SurfaceTransform|None=None
    confidence: float=1.0
    generated: bool=False
    provider: str='procedural'
    def validate(self):
        if not isinstance(self.effect_id,str) or not self.effect_id or len(self.effect_id)>128: raise ValueError('invalid effect id')
        if not isinstance(self.kind,str) or self.kind not in EFFECT_KINDS: raise ValueError('unsupported effect kind')
        if not isinstance(self.parameters,dict) or any(not isinstance(k,str) or len(k)>128 for k in self.parameters): raise ValueError('invalid effect parameters')
        if self.target_track_id is not None and (not isinstance(self.target_track_id,int) or self.target_track_id<1): raise ValueError('invalid target track id')
        if not all(isinstance(x,int) for x in (self.start_frame,self.end_frame)) or self.start_frame<0 or self.end_frame<self.start_frame: raise ValueError('invalid frame range')
        if not finite(self.intensity) or self.intensity<0 or self.intensity>100: raise ValueError('invalid intensity')
        if not finite(self.confidence) or not 0<=self.confidence<=1: raise ValueError('invalid effect confidence')
        if self.mask: self.mask.validate()
        if self.surface: self.surface.validate()
        if len(self.parameters)>128: raise ValueError('too many effect parameters')
        if any(isinstance(v,(str,bytes,list,dict,tuple)) and len(v)>4096 for v in self.parameters.values()): raise ValueError('oversized effect parameter')
        return True

EFFECT_KINDS={
 'glow','neon','outline','fire','smoke','fog','dust','rain','snow','sparks','lightning','energy',
 'shockwave','particles','light_streaks','motion_trail','flash','camera_shake','directional_blur',
 'color_key','luma_key','green_screen','blue_screen','object_remove','paint','clone','screen_replace',
 'sign_replace','poster_replace','surface_graphic','background_blur','relight','light_wrap','spill_suppress',
 'mask_blur','mask_color','atmosphere','lens_haze','custom'
}

@dataclass
class VFXPacket:
    version: str='1.0'
    source_clip: str=''
    effects: list[EffectSpec]=field(default_factory=list)
    dependencies: list[str]=field(default_factory=list)
    quality: dict[str,float]=field(default_factory=dict)
    critic_issues: list[str]=field(default_factory=list)
    repair_history: list[dict[str,Any]]=field(default_factory=list)
    generated_assets: list[str]=field(default_factory=list)
    cache_key: str=''
    def validate(self):
        if self.version!='1.0' or len(self.effects)>4096 or len(self.dependencies)>4096: raise ValueError('invalid VFX packet')
        for e in self.effects: e.validate()
        if not isinstance(self.source_clip,str) or len(self.source_clip)>4096: raise ValueError('invalid source clip')
        if not all(isinstance(x,str) and x for x in self.dependencies): raise ValueError('invalid dependencies')
        if not isinstance(self.critic_issues,list) or not all(isinstance(x,str) for x in self.critic_issues): raise ValueError('invalid critic issues')
        if not isinstance(self.repair_history,list) or len(self.repair_history)>256: raise ValueError('invalid repair history')
        if not isinstance(self.generated_assets,list) or len(self.generated_assets)>4096 or not all(isinstance(x,str) for x in self.generated_assets): raise ValueError('invalid generated assets')
        for k,v in self.quality.items():
            if not isinstance(k,str) or not finite(v): raise ValueError('invalid quality metric')
        return True

class VFXPlanner:
    """Deterministic intent-to-VFX planner. It creates a safe plan; it never pretends to render unavailable generative models."""
    aliases={
      'remove':'object_remove','erase':'object_remove','clean':'object_remove','fire':'fire','flames':'fire',
      'smoke':'smoke','fog':'fog','rain':'rain','snow':'snow','lightning':'lightning','electric':'energy',
      'energy':'energy','neon':'neon','glow':'glow','outline':'outline','spark':'sparks','sparks':'sparks',
      'screen':'screen_replace','billboard':'screen_replace','sign':'sign_replace','poster':'poster_replace',
      'shake':'camera_shake','trail':'motion_trail','blur':'background_blur','relight':'relight'
    }
    def plan(self, intent:str, track_id:int|None=None, frames=(0,0), mask=None):
        if not isinstance(intent,str) or not intent.strip() or len(intent)>2000: raise ValueError('invalid intent')
        start,end=frames
        if not isinstance(start,int) or not isinstance(end,int) or start<0 or end<start: raise ValueError('invalid frame range')
        low=intent.lower(); kinds=[]
        for token,kind in self.aliases.items():
            if token in low and kind not in kinds: kinds.append(kind)
        if not kinds: kinds=['custom']
        effects=[]
        for i,k in enumerate(kinds):
            e=EffectSpec(f'vfx-{i+1}',k,{'intent':intent[:512]},start_frame=start,end_frame=end,target_track_id=track_id,mask=mask,confidence=.72)
            e.validate(); effects.append(e)
        p=VFXPacket(source_clip='',effects=effects,dependencies=['stage5.track'] if track_id is not None else [])
        p.cache_key=self.cache_key(p); return p
    @staticmethod
    def cache_key(packet):
        import hashlib,json
        def mask_data(m):
            if m is None: return None
            return {'points':[(p.x,p.y) for p in m.points],'feather':m.feather,'opacity':m.opacity,'expansion':m.expansion,'inverted':m.inverted,'quality':m.quality}
        def surface_data(s):
            return None if s is None else {'matrix':s.matrix,'confidence':s.confidence}
        raw=json.dumps({'source':packet.source_clip,'effects':[(e.effect_id,e.kind,e.start_frame,e.end_frame,e.target_track_id,e.parameters,e.blend_mode,e.intensity,e.confidence,e.provider,mask_data(e.mask),surface_data(e.surface)) for e in packet.effects],'dependencies':packet.dependencies},sort_keys=True,separators=(',',':'))
        return hashlib.sha256(raw.encode()).hexdigest()

class TemporalCritic:
    def score(self, packet:VFXPacket, observations:Iterable[dict[str,Any]]=()):
        packet.validate(); issues=[]; flicker=0; drift=0; leakage=0
        prev=None
        for o in observations:
            if not isinstance(o,dict): issues.append('malformed_observation'); continue
            q=o.get('quality',1.0); d=o.get('drift',0.0); l=o.get('leakage',0.0)
            if not finite(q) or not finite(d) or not finite(l): issues.append('nonfinite_observation'); continue
            if q<.35: flicker+=1
            if d>50: drift+=1
            if l>.5: leakage+=1
            prev=o
        score=1.0-.08*min(5,flicker)-.10*min(5,drift)-.12*min(5,leakage)
        if flicker: issues.append('temporal_instability')
        if drift: issues.append('effect_drift')
        if leakage: issues.append('mask_leakage')
        packet.quality.update({'temporal_stability':max(0,score),'artifact_score':max(0,1-.12*min(5,leakage)),'flicker_events':float(flicker),'drift_events':float(drift),'leakage_events':float(leakage)})
        packet.critic_issues=sorted(set(issues)); return {'score':max(0,min(1,score)),'issues':packet.critic_issues,'metrics':{'flicker':flicker,'drift':drift,'leakage':leakage}}

class VFXRepairEngine:
    def repair(self, packet:VFXPacket, critic:dict[str,Any], max_attempts=3):
        if max_attempts<0 or max_attempts>5: raise ValueError('invalid repair budget')
        packet.validate(); attempts=0
        original=set(critic.get('issues',[])) if isinstance(critic,dict) else set()
        actions=[]
        remaining=set(original)
        for _ in range(max_attempts):
            if not remaining: break
            attempts+=1; step=[]
            if 'temporal_instability' in remaining:
                for e in packet.effects: e.parameters['temporal_smoothing']=True
                step.append('temporal_smoothing')
            if 'effect_drift' in remaining:
                for e in packet.effects: e.parameters['reanchor']=True
                step.append('reanchor')
            if 'mask_leakage' in remaining:
                for e in packet.effects:
                    if e.mask: e.mask.expansion=max(-20,e.mask.expansion-1)
                step.append('mask_refine')
            actions.extend(step)
            packet.repair_history.append({'attempt':attempts,'actions':step})
            # No observation data is available here, so repairs are recorded as attempted, not certified.
            break
        return {'attempts':attempts,'remaining_issues':sorted(remaining),'repaired':bool(actions),'actions':actions,'certified':not remaining}

class VFXProviderRegistry:
    def __init__(self):
        self.providers=[
          ('procedural-core',('cpu',),.80),('ffmpeg-filter',('cpu',),.76),('opencv-vfx',('cpu',),.78),
          ('sam3.1-mask',('cuda',),.99),('sam2.1-mask',('cuda',),.97),('pro-matting',('cpu',),.92),
          ('nvidia-tensorrt-vfx',('cuda',),.96),('openvino-vfx',('openvino',),.88),('coreml-vfx',('coreml',),.88),
          ('webgpu-vfx',('webgpu',),.86),('cloud-generative-vfx',('cloud',),.99)
        ]
    def route(self, requirements=(), capabilities=('cpu',), quality=True):
        caps=set(capabilities); req=set(requirements)
        candidates=[p for p in self.providers if req.issubset({p[0]}) or req.issubset(set(p[1]))]
        candidates=[p for p in candidates if set(p[1]).issubset(caps) or 'cpu' in p[1] and 'cpu' in caps]
        if not candidates: return self.providers[0]
        return max(candidates,key=lambda p:p[2] if quality else -len(p[1]))
