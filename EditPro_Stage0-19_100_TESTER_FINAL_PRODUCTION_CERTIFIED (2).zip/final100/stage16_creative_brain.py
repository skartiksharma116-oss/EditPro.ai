"""Stage 16: AI Creative Director / Autopilot Intelligence.

Deterministic, provider-neutral creative intelligence layer. It converts Stage 15's
execution capabilities plus media signals into an editable, reversible, scored
creative plan. No fake pixel generation is claimed here.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json, math, re
from typing import Any

CONTRACT_VERSION = "16.2"


def digest(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


@dataclass(frozen=True)
class CreativeOperation:
    id: str
    kind: str
    target: str
    reason: str
    confidence: float
    reversible: bool = True
    protected: bool = False
    dependencies: tuple[str, ...] = ()


class Stage16CapabilityRegistry:
    FAMILIES = {
        "understanding": ["semantic_index", "natural_language_search", "visual_search", "transcript_search", "speaker_index", "object_index", "emotion_index", "duplicate_detection", "important_moment_detection"],
        "text_edit": ["transcript_to_timeline", "text_delete", "text_reorder", "filler_removal", "silence_removal", "speaker_select", "paper_edit", "rough_cut"],
        "autopilot": ["best_take_select", "bad_take_reject", "dead_space_trim", "scene_reorder", "pacing", "transition_plan", "broll_plan", "caption_plan", "music_sync", "ending_plan"],
        "story": ["hook", "build_up", "climax", "payoff", "emotional_arc", "chronology", "montage", "documentary", "trailer", "highlight"],
        "retention": ["opening_score", "attention_drop", "boring_section", "scene_density", "pause_analysis", "payoff_timing", "cta_placement"],
        "music": ["bpm_map", "beat_map", "section_detection", "beat_cut", "chorus_drop", "retime", "ducking", "dialogue_music_balance", "emotion_music_match"],
        "audio": ["dialogue_separation", "music_separation", "sfx_separation", "speaker_mix", "loudness_normalization", "room_tone", "crosstalk", "intelligent_ducking", "audio_continuity", "sound_design"],
        "meme": ["necessity_detection", "reaction_timing", "frequency_control", "context_match", "tone_protection"],
        "reference": ["reference_image", "reference_video", "reference_style", "reference_character", "reference_composition", "reference_color", "reference_diff"],
        "localized": ["object_only", "person_only", "background_only", "lighting_only", "color_only", "localized_generation", "untouched_region_lock"],
        "multishot": ["idea_to_storyboard", "shot_planning", "shot_order", "camera_continuity", "character_continuity", "environment_continuity", "lighting_continuity", "transition_continuity"],
        "director": ["creative_director", "editor_agent", "audio_agent", "vfx_agent", "meme_agent", "color_agent", "caption_agent", "critic_agent"],
        "consistency": ["style_lock", "character_lock", "color_lock", "typography_lock", "camera_language_lock", "vfx_language_lock", "audio_language_lock", "brand_lock"],
        "self_improve": ["draft", "analyze", "repair", "rescore", "version_two", "compare_versions", "best_version"],
        "human_control": ["auto_mode", "copilot_mode", "manual_mode", "asset_lock", "clip_lock", "person_lock", "music_lock", "style_lock_user", "constraint_parser", "explainable_changes", "rollback"],
        "platform": ["reel", "short", "youtube", "story", "square", "landscape", "auto_reframe", "subject_protection", "caption_safe_zone", "platform_pacing"],
        "versioning": ["cinematic_version", "energetic_version", "emotional_version", "short_version", "version_compare", "version_recommendation"],
        "safety_qa": ["protected_assets", "approval_gate", "undo_safe", "history", "story_qa", "pacing_qa", "continuity_qa", "audio_qa", "caption_qa", "framing_qa", "face_qa", "style_qa", "generation_qa", "platform_qa"],
        "editability": ["editable_results", "generation_boundaries", "source_mapping", "operation_lineage", "non_destructive_stack", "provenance_chain", "timeline_mapping", "source_clip_mapping", "mask_mapping", "parameter_mapping", "keyframe_mapping", "prompt_mapping", "model_mapping", "provider_mapping", "render_recipe", "reopen_recipe", "partial_recompute", "safe_preview", "diff_preview", "change_summary", "audit_log", "schema_versioning", "migration_recipe", "recovery_point", "dependency_map", "integrity_check"],
    }

    def __init__(self):
        self.capabilities = tuple(f"{family}.{name}" for family, names in self.FAMILIES.items() for name in names)
        self.by_name = set(self.capabilities)


class Stage16CreativeBrain:
    """Provider-neutral Stage-16 creative planning and QA contract."""
    CONTRACT_VERSION = CONTRACT_VERSION

    def __init__(self):
        self.registry = Stage16CapabilityRegistry()

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return set(re.findall(r"[a-z0-9']+", str(text).lower()))

    def parse_intent(self, command: str, media: dict[str, Any]) -> dict[str, Any]:
        c = str(command or "").lower()
        t = self._tokens(c)
        def anyof(*xs): return any(x in c for x in xs)
        fmt = str(media.get("target_format", "")).lower()
        return {
            "short_form": anyof("reel", "short", "story", "tiktok") or fmt in {"reel", "story", "short"},
            "long_form": anyof("youtube", "long video", "documentary", "podcast", "interview"),
            "cinematic": anyof("cinematic", "film", "movie", "premium", "legendary", "beast"),
            "meme": anyof("meme", "funny", "comedy", "reaction"),
            "music": anyof("music", "song", "beat", "rhythm", "bpm"),
            "dialogue": anyof("talk", "speech", "interview", "podcast", "dialogue") or bool(media.get("transcript")),
            "reference": anyof("reference", "match", "same style", "like this"),
            "generation": anyof("generate", "create", "replace", "remove", "extend", "animate", "transform"),
            "multishot": anyof("storyboard", "shots", "sequence", "scene", "multi shot"),
            "preserve": anyof("keep", "preserve", "don't change", "do not change", "untouched", "lock"),
            "platform": fmt or ("reel" if anyof("reel", "instagram") else "landscape"),
            "command_tokens": sorted(t),
        }

    @staticmethod
    def _safe_num(value, default=0.0):
        try:
            x=float(value)
            return x if math.isfinite(x) and x >= 0 else default
        except Exception:
            return default

    def _signal_index(self, media, visual, speech):
        visual = [x for x in (visual or []) if isinstance(x, dict)]
        words = [x for x in (speech or {}).get("transcript", []) if isinstance(x, dict)] if isinstance(speech, dict) else []
        labels = sorted({str(x.get("label", "")).lower() for x in visual if x.get("label")})
        speakers = sorted({str(x.get("speaker", "")).lower() for x in words if x.get("speaker")})
        text = " ".join(str(x.get("text", x.get("word", ""))) for x in words)
        def safe_int(value, default=0):
            try:
                x=float(value)
                return int(x) if math.isfinite(x) else default
            except Exception:
                return default
        return {
            "visual_count": len(visual), "word_count": len(words), "labels": labels,
            "speakers": speakers, "transcript_text_digest": digest(text),
            "duration": self._safe_num(media.get("duration", 0)),
            "resolution": [safe_int(media.get("width", 0)), safe_int(media.get("height", 0))],
        }

    def _operations(self, command, media, visual, speech, intent):
        ops=[]
        def add(kind,target,reason,confidence=.95,deps=(),protected=False):
            oid=digest([kind,target,reason,deps])[:16]
            ops.append(CreativeOperation(oid,kind,target,reason,max(0,min(1,float(confidence))),True,protected,tuple(deps)))
        add("understand","project","Build a semantic project map before editing",.99)
        add("search","media","Enable natural-language retrieval and duplicate/important-moment discovery",.96)
        if intent["dialogue"]:
            add("text_edit","transcript","Make transcript and timeline share one editable boundary",.98)
            add("edit","silences","Remove dead pauses/fillers only when they improve pacing",.94)
            add("story","rough_cut","Build a transcript-aware rough cut",.96)
        add("autopilot","timeline","Select strong takes, remove dead space and propose pacing",.97)
        if intent["music"] or intent["short_form"]:
            add("music","timeline","Align cuts to beats/sections while preserving dialogue clarity",.95)
        if intent["meme"]:
            add("meme","timeline","Use context-aware meme timing without overloading the edit",.92)
        if intent["reference"]:
            add("reference","creative_language","Separate reusable reference traits from protected source content",.95)
        if intent["generation"]:
            add("localized_edit","target_regions","Protect untouched regions and map generated changes to source regions",.96)
            add("generation","timeline","Return generated work as editable, traceable operations",.98)
        if intent["multishot"] or intent["cinematic"]:
            add("director","shots","Plan shots, continuity and visual language before execution",.97)
            add("consistency","project","Lock style, character, color and camera language",.97)
        add("qa","final","Run creative QA and repair loop before acceptance",.99)
        add("history","project","Make every AI change reversible and explainable",.99,protected=True)
        return ops

    def _score(self, ops, intent, index):
        base = 0.86
        if index["word_count"]: base += .03
        if index["visual_count"]: base += .03
        if intent["short_form"]: base += .02
        if intent["cinematic"]: base += .01
        if intent["generation"]: base += .01
        return min(.99, base + min(.04, len(ops)*.002))

    def plan(self, command: str, media: dict[str, Any], visual=None, speech=None, stage15=None, locks=None) -> dict[str, Any]:
        media = dict(media or {})
        intent = self.parse_intent(command, media)
        index = self._signal_index(media, visual, speech)
        ops = self._operations(command, media, visual, speech, intent)
        locks = sorted(set(str(x) for x in (locks or [])))
        protected = [o.target for o in ops if o.protected] + locks
        capabilities = sorted({c for c in self.registry.capabilities if c.split('.',1)[0] in {
            "understanding","text_edit","autopilot","story","retention","music","audio","director","consistency","self_improve","human_control","platform","safety_qa","editability"}})
        if intent["generation"]: capabilities += sorted(c for c in self.registry.capabilities if c.startswith(("localized.","reference.","multishot.")))
        if intent["meme"]: capabilities += sorted(c for c in self.registry.capabilities if c.startswith("meme."))
        plan={
            "contract_version":self.CONTRACT_VERSION,
            "command":str(command),"intent":intent,"signal_index":index,
            "operations":[asdict(o) for o in ops],"locks":locks,"protected_targets":sorted(set(protected)),
            "stage15_fingerprint":str((stage15 or {}).get("fingerprint", "")) if isinstance(stage15,dict) else "",
            "capabilities":sorted(set(capabilities)),
            "editable":True,"non_destructive":True,"reversible":True,
            "quality_score":self._score(ops,intent,index),
        }
        plan["fingerprint"]=digest(plan)
        return plan

    def qa(self, plan: dict[str, Any]) -> dict[str, Any]:
        issues=[]
        if not plan.get("editable"): issues.append("not-editable")
        if not plan.get("non_destructive"): issues.append("destructive-plan")
        if not plan.get("reversible"): issues.append("non-reversible")
        if not plan.get("fingerprint"): issues.append("missing-fingerprint")
        seen=set()
        for op in plan.get("operations",[]):
            if not isinstance(op,dict) or not op.get("id"): issues.append("malformed-operation"); continue
            if op["id"] in seen: issues.append("duplicate-operation-id")
            seen.add(op["id"])
            if not (0 <= float(op.get("confidence",0)) <= 1): issues.append("invalid-confidence")
            if op.get("protected") and not op.get("reversible",False): issues.append("protected-not-reversible")
        score=float(plan.get("quality_score",0) or 0)
        status="PASS" if not issues and score >= .90 else ("REPAIR" if not issues or score >= .75 else "REJECT")
        return {"ok":not issues and status=="PASS","status":status,"issues":sorted(set(issues)),"quality_score":score,
                "operation_count":len(plan.get("operations",[])),"fingerprint":plan.get("fingerprint","")}

    def inspect(self, plan):
        return self.qa(plan)

    def handoff(self, plan):
        return {"creative_digest":plan["fingerprint"],"contract_version":self.CONTRACT_VERSION,
                "editable":True,"reversible":True,"protected_targets":list(plan.get("protected_targets",[])),
                "operation_count":len(plan.get("operations",[]))}
