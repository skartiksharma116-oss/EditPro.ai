# EditPro.ai Stage 7 Scope Freeze Candidate

## Build now
- Adaptive Canva-like template/design ecosystem.
- Structured templates with reusable asset/text slots.
- AI intent -> format/category/template selection.
- Responsive/adaptive layout across social/video/print formats.
- Local deterministic SVG/layout path with no paid API dependency.
- Browser-editor integration contracts for Konva/Fabric.js and self-hosted OpenDesign.
- Browser video-composition contract via WebMotion where appropriate.
- Character-motion planning contract: walk/run/jump/wave/talk/dance/idle/turn/camera zoom.
- Safe provider routing and explicit unavailable-provider state.
- Deterministic validation, fuzzing, repair-ready contracts, caching/digests.

## Explicitly not claimed as locally available
- Proprietary cloud character generators.
- Proprietary template/stock libraries.
- Paid AI inference.
- Guaranteed commercial rights for third-party template/assets.

## Later stages
- Full 3D character generation and photoreal character animation.
- Full scene compositing/layout/3D compositing pipeline.
- Cinematography director.
- Audio mastering/sound studio.
- Meme engine.
- Full image/asset generation studio.
- Global style engine.
- Full multi-AI worker tournament.
