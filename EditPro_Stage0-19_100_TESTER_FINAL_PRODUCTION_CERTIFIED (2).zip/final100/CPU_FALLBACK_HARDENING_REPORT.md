# EditPro.ai Stage 2 CPU Fallback Hardening

The CPU path was upgraded from a minimal emergency fallback to a bounded parallel execution engine.

## Changes
- Host CPU capability detection (logical/physical cores, RAM).
- Bounded thread pool and bounded in-flight work.
- Chunking for large task lists to limit queued memory.
- Deterministic worker output for reproducible testing.
- Oversized task rejection.
- Clean shutdown and cancellation.
- Scheduler now uses the optimized CPU worker when ROCm is not genuinely available.
- Fixed two integration defects found during this hardening pass: an invalid ROCm worker import path and a missing `runtime.gpu_backend` dependency.

## Tests after fixes
- Python compileall: PASS
- 10,000 CPU varied jobs: PASS
- CPU memory-bound rejection: PASS
- CPU deterministic replay: PASS
- 1,000 scheduler CPU fallback jobs: PASS
- 10,000 mixed Analyzer/Director/CPU runs: PASS
- 10,000 scheduler dispatches: PASS
- 10,000 provider mutation runs: PASS

The host used for this test reports no physical ROCm runtime, so ROCm correctly falls back to CPU. No hardware is falsely reported.
