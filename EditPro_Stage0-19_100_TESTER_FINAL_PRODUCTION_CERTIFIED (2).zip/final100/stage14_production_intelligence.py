"""EditPro.ai Stage 14: AI Production Intelligence Engine, hardened edition.

Stage 14 is the production-intelligence/control layer above Stages 0-13.5.
It turns intent + upstream signals into a deterministic, auditable production
plan. It does not pretend an external provider executed anything unless the
caller explicitly advertises that runtime as installed/executable.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import hashlib, json, math, re
from typing import Any, Iterable


def clamp(v, lo=0.0, hi=1.0):
    try:
        x = float(v)
    except Exception:
        return lo
    return max(lo, min(hi, x)) if math.isfinite(x) else lo


def digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


@dataclass(frozen=True)
class Specialist:
    name: str
    domain: str
    capability: str
    quality: float
    speed: float
    local: bool = True
    executable: bool = False
    alternative_for: tuple[str, ...] = ()
    evidence: str = "registry"
    cost: float = 0.0
    deterministic: bool = True


@dataclass
class Candidate:
    specialist: Specialist
    score: float
    reasons: list[str] = field(default_factory=list)


class SpecialistCatalog:
    """Provider-neutral catalog. Contracts are never treated as executed runtimes."""
    def __init__(self):
        self.items = [
            Specialist("whisper-large-v3-turbo", "speech", "speech.asr", .94, .90, True, False, ("deepgram-nova-3", "parakeet-tdt"), "OpenAI Whisper MIT repo"),
            Specialist("parakeet-tdt", "speech", "speech.asr", .97, .98, True, False, ("whisper-large-v3-turbo", "canary-qwen"), "existing provider registry"),
            Specialist("deepgram-nova-3", "speech", "speech.asr", .98, .98, False, False, ("whisper-large-v3-turbo", "parakeet-tdt"), "current provider contract", .35, False),
            Specialist("yolo-detect", "vision", "vision.detection", .91, .96, True, False, ("opencv-detect", "cloud-vision"), "existing provider registry"),
            Specialist("opencv-detect", "vision", "vision.detection", .84, .97, True, True, ("yolo-detect",), "local OpenCV-style fallback"),
            Specialist("sam2.1", "vision", "vision.segmentation", .97, .74, True, False, ("yolo-seg", "pro-matting"), "existing provider registry"),
            Specialist("bytetrack", "vision", "vision.tracking", .91, .97, True, False, ("ocsort",), "existing provider registry"),
            Specialist("ocsort", "vision", "vision.tracking", .90, .92, True, False, ("bytetrack",), "existing provider registry"),
            Specialist("depth-anything", "vision", "vision.depth", .94, .75, True, False, ("video-depth-anything", "midas"), "existing provider registry"),
            Specialist("demucs", "audio", "audio.separation", .95, .78, True, False, ("meta-audio-separation",), "existing provider registry"),
            Specialist("meta-audio-separation", "audio", "audio.separation", .96, .76, True, False, ("demucs",), "existing provider registry"),
            Specialist("beat-sync-local", "audio", "audio.music", .90, .96, True, True, ("cloud-music-analysis",), "local beat/tempo analysis"),
            Specialist("realesrgan", "restoration", "image.upscale", .93, .85, True, False, ("cloud-upscale",), "existing provider registry"),
            Specialist("rife", "motion", "video.interpolation", .94, .80, True, False, ("cloud-interpolation",), "existing provider registry"),
            Specialist("opencolorio-aces", "color", "color.management", .98, .98, True, False, ("gpu-color",), "existing provider registry"),
            Specialist("blender-vfx", "vfx", "vfx", .94, .65, True, False, ("houdini-vfx", "cloud-vfx"), "existing provider registry"),
            Specialist("ffmpeg-hw", "render", "render.gpu", .97, .95, True, False, ("cpu-render",), "FFmpeg filter/encoding stack"),
            Specialist("cpu-render", "render", "render.cpu", .90, .45, True, True, (), "local deterministic fallback"),
            Specialist("multimodal-index", "search", "search.project", .94, .80, True, True, (), "existing provider registry"),
            Specialist("semantic-project-memory", "memory", "memory.project", .92, .80, True, True, (), "existing provider registry"),
            Specialist("multi-modal-critic", "critic", "critic.ai", .92, .65, True, True, (), "existing provider registry"),
        ]

    def for_capability(self, capability):
        return [x for x in self.items if x.capability == capability]


class ProductionIntent:
    def parse(self, command: str) -> dict[str, Any]:
        c = str(command or "").strip().lower()
        return {
            "cinematic": any(k in c for k in ("cinematic", "film", "movie")),
            "short_form": any(k in c for k in ("reel", "short", "shorts", "tiktok")),
            "captions": any(k in c for k in ("caption", "subtitle", "subtitles")),
            "music": any(k in c for k in ("music", "beat", "song", "soundtrack")),
            "humor": any(k in c for k in ("funny", "meme", "humor", "comedy")),
            "privacy_local": any(k in c for k in ("local", "offline", "private", "on-device")),
            "quality": 1.0 if any(k in c for k in ("premium", "legendary", "best", "ultra", "cinematic", "beast")) else .85,
            "speed_priority": any(k in c for k in ("fast", "quick", "instant")),
            "accuracy_priority": any(k in c for k in ("accurate", "precise", "perfect")),
        }


class TournamentRouter:
    def __init__(self, catalog=None):
        self.catalog = catalog or SpecialistCatalog()

    def rank(self, capability, intent, installed: Iterable[str] = (), max_candidates=4):
        installed = set(installed or ())
        out = []
        for s in self.catalog.for_capability(capability):
            score = .48*s.quality + .20*s.speed + .17*(1.0 if s.local else .25) + .10*(1.0 if s.deterministic else .4) + .05*(1.0 if s.executable else .55)
            reasons = []
            if intent.get("privacy_local") and not s.local:
                score -= .40; reasons.append("privacy-local-preference")
            if intent.get("speed_priority"):
                score += .06*s.speed; reasons.append("speed-priority")
            if intent.get("accuracy_priority"):
                score += .06*s.quality; reasons.append("accuracy-priority")
            if s.name in installed:
                score += .12; reasons.append("runtime-installed")
            if s.local:
                reasons.append("local-capable")
            if s.executable:
                reasons.append("executable-runtime")
            else:
                reasons.append("contract-until-runtime-installed")
            out.append(Candidate(s, clamp(score), reasons))
        return sorted(out, key=lambda x: (x.score, x.specialist.quality, x.specialist.name), reverse=True)[:max(1, int(max_candidates))]


class ProductionCritic:
    def review(self, candidate: Candidate, intent: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        issues = []
        score = candidate.score
        s = candidate.specialist
        if not s.executable:
            issues.append("runtime-not-executed")
        if intent.get("privacy_local") and not s.local:
            issues.append("privacy-mismatch")
        if context.get("dependency_gap"):
            issues.append("dependency-gap")
        if context.get("failure_injected"):
            issues.append("provider-failure-injected")
        if context.get("quality_gate") and score < .80:
            issues.append("quality-below-gate")
        if not s.deterministic:
            issues.append("nondeterministic-provider")
        return {
            "score": clamp(score - .05*len(issues)),
            "issues": sorted(set(issues)),
            "needs_repair": bool(issues and score < .84),
        }


class Stage14ProductionIntelligence:
    """Director -> dependency planner -> specialist tournament -> critic -> repair -> audit."""
    CAPABILITIES = (
        "vision.detection", "vision.tracking", "vision.segmentation", "vision.depth",
        "speech.asr", "audio.separation", "audio.music", "color.management",
        "image.upscale", "video.interpolation", "vfx", "search.project", "memory.project",
        "render.gpu", "render.cpu", "critic.ai",
    )
    REQUIRED_JOB_FIELDS = ("capability", "status", "winner", "score", "issues", "repaired", "alternatives", "evidence", "execution")

    def __init__(self):
        self.catalog = SpecialistCatalog()
        self.intent = ProductionIntent()
        self.router = TournamentRouter(self.catalog)
        self.critic = ProductionCritic()

    def _normalize_media(self, media):
        m = dict(media or {}) if isinstance(media, dict) else {}
        for k in ("width", "height", "fps", "duration"):
            if k in m:
                try: m[k] = max(0, float(m[k]))
                except Exception: m[k] = 0
        return m

    def _capabilities(self, command, media, intent):
        c = ["vision.detection", "vision.tracking", "vision.depth", "color.management", "search.project", "memory.project"]
        if media.get("speech", True) or intent["captions"]:
            c.append("speech.asr")
        if media.get("noisy_audio") or media.get("separation"):
            c.append("audio.separation")
        if intent["music"] or media.get("music"):
            c.append("audio.music")
        if media.get("low_resolution") or media.get("upscale"):
            c.append("image.upscale")
        if media.get("slow_motion") or media.get("interpolation"):
            c.append("video.interpolation")
        if intent["cinematic"] or media.get("segmentation") or media.get("background_change"):
            c += ["vision.segmentation", "vfx"]
        c += ["render.gpu", "render.cpu", "critic.ai"]
        return list(dict.fromkeys(c))

    def _dependencies(self, caps):
        deps = {
            "vision.tracking": ["vision.detection"],
            "vision.segmentation": ["vision.detection"],
            "vision.depth": ["vision.detection"],
            "speech.asr": [], "audio.separation": [], "audio.music": [],
            "color.management": [], "image.upscale": [], "video.interpolation": ["vision.tracking"],
            "vfx": ["vision.tracking", "vision.segmentation", "vision.depth"],
            "render.gpu": ["color.management"], "render.cpu": ["color.management"],
            "critic.ai": ["render.cpu"], "search.project": [], "memory.project": ["search.project"],
            "vision.detection": [],
        }
        return {k: [x for x in deps.get(k, []) if x in caps] for k in caps}

    def _execution_envelope(self, specialist, installed):
        installed = set(installed or ())
        executed = bool(specialist.executable and specialist.name in installed) or bool(specialist.executable and specialist.name == "cpu-render" and "cpu" in installed)
        return {
            "mode": "executed" if executed else "contract",
            "provider": specialist.name,
            "installed": specialist.name in installed or (specialist.name == "cpu-render" and "cpu" in installed),
            "external_claim_allowed": executed,
        }

    def _validate_result(self, result):
        errors = []
        if result.get("stage") != 14: errors.append("stage-id")
        if not isinstance(result.get("intent"), dict): errors.append("intent-schema")
        if not isinstance(result.get("jobs"), list) or not result["jobs"]: errors.append("jobs-schema")
        for job in result.get("jobs", []):
            for field in self.REQUIRED_JOB_FIELDS:
                if field not in job: errors.append(f"job-missing:{field}")
            if job.get("status") not in {"planned", "contract", "deferred"}: errors.append("job-status")
            if not 0 <= float(job.get("score", 0)) <= 1: errors.append("job-score")
            if job.get("execution", {}).get("mode") == "executed" and not job.get("execution", {}).get("external_claim_allowed"):
                errors.append("execution-claim")
        if result.get("quality_gate", {}).get("score", 0) < 0: errors.append("quality-score")
        return sorted(set(errors))

    def plan(self, command, media=None, installed=(), max_candidates=4, failure_inject=(), dependency_gap=(), upstream_fingerprint=""):
        media = self._normalize_media(media)
        intent = self.intent.parse(command)
        installed = tuple(sorted(set(installed or ())))
        failure_inject = set(failure_inject or ())
        dependency_gap = set(dependency_gap or ())
        caps = self._capabilities(command, media, intent)
        deps = self._dependencies(caps)
        jobs = []
        repairs = 0
        failed_caps = []

        for cap in caps:
            ranked = self.router.rank(cap, intent, installed, max_candidates)
            if not ranked:
                jobs.append({"capability": cap, "status": "deferred", "winner": None, "score": 0.0,
                             "issues": ["no-specialist"], "repaired": False, "alternatives": [], "evidence": "none",
                             "execution": {"mode": "deferred", "provider": None, "installed": False, "external_claim_allowed": False}})
                failed_caps.append(cap)
                continue

            valid_ranked = [c for c in ranked if c.specialist.name not in failure_inject]
            winner = ranked[0]
            injected = winner.specialist.name in failure_inject
            if injected and valid_ranked:
                winner = valid_ranked[0]
                repairs += 1
            elif injected:
                failed_caps.append(cap)

            context = {"quality_gate": intent["quality"] >= .95,
                       "dependency_gap": cap in dependency_gap,
                       "failure_injected": injected}
            critique = self.critic.review(winner, intent, context)
            repaired = injected
            if critique["needs_repair"] and len(valid_ranked) > 1:
                backup = valid_ranked[1]
                bcrit = self.critic.review(backup, intent, context)
                if bcrit["score"] >= critique["score"]:
                    winner, critique = backup, bcrit
                    repaired = True
                    repairs += 1

            issues = list(critique["issues"])
            if cap in dependency_gap:
                issues.append("dependency-gap")
            execution = self._execution_envelope(winner.specialist, installed)
            status = "planned" if execution["mode"] == "executed" else "contract"
            if cap in dependency_gap and not winner.specialist.executable:
                status = "deferred"
            if cap in failed_caps:
                status = "deferred"
            alternatives = [c.specialist.name for c in ranked if c.specialist.name != winner.specialist.name and c.specialist.name not in failure_inject]
            jobs.append({
                "capability": cap,
                "status": status,
                "winner": winner.specialist.name,
                "score": critique["score"],
                "issues": sorted(set(issues)),
                "repaired": repaired,
                "alternatives": alternatives,
                "evidence": winner.specialist.evidence,
                "execution": execution,
                "dependencies": deps.get(cap, []),
            })

        scores = [float(j["score"]) for j in jobs]
        quality_score = clamp(sum(scores) / max(1, len(scores)))
        hard_failures = [j["capability"] for j in jobs if j["status"] == "deferred" and "no-specialist" in j["issues"]]
        unresolved = [j["capability"] for j in jobs if j["status"] == "deferred"]
        gate = {
            "score": quality_score,
            "threshold": .82 if intent["quality"] < .95 else .88,
            "passed": quality_score >= (.82 if intent["quality"] < .95 else .88) and not hard_failures,
            "hard_failures": hard_failures,
            "deferred_jobs": unresolved,
        }
        result = {
            "stage": 14,
            "ok": True,
            "command": str(command),
            "intent": intent,
            "capabilities": caps,
            "dependency_graph": deps,
            "jobs": jobs,
            "repair_count": repairs,
            "quality_score": quality_score,
            "quality_gate": gate,
            "coverage": {"requested_capabilities": len(caps), "planned_or_contract": sum(j["status"] != "deferred" for j in jobs), "deferred": len(unresolved)},
            "runtime_policy": "external specialists are contract-only unless explicitly installed; no fake execution claims",
            "privacy_policy": "local/offline intent penalizes non-local providers and never authorizes external execution by name alone",
            "determinism_policy": "sorted inputs, stable ranking, canonical JSON fingerprint, no wall-clock fields",
            "handoff": {"upstream": "0-13.5", "upstream_fingerprint": str(upstream_fingerprint or ""), "downstream": "stage14 production execution", "non_destructive": True,
                        "contract_version": "14.1", "preserve_upstream": True},
            "audit": {"installed": installed, "failure_injection": sorted(failure_inject), "dependency_gap": sorted(dependency_gap)},
        }
        result["validation_errors"] = self._validate_result(result)
        result["ok"] = not result["validation_errors"]
        result["fingerprint"] = digest(result)
        return result

    def replay(self, result):
        """Validate a previous plan without changing it; useful for deterministic QA."""
        errors = self._validate_result(result)
        expected = result.get("fingerprint")
        clone = dict(result); clone.pop("fingerprint", None)
        return {"valid": not errors and bool(expected), "validation_errors": errors,
                "fingerprint": expected, "recomputed_fingerprint": digest(clone) if expected else None,
                "match": bool(expected) and expected == digest(clone)}

    def stress(self, command, media=None, iterations=1000, installed=(), failure_inject=(), upstream_fingerprint=""):
        iterations = max(1, min(int(iterations), 100000))
        fingerprints = set(); failures = []
        for i in range(iterations):
            r = self.plan(command, media, installed, failure_inject=failure_inject, upstream_fingerprint=upstream_fingerprint)
            if not r.get("ok") or not r.get("fingerprint") or not self.replay(r)["match"]:
                failures.append(i)
            fingerprints.add(r.get("fingerprint"))
        return {"iterations": iterations, "passed": iterations-len(failures), "failed": len(failures),
                "deterministic": len(fingerprints) == 1, "fingerprints": len(fingerprints),
                "failure_indices": failures[:20]}

    def audit_matrix(self, cases):
        reports = []
        for case in cases:
            r = self.plan(case.get("command", ""), case.get("media", {}), case.get("installed", ()),
                          max_candidates=case.get("max_candidates", 4), failure_inject=case.get("failure_inject", ()),
                          dependency_gap=case.get("dependency_gap", ()))
            reports.append({"name": case.get("name", "case"), "ok": r["ok"], "quality": r["quality_score"],
                            "coverage": r["coverage"], "repairs": r["repair_count"], "validation_errors": r["validation_errors"],
                            "fingerprint": r["fingerprint"]})
        return {"cases": len(reports), "passed": sum(x["ok"] for x in reports), "failed": sum(not x["ok"] for x in reports), "reports": reports}
