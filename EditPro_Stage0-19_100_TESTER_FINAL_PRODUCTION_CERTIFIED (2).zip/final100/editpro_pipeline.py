"""Unified Stage 0-7 integration facade.

Keeps stage implementations modular while providing one safe end-to-end entry point
for media understanding, visual intelligence, speech/captions, tracking, VFX and
adaptive design/motion planning.
"""
from __future__ import annotations
from pathlib import Path
from typing import Any
from dataclasses import asdict

from ai.production_pipeline import ProductionStage2
from ai.speech import SpeechResult
from stage3.stage3_production import Stage3Production
from stage4.pipeline import Stage4Pipeline
from stage5_pipeline import TrackingPipeline
from stage5_tracking import Detection, Box
from stage6_pipeline import Stage6Pipeline
from stage7_design import Stage7Pipeline
from stage8_compositor import Stage8Pipeline
from stage9_cinematography import Stage9Pipeline, CinematographyPlan
from stage10_audio import Stage10Pipeline
from stage11_meme import Stage11Pipeline
from stage12_asset_studio import Stage12Pipeline, AssetLibrary, AssetRecord, AssetMetadata, EditRequest
from stage13_style import Stage13StyleEngine, STYLE_MODES
from stage13_5_editing import Stage13_5EditingEngine
from stage14_production_intelligence import Stage14ProductionIntelligence
from stage15_generation_execution import Stage15Executor
from stage16_creative_brain import Stage16CreativeBrain
from stage17_final_completion import Stage17FinalCompletion
from stage18_scale_hardening import Stage18ScaleHardening
from stage18_5_professional_supremacy import Stage18_5ProfessionalSupremacy
from stage19_final_master import Stage19FinalMaster
from orchestration.core import ResourceProfile


class EditProPipeline:
    """One orchestration surface for the defined Stage 0-7 scope."""

    def __init__(self):
        self.stage2 = ProductionStage2()
        self.stage3 = Stage3Production()
        self.stage4 = Stage4Pipeline()
        self.stage5 = TrackingPipeline(profile=ResourceProfile('cpu-high', memory_mb=16384, max_workers=8))
        self.stage6 = Stage6Pipeline()
        self.stage7 = Stage7Pipeline()
        self.stage8 = Stage8Pipeline()
        self.stage9 = Stage9Pipeline()
        self.stage10 = Stage10Pipeline()
        self.stage11 = Stage11Pipeline()
        self.stage12 = Stage12Pipeline(AssetLibrary())
        self.stage13 = Stage13StyleEngine()
        self.stage13_5 = Stage13_5EditingEngine()
        self.stage14 = Stage14ProductionIntelligence()
        self.stage15 = Stage15Executor()
        self.stage16 = Stage16CreativeBrain()
        self.stage17 = Stage17FinalCompletion()
        self.stage18 = Stage18ScaleHardening()
        self.stage18_5 = Stage18_5ProfessionalSupremacy()
        self.stage19 = Stage19FinalMaster()

    @staticmethod
    def _words(speech: SpeechResult | None) -> list[dict[str, Any]]:
        return list(speech.transcript) if speech and isinstance(speech.transcript, list) else []

    @staticmethod
    def _detections_from_objects(objects: list[dict[str, Any]] | None) -> list[Detection]:
        out = []
        for d in objects or []:
            if not isinstance(d, dict):
                continue
            try:
                box = Box(float(d['x']), float(d['y']), float(d['w']), float(d['h']))
                conf = float(d.get('confidence', 1.0))
                label = str(d.get('label', 'object'))
                appearance = tuple(float(x) for x in d.get('appearance', ()))
                item = Detection(box, label, conf, appearance)
                if item.valid():
                    out.append(item)
            except (KeyError, TypeError, ValueError):
                continue
        return out


    @staticmethod
    def _sanitize_words(words: list[dict[str, Any]] | None, duration: float) -> list[dict[str, Any]]:
        """Drop malformed/out-of-range word timings at the integration boundary."""
        out=[]
        for w in words or []:
            if not isinstance(w,dict):
                continue
            try:
                st=float(w.get("start",0)); en=float(w.get("end",st))
            except (TypeError,ValueError):
                continue
            if st < 0 or en <= st or st > duration:
                continue
            item=dict(w); item["start"]=max(0.0,min(st,duration)); item["end"]=max(item["start"],min(en,duration))
            if item["end"] > item["start"]:
                out.append(item)
        # Stage 4 requires chronological transcript order. ASR providers can return
        # segments out of order, so normalize deterministically at the shared boundary.
        out.sort(key=lambda item: (float(item["start"]), float(item["end"]), str(item.get("speaker", "")), str(item.get("text", item.get("word", "")))))
        # Some ASR systems emit overlapping segments. Stage 4 uses a strict,
        # non-overlapping word timeline, so deterministically trim overlaps at the
        # shared boundary rather than letting one provider break the whole pipeline.
        normalized=[]; prev_end=0.0
        for item in out:
            st=max(float(item["start"]), prev_end)
            en=float(item["end"])
            if en <= st:
                continue
            item=dict(item); item["start"]=st; item["end"]=en
            normalized.append(item); prev_end=en
        return normalized

    @staticmethod
    def _sanitize_signal_media(media: dict[str, Any]) -> dict[str, Any]:
        """Harden the signal boundary against hostile/malformed metadata.

        Signal mode is an integration API, so malformed machine metadata must not
        crash the whole 0-16 orchestration graph. Values are clamped to the smallest
        valid planning domain while preserving the caller's original values under
        ``_input_media`` for audit/debugging.
        """
        import math
        src = dict(media) if isinstance(media, dict) else {}
        out = dict(src)
        out["_input_media"] = dict(src)
        def finite_number(value, default):
            try:
                x = float(value)
                return x if math.isfinite(x) else default
            except (TypeError, ValueError):
                return default
        out["duration"] = max(0.001, finite_number(src.get("duration", 1.0), 1.0))
        out["width"] = max(16, min(8192, int(round(finite_number(src.get("width", 1920), 1920)))))
        out["height"] = max(16, min(8192, int(round(finite_number(src.get("height", 1080), 1080)))))
        _fps = int(round(finite_number(src.get("fps", 30), 30)))
        _supported_fps = (1,2,5,10,12,15,20,24,25,30,50,60,90,120)
        out["fps"] = min(_supported_fps, key=lambda x: abs(x-_fps))
        return out

    @staticmethod
    def _sanitize_signal_speech(speech: dict[str, Any] | None, duration: float) -> dict[str, Any]:
        """Normalize hostile transcript/beat payloads before downstream stage models."""
        import math
        src = dict(speech) if isinstance(speech, dict) else {}
        clean = dict(src)
        words=[]
        for w in src.get("transcript") or []:
            if not isinstance(w, dict):
                continue
            text=w.get("text", w.get("word", ""))
            if not isinstance(text, str) or not text.strip():
                continue
            try:
                st=float(w.get("start", 0)); en=float(w.get("end", st))
            except (TypeError, ValueError):
                continue
            if not math.isfinite(st) or not math.isfinite(en):
                continue
            if en <= st or en <= 0 or st >= duration:
                continue
            item=dict(w); item["text"]=text.strip(); item["start"]=max(0.0, st); item["end"]=min(duration, en)
            if item["end"] > item["start"]:
                words.append(item)
        clean["transcript"]=words
        beats=[]
        for b in src.get("beats") or []:
            try:
                x=float(b)
                if math.isfinite(x) and 0 <= x <= duration:
                    beats.append(x)
            except (TypeError, ValueError):
                continue
        clean["beats"]=beats
        return clean

    @staticmethod
    def _normalize_target_format(target_format: str | None) -> str:
        """Normalize shared format vocabulary across Stage 7/8/9."""
        value=(target_format or "landscape").strip().lower()
        aliases={
            "instagram":"instagram_post", "post":"instagram_post",
            "instagram story":"instagram_story", "story":"instagram_story",
            "instagram reel":"reel", "reels":"reel",
            "youtube thumbnail":"youtube_thumbnail", "thumbnail":"youtube_thumbnail",
            "youtube banner":"youtube_banner", "banner":"youtube_banner",
            "16:9":"landscape", "9:16":"reel", "1:1":"square", "portrait":"reel", "youtube":"landscape",
        }
        return aliases.get(value,value)


    def run_from_signals(
        self,
        media: dict[str, Any],
        visual: list[dict[str, Any]] | None = None,
        speech: dict[str, Any] | None = None,
        intent: str = 'make an instagram reel',
        target_format: str | None = None,
        character_intent: str | None = None,
        vfx_intent: str = 'cinematic enhancement',
        style: str = 'balanced',
        objects: list[dict[str, Any]] | None = None,
        raw_words: list[dict[str, Any]] | None = None,
        available_runtimes=('cpu',),
        assets: list[dict[str, Any]] | None = None,
        asset_query: str = '',
        asset_edits: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        if not isinstance(media, dict):
            media = {}
        media = self._sanitize_signal_media(media)
        speech = self._sanitize_signal_speech(speech, float(media.get("duration", 1.0)))
        # Normalize style once at the shared orchestration boundary so Stage 13
        # and every downstream stage receive the same creative intent.
        effective_style = style if style in STYLE_MODES else 'balanced'
        # Stage 2 signal boundary.
        from ai.analyzer import VideoUnderstandingEngine
        from ai.director import EditingDirector
        words = raw_words if raw_words is not None else ((speech or {}).get('transcript') or [])
        words = self._sanitize_words(words, float(media.get('duration', 0) or 0))
        vmap = self.stage2.analyzer.analyze(media, words, [])
        plan = self.stage2.director.plan(vmap, effective_style)
        s2 = {'media': dict(media), 'visual_samples': visual or [], 'speech': speech,
              'runtime': self.stage2._runtime, 'video_map': vmap, 'edit_plan': plan,
              'cloud': {'ok': False, 'error': 'signal_mode'}}
        speech_dict = s2.get('speech')
        # Stages 3-7 share the same normalized signals.
        s3 = self.stage3.pipeline.run(float(media.get('duration', 0)), int(media.get('width', 0)),
                                      int(media.get('height', 0)), frames=visual or [],
                                      target=(9,16), available_runtimes=available_runtimes)
        s3['quality'] = self.stage3.gate.check(s3['reframe'], s3['tracks']); s3['media'] = dict(media)
        duration = float(media.get('duration', 0))
        s4 = self.stage4.run(words, duration, language=(speech or {}).get('language'),
                             visual_context=s3.get('attention_zones'), profile=effective_style)
        detections = self._detections_from_objects(objects)
        s5 = self.stage5.process([detections] if detections else [[]], priority='quality', reset=True)
        track_id = next(iter(self.stage5.tracker.tracks), None)
        end_frame = max(0, int(round(duration * 30)) - 1)
        s6 = self.stage6.process(vfx_intent, track_id=track_id, frames=(0, end_frame), capabilities=('cpu',))
        normalized_format = self._normalize_target_format(target_format)
        s7 = self.stage7.process(intent, target_format=normalized_format, character_intent=character_intent,
                                 content={'title': intent})
        s8_scene = self.stage8.plan(intent, width=int(media.get('width',1920) or 1920),
                                    height=int(media.get('height',1080) or 1080), fps=max(1,int(media.get('fps',30) or 30)),
                                    duration_frames=max(1,int(round(duration*max(1,float(media.get('fps',30) or 30))))))
        s8 = {'ok': True, 'scene': s8_scene, 'inspection': self.stage8.inspect(s8_scene)}
        s9_plan = self.stage9.plan(intent, visual=visual, speech=speech, media=media, fps=max(1,int(media.get('fps',30) or 30)), duration_frames=max(1,int(round(duration*max(1,float(media.get('fps',30) or 30))))), target_format=normalized_format, style=effective_style)
        # Stage 9 is the director: feed its camera decisions into Stage 8 without replacing Stage 8's compositor.
        s8_scene.metadata['stage9_director_digest'] = s9_plan.digest
        s8_scene.metadata['stage9_visual_strategy'] = s9_plan.visual_strategy
        s8_scene.metadata['stage9_shot_count'] = len(s9_plan.shots)
        s8_scene.camera_keyframes = {}
        for axis, key in [('fov','scale'), ('x','x'), ('target_y','y')]:
            vals=[]
            for k in s9_plan.camera_keyframes:
                if key in k:
                    # Deterministic mapping: Stage 8 camera engine consumes numeric keyframes.
                    from stage8_compositor import Keyframe
                    value = float(k[key])
                    if axis == 'fov': value = 55.0 / max(0.01, value)
                    elif axis == 'x': value = (value - 0.5) * 240.0
                    elif axis == 'target_y': value = (value - 0.5) * 160.0
                    vals.append(Keyframe(int(k['frame']), value, str(k.get('easing','ease_in_out'))))
            if vals:
                # Keep the final occurrence for duplicate frame numbers.
                dedup={v.frame:v for v in vals}
                s8_scene.camera_keyframes[axis]=[dedup[f] for f in sorted(dedup)]
        s8_scene.validate()
        s9 = {'ok': True, 'plan': s9_plan, 'inspection': self.stage9.inspect(s9_plan)}
        audio_meta = dict(media); audio_meta['duration'] = duration
        s10_plan = self.stage10.plan(intent, audio=audio_meta, transcript=words, beats=(speech or {}).get('beats',[]) if isinstance(speech or {},dict) else [])
        s10 = {'ok': True, 'plan': s10_plan, 'inspection': self.stage10.inspect(s10_plan)}
        s11_plan = self.stage11.plan(intent, duration=duration, target_format=normalized_format, style='classic',
                                     visual=visual, speech=words, beats=(speech or {}).get('beats',[]) if isinstance(speech or {},dict) else [])
        s11 = {'ok': True, 'plan': s11_plan, 'inspection': self.stage11.inspect(s11_plan)}

        # Stage 12 asset layer: register supplied assets, or the current media as a
        # project-owned source, then feed the shared command/format into the asset
        # planner. This makes 0-12 one coordinated signal path rather than a pile
        # of numbered folders that merely coexist.
        stage12_lib = AssetLibrary()
        for item in (assets or []):
            if isinstance(item, dict):
                stage12_lib.add(item)
        if not stage12_lib.assets:
            stage12_lib.add(AssetRecord(
                id='signal_media', kind='user_import', license_class='user_owned',
                width=max(0,int(media.get('width',0) or 0)), height=max(0,int(media.get('height',0) or 0)),
                duration=duration, mime_type=str(media.get('mime_type',media.get('format',''))),
                metadata=AssetMetadata(tags=[normalized_format], objects=[str(x.get('label','')).lower() for x in (visual or []) if isinstance(x,dict) and x.get('label')])
            ))
        self.stage12 = Stage12Pipeline(stage12_lib)
        s12_plan = self.stage12.plan(intent, duration, normalized_format if normalized_format in {
            'square','portrait','landscape','reel','story','youtube','thumbnail','banner','instagram_post','instagram_story','youtube_thumbnail','youtube_banner'
        } else 'landscape', asset_query=asset_query, asset_ids=['signal_media'] if not asset_query and not assets else None, edits=asset_edits or [])
        s12_results=[]
        for aid in s12_plan.selected_assets:
            for edit in (asset_edits or []):
                s12_results.append(self.stage12.apply_edit(aid, edit))
        s12 = {'ok': True, 'plan': s12_plan, 'results': s12_results, 'inspection': self.stage12.inspect(s12_plan)}
        # Stage 13: one global creative language shared by the downstream visual/audio/asset layers.
        s13_plan = self.stage13.plan(intent, mode=effective_style)
        style_handoff = self.stage13.handoff(s13_plan)
        # Stage 13 is not merely a report generator: attach its immutable handoff
        # contract to every downstream plan so later renderers can consume one
        # consistent creative language without changing their existing APIs.
        s7['style_handoff_digest'] = style_handoff['style_digest']
        s7['style_profile_digest'] = style_handoff['profile_digest']
        s8_scene.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s8_scene.metadata['stage13_style_mode'] = style_handoff['mode']
        s9_plan.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s10_plan.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s11_plan.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s12_plan.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s13 = {'ok': True, 'plan': s13_plan, 'inspection': self.stage13.inspect(s13_plan), 'handoff': style_handoff}
        # Stage 13.5 closes the core editing capability gaps while preserving the
        # existing Stage 14 boundary. It creates a non-destructive edit contract.
        s13_5_plan = self.stage13_5.plan(intent, duration=duration, fps=max(1,int(media.get('fps',30) or 30)), target_format=normalized_format, media=media)
        s13_5_plan.timeline.history.append(f"stage13_style:{style_handoff['style_digest']}")
        # Recompute digest after the cross-stage history marker is attached.
        from stage13_5_editing import digest_obj
        s13_5_plan.digest = digest_obj({'command':s13_5_plan.command,'features':s13_5_plan.features,'operations':[asdict(o) for o in s13_5_plan.operations],'timeline':asdict(s13_5_plan.timeline),'contracts':s13_5_plan.contracts})
        editing_handoff = self.stage13_5.handoff(s13_5_plan)
        s13_5 = {'ok': True, 'plan': s13_5_plan, 'inspection': self.stage13_5.inspect(s13_5_plan), 'handoff': editing_handoff}
        # Stage 14: production intelligence/tournament above the completed editing layer.
        stage14_media = dict(media)
        stage14_media.update({'speech': bool(words), 'music': bool((speech_dict or {}).get('beats')) if isinstance(speech_dict, dict) else False})
        s14 = self.stage14.plan(intent, media=stage14_media, installed=tuple(stage14_media.get('_installed_providers', ())), upstream_fingerprint=editing_handoff.get('editing_digest', '') if isinstance(editing_handoff, dict) else '')
        # Stage 15: advanced generation/execution above the Stage 14 production plan.
        stage15_media = dict(stage14_media)
        stage15_media.update({'style_digest': style_handoff.get('style_digest', ''), 'editing_digest': editing_handoff.get('editing_digest', '') if isinstance(editing_handoff, dict) else ''})
        s15 = self.stage15.plan(intent, media=stage15_media, installed=tuple(stage15_media.get('_installed_providers', ())), upstream={'fingerprint': s14.get('fingerprint', '')})
        s16_plan = self.stage16.plan(intent, media={**stage15_media, 'target_format': normalized_format}, visual=s3.get('attention_zones') or [], speech=speech_dict or {}, stage15=s15)
        s16 = {'ok': True, 'plan': s16_plan, 'inspection': self.stage16.inspect(s16_plan), 'handoff': self.stage16.handoff(s16_plan)}
        s17_plan = self.stage17.plan(intent, media={**stage15_media, 'target_format': normalized_format}, upstream={'fingerprint': s16_plan.get('fingerprint','')})
        s17 = {'ok': True, 'plan': s17_plan, 'inspection': self.stage17.inspect(s17_plan), 'handoff': self.stage17.handoff(s17_plan)}
        s18_plan = self.stage18.plan(intent, hardware=stage15_media.get('hardware', {}), project=stage15_media.get('project', s2.get('media', {})), upstream=s17.get('handoff', {}))
        s18 = {'ok': True, 'plan': s18_plan, 'inspection': self.stage18.inspect(s18_plan), 'handoff': self.stage18.handoff(s18_plan)}
        s18_5_plan = self.stage18_5.plan(intent, project=stage15_media.get('project', s2.get('media', {})), hardware=stage15_media.get('hardware', {}), upstream=s18.get('handoff', {}))
        s18_5 = {'ok': True, 'plan': s18_5_plan, 'inspection': self.stage18_5.inspect(s18_5_plan), 'handoff': self.stage18_5.handoff(s18_5_plan)}
        s19_plan = self.stage19.plan(intent, upstream=s18_5.get('handoff', {}), media=stage15_media, installed=tuple(stage15_media.get('_installed_providers', ())))
        s19 = {'ok': True, 'plan': s19_plan, 'inspection': self.stage19.inspect(s19_plan), 'handoff': self.stage19.handoff(s19_plan)}
        stages={'0_1': 'browser_ui', '2': s2, '3': s3, '4': s4, '5': s5, '6': s6, '7': s7, '8': s8, '9': s9, '10': s10, '11': s11, '12': s12, '13': s13, '13.5': s13_5, '14': s14, '15': s15, '16': s16, '17': s17, '18': s18, '18.5': s18_5, '19': s19}
        return {'ok': all(bool(x.get('ok', True)) for x in stages.values() if isinstance(x,dict)), 'stages': stages}

    def run(
        self,
        path: str | Path,
        intent: str = 'make an instagram reel',
        target_format: str | None = None,
        character_intent: str | None = None,
        vfx_intent: str = 'cinematic enhancement',
        style: str = 'balanced',
        objects: list[dict[str, Any]] | None = None,
        raw_words: list[dict[str, Any]] | None = None,
        available_runtimes=('cpu',),
        assets: list[dict[str, Any]] | None = None,
        asset_query: str = '',
        asset_edits: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        media_path = Path(path)
        media_validation = self.stage19.validate_media_file(media_path)
        if not media_validation.get('ok'):
            raise ValueError(f'Unsafe or invalid media input: {media_path}')

        # Normalize style once at the shared orchestration boundary.
        effective_style = style if style in STYLE_MODES else 'balanced'
        # Stage 2: real media understanding + optional speech/cloud fallbacks.
        s2 = self.stage2.run(media_path, style=effective_style)
        # Reuse Stage 2's already-computed speech object. For media without audio it is None.
        speech_dict = s2.get('speech')
        words = raw_words if raw_words is not None else []
        if not words and isinstance(speech_dict, dict):
            words = speech_dict.get('transcript') or []

        # Stage 3: visual intelligence and safe reframing.
        s3 = self.stage3.run(media_path, target=(9, 16), available_runtimes=available_runtimes)

        # Stage 4: transcript/caption direction. Empty transcripts are valid and remain non-destructive.
        duration = float(s2['media']['duration'])
        words = self._sanitize_words(words, duration)
        s4 = self.stage4.run(words, duration, language=(speech_dict or {}).get('language') if speech_dict else None,
                             visual_context=s3.get('attention_zones'), profile=effective_style)

        # Stage 5: use only explicitly supplied object detections. No fabricated tracking data.
        detections = self._detections_from_objects(objects)
        s5 = self.stage5.process([detections], priority='quality', reset=True) if detections else self.stage5.process([[]], priority='quality', reset=True)

        # Stage 6: VFX plan can attach to a real Stage-5 track when one exists.
        track_id = next(iter(self.stage5.tracker.tracks), None)
        end_frame = max(0, int(round(duration * 30)) - 1)
        s6 = self.stage6.process(vfx_intent, track_id=track_id, frames=(0, end_frame), capabilities=('cpu',))

        # Stage 7: adaptive template + character motion.
        normalized_format = self._normalize_target_format(target_format)
        s7 = self.stage7.process(intent, target_format=normalized_format, character_intent=character_intent,
                                 content={'title': intent})
        s8_scene = self.stage8.plan(intent, width=int(s2['media'].get('width',1920) or 1920),
                                    height=int(s2['media'].get('height',1080) or 1080), fps=max(1,int(s2['media'].get('fps',30) or 30)),
                                    duration_frames=max(1,int(round(duration*max(1,float(s2['media'].get('fps',30) or 30))))))
        s8 = {'ok': True, 'scene': s8_scene, 'inspection': self.stage8.inspect(s8_scene)}
        s9_plan = self.stage9.plan(intent, visual=s3.get('attention_zones'), speech=speech_dict, media=s2.get('media'), fps=max(1,int(s2['media'].get('fps',30) or 30)), duration_frames=max(1,int(round(duration*max(1,float(s2['media'].get('fps',30) or 30))))), target_format=normalized_format, style=effective_style)
        # Stage 9 is the director: feed its camera decisions into Stage 8 without replacing Stage 8's compositor.
        s8_scene.metadata['stage9_director_digest'] = s9_plan.digest
        s8_scene.metadata['stage9_visual_strategy'] = s9_plan.visual_strategy
        s8_scene.metadata['stage9_shot_count'] = len(s9_plan.shots)
        s8_scene.camera_keyframes = {}
        for axis, key in [('fov','scale'), ('x','x'), ('target_y','y')]:
            vals=[]
            for k in s9_plan.camera_keyframes:
                if key in k:
                    # Deterministic mapping: Stage 8 camera engine consumes numeric keyframes.
                    from stage8_compositor import Keyframe
                    value = float(k[key])
                    if axis == 'fov': value = 55.0 / max(0.01, value)
                    elif axis == 'x': value = (value - 0.5) * 240.0
                    elif axis == 'target_y': value = (value - 0.5) * 160.0
                    vals.append(Keyframe(int(k['frame']), value, str(k.get('easing','ease_in_out'))))
            if vals:
                # Keep the final occurrence for duplicate frame numbers.
                dedup={v.frame:v for v in vals}
                s8_scene.camera_keyframes[axis]=[dedup[f] for f in sorted(dedup)]
        s8_scene.validate()
        s9 = {'ok': True, 'plan': s9_plan, 'inspection': self.stage9.inspect(s9_plan)}
        audio_meta = dict(s2.get('media') or {}); audio_meta['duration'] = duration
        s10_plan = self.stage10.plan(intent, audio=audio_meta, transcript=words, beats=(speech_dict or {}).get('beats',[]) if isinstance(speech_dict,dict) else [])
        s10 = {'ok': True, 'plan': s10_plan, 'inspection': self.stage10.inspect(s10_plan)}
        s11_plan = self.stage11.plan(intent, duration=duration, target_format=normalized_format, style='classic',
                                     visual=s3.get('attention_zones'), speech=words, beats=(speech_dict or {}).get('beats',[]) if isinstance(speech_dict,dict) else [])
        s11 = {'ok': True, 'plan': s11_plan, 'inspection': self.stage11.inspect(s11_plan)}

        stage12_lib = AssetLibrary()
        for item in (assets or []):
            if isinstance(item, dict): stage12_lib.add(item)
        if not stage12_lib.assets:
            stage12_lib.add(AssetRecord(
                id='media_source', path=str(media_path), kind='user_import', license_class='user_owned',
                mime_type=str(s2['media'].get('mime_type',s2['media'].get('format',''))),
                width=max(0,int(s2['media'].get('width',0) or 0)), height=max(0,int(s2['media'].get('height',0) or 0)),
                duration=duration, metadata=AssetMetadata(tags=[normalized_format], objects=[str(x.get('label','')).lower() for x in (s3.get('attention_zones') or []) if isinstance(x,dict) and x.get('label')])
            ))
        self.stage12 = Stage12Pipeline(stage12_lib)
        s12_plan = self.stage12.plan(intent, duration, normalized_format if normalized_format in {
            'square','portrait','landscape','reel','story','youtube','thumbnail','banner','instagram_post','instagram_story','youtube_thumbnail','youtube_banner'
        } else 'landscape', asset_query=asset_query, asset_ids=['media_source'] if not asset_query and not assets else None, edits=asset_edits or [])
        s12_results=[]
        for aid in s12_plan.selected_assets:
            for edit in (asset_edits or []):
                s12_results.append(self.stage12.apply_edit(aid, edit))
        s12 = {'ok': True, 'plan': s12_plan, 'results': s12_results, 'inspection': self.stage12.inspect(s12_plan)}
        s13_plan = self.stage13.plan(intent, mode=effective_style)
        style_handoff = self.stage13.handoff(s13_plan)
        s7['style_handoff_digest'] = style_handoff['style_digest']
        s7['style_profile_digest'] = style_handoff['profile_digest']
        s8_scene.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s8_scene.metadata['stage13_style_mode'] = style_handoff['mode']
        s9_plan.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s10_plan.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s11_plan.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s12_plan.metadata['stage13_style_digest'] = style_handoff['style_digest']
        s13 = {'ok': True, 'plan': s13_plan, 'inspection': self.stage13.inspect(s13_plan), 'handoff': style_handoff}
        # Stage 13.5: core editing completion contract on the real-media path.
        s13_5_plan = self.stage13_5.plan(intent, duration=duration, fps=max(1,int(s2['media'].get('fps',30) or 30)), target_format=normalized_format, media=s2.get('media') or {})
        s13_5_plan.timeline.history.append(f"stage13_style:{style_handoff['style_digest']}")
        from stage13_5_editing import digest_obj
        s13_5_plan.digest = digest_obj({'command':s13_5_plan.command,'features':s13_5_plan.features,'operations':[asdict(o) for o in s13_5_plan.operations],'timeline':asdict(s13_5_plan.timeline),'contracts':s13_5_plan.contracts})
        editing_handoff = self.stage13_5.handoff(s13_5_plan)
        s13_5 = {'ok': True, 'plan': s13_5_plan, 'inspection': self.stage13_5.inspect(s13_5_plan), 'handoff': editing_handoff}
        stage14_media = dict(s2.get('media') or {})
        stage14_media.update({'speech': bool(words), 'music': bool((speech_dict or {}).get('beats')) if isinstance(speech_dict, dict) else False})
        s14 = self.stage14.plan(intent, media=stage14_media, installed=tuple(stage14_media.get('_installed_providers', ())), upstream_fingerprint=style_handoff.get('style_digest', ''))
        stage15_media = dict(stage14_media)
        stage15_media.update({'style_digest': style_handoff.get('style_digest', ''),
                              'editing_digest': editing_handoff.get('editing_digest', '') if isinstance(editing_handoff, dict) else ''})
        s15 = self.stage15.plan(intent, media=stage15_media, installed=tuple(stage15_media.get('_installed_providers', ())), upstream={'fingerprint': s14.get('fingerprint', '')})
        # Stage 16: Creative Director / Autopilot intelligence above the execution core.
        # It plans editable, reversible creative decisions; it does not pretend that
        # a provider-neutral contract has already generated pixels.
        s16_plan = self.stage16.plan(intent, media={**stage15_media, 'target_format': normalized_format},
                                     visual=s3.get('attention_zones') or [], speech=speech_dict or {}, stage15=s15)
        s16 = {'ok': True, 'plan': s16_plan, 'inspection': self.stage16.inspect(s16_plan),
               'handoff': self.stage16.handoff(s16_plan)}

        s17_plan = self.stage17.plan(intent, media={**stage15_media, 'target_format': normalized_format}, upstream={'fingerprint': s16_plan.get('fingerprint','')})
        s17 = {'ok': True, 'plan': s17_plan, 'inspection': self.stage17.inspect(s17_plan), 'handoff': self.stage17.handoff(s17_plan)}
        s18_plan = self.stage18.plan(intent, hardware=stage15_media.get('hardware', {}), project=stage15_media.get('project', s2.get('media', {})), upstream=s17.get('handoff', {}))
        s18 = {'ok': True, 'plan': s18_plan, 'inspection': self.stage18.inspect(s18_plan), 'handoff': self.stage18.handoff(s18_plan)}
        s18_5_plan = self.stage18_5.plan(intent, project=stage15_media.get('project', s2.get('media', {})), hardware=stage15_media.get('hardware', {}), upstream=s18.get('handoff', {}))
        s18_5 = {'ok': True, 'plan': s18_5_plan, 'inspection': self.stage18_5.inspect(s18_5_plan), 'handoff': self.stage18_5.handoff(s18_5_plan)}
        s19_plan = self.stage19.plan(intent, upstream=s18_5.get('handoff', {}), media=stage15_media, installed=tuple(stage15_media.get('_installed_providers', ())))
        s19 = {'ok': True, 'plan': s19_plan, 'inspection': self.stage19.inspect(s19_plan), 'handoff': self.stage19.handoff(s19_plan)}
        stages={'0_1': 'browser_ui', '2': s2, '3': s3, '4': s4, '5': s5, '6': s6, '7': s7, '8': s8, '9': s9, '10': s10, '11': s11, '12': s12, '13': s13, '13.5': s13_5, '14': s14, '15': s15, '16': s16, '17': s17, '18': s18, '18.5': s18_5, '19': s19}
        return {'ok': all(bool(x.get('ok', True)) for x in stages.values() if isinstance(x,dict)), 'stages': stages}
