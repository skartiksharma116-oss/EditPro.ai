#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python tests/test_matrix.py
python tests/production_hardening.py
python tests/production_environment_test.py
python tests/harsh_media_render.py
python tests/concurrency_faults.py
python tests/environment_smoke.py
python - <<'PY'
import sys
sys.path.insert(0,'.')
from infra.gpu_worker import run_tensor_job
print('GPU/CPU worker:',run_tensor_job(64))
PY
