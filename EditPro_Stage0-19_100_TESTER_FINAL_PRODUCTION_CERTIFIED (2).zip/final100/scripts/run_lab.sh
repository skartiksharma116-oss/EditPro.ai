#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python tests/test_matrix.py
python tests/production_hardening.py
python tests/production_environment_test.py
