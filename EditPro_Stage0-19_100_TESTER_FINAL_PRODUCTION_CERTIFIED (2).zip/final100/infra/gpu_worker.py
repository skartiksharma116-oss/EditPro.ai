"""GPU/CPU worker abstraction. Uses CUDA when present and never lies about fallback."""
from __future__ import annotations
import time

def run_tensor_job(size=128):
    import torch
    device='cuda' if torch.cuda.is_available() else 'cpu'
    x=torch.randn(size,size,device=device); y=x@x.T
    if device=='cuda': torch.cuda.synchronize()
    return {'device':device,'checksum':float(y.mean().item())}
