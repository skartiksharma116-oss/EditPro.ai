"""Local deterministic cloud AI simulator for integration tests. Supports injected failures."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json, os, random
PORT=int(os.getenv('PORT','8110')); MODE=os.getenv('MOCK_MODE','ok')
class H(BaseHTTPRequestHandler):
 def do_POST(self):
  n=int(self.headers.get('Content-Length','0')); _=self.rfile.read(n)
  if MODE=='fail': self.send_response(503); self.end_headers(); return
  if MODE=='badshape': self.send_response(200); self.end_headers(); self.wfile.write(b'[]'); return
  if MODE=='flaky' and random.random()<.35: self.send_response(503); self.end_headers(); return
  self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(json.dumps({'ok':True,'worker':'mock-cloud','confidence':0.91}).encode())
 def log_message(self,*a): pass
if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',PORT),H).serve_forever()
