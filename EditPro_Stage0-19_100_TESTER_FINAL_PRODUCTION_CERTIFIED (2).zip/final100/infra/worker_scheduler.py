from ai.cpu_engine import CPUWorker
from .rocm_worker import ROCmWorker

class WorkerScheduler:
    def __init__(self, cpu_workers=None):
        self.rocm=ROCmWorker(); self.cpu=CPUWorker(max_workers=cpu_workers)
    def health(self): return {'rocm':self.rocm.health(),'cpu':self.cpu.health()}
    def dispatch(self,task):
        h=self.rocm.health()
        # ROCm is selected only when the worker proves real availability.
        return self.rocm.run(task) if h.get('available') else self.cpu.run(task)
    def close(self): self.cpu.close()
