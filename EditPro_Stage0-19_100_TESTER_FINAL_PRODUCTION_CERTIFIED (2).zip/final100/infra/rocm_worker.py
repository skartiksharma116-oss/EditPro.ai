from ai.rocm_backend import choose

class ROCmWorker:
    name='amd-rocm'
    def health(self):
        info=choose('rocm')
        return {'worker':self.name,'backend':info.backend,'available':info.available,'devices':info.device_count,'detail':info.detail}
    def run(self, task):
        info=choose('rocm')
        if not info.available:
            raise RuntimeError('ROCm GPU unavailable; scheduler must use fallback worker')
        return {'status':'ready','backend':'rocm','task':task}
