"""Local deterministic transcription service for end-to-end speech integration tests."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json, os
PORT=int(os.getenv('PORT','8111'))
class H(BaseHTTPRequestHandler):
 def do_POST(self):
  n=int(self.headers.get('Content-Length','0')); body=self.rfile.read(n)
  # It is deliberately deterministic. It validates that multipart bytes reached the speech boundary.
  ok=b'filename=' in body
  self.send_response(200 if ok else 400); self.send_header('Content-Type','application/json'); self.end_headers()
  self.wfile.write(json.dumps({'transcript':[{'text':'This is an important test moment','start':0.2,'end':1.7}], 'language':'en'}).encode())
 def log_message(self,*a): pass
if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',PORT),H).serve_forever()
