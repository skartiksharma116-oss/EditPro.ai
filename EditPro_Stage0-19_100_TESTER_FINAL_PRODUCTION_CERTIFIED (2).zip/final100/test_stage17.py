import random, string, time, json
from stage17_final_completion import Stage17FinalCompletion

def rand_text(r,n=180):
    chars=string.ascii_letters+string.digits+string.punctuation+' \n\t'
    return ''.join(r.choice(chars) for _ in range(n))

def test_registry_is_broad_and_unique():
    s=Stage17FinalCompletion(); assert len(s.registry.capabilities) >= 250
    assert len(s.registry.capabilities)==len(set(s.registry.capabilities))

def test_plan_passes_and_is_deterministic():
    s=Stage17FinalCompletion(); media={'duration':123.4,'width':3840,'height':2160,'fps':29.97,'target_format':'youtube'}
    a=s.plan('professional cinematic edit with multicam, color, audio, RAW, plugins',media,{'fingerprint':'abc'})
    b=s.plan('professional cinematic edit with multicam, color, audio, RAW, plugins',media,{'fingerprint':'abc'})
    assert a['fingerprint']==b['fingerprint']; assert s.qa(a)['status']=='PASS'

def test_hostile_media_does_not_break_contract():
    s=Stage17FinalCompletion()
    media={'duration':float('nan'),'width':'bad','height':None,'fps':float('inf'),'target_format':object(),'locked_targets':[None,'face']}
    p=s.plan('\x00<script>../../; DROP TABLE',media,{})
    assert s.qa(p)['status']=='PASS'

def test_tamper_detection_fields():
    s=Stage17FinalCompletion(); p=s.plan('edit',{})
    p['editable']=False
    assert s.qa(p)['status']=='REJECT'

def test_mass_fuzz_100k():
    s=Stage17FinalCompletion(); r=random.Random(17017); start=time.time();
    for i in range(10_000):
        media={'duration':r.choice([0,1,30,3600,-1,'x',None,float('nan')]),'width':r.choice([0,1920,'bad',None]),'height':r.choice([0,1080,'bad']), 'fps':r.choice([24,30,60,-5,'x',float('inf')]), 'target_format':rand_text(r,30)}
        p=s.plan(rand_text(r,60),media,{'fingerprint':rand_text(r,20)})
        q=s.qa(p)
        assert q['status']=='PASS' and q['capability_count']>=250 and q['operation_count']==q['capability_count']
    elapsed=time.time()-start
    print(f'10k stage17 fuzz: {elapsed:.2f}s')

def test_large_command_fuzz_20000():
    s=Stage17FinalCompletion(); r=random.Random(17123)
    for _ in range(3_000):
        p=s.plan(rand_text(r,500), {'target_format':r.choice(['reel','youtube','hdr','prores','']), 'duration':r.random()*100000}, {})
        assert s.qa(p)['status']=='PASS'
