"""EditPro.ai Stage 15: Advanced AI Generation & Specialist Execution Core.

This stage is deliberately exhaustive within its boundary: it turns Stage-14
production decisions into an auditable execution graph for generative media,
character motion, scene reconstruction, VFX, temporal consistency, repair and
runtime management. It never pretends a remote model rendered pixels unless
that exact runtime is explicitly advertised as executable.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import hashlib, json, math
from typing import Any


def clamp(v, lo=0.0, hi=1.0):
    try:
        x=float(v)
    except Exception:
        return lo
    return max(lo, min(hi, x)) if math.isfinite(x) else lo


def digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


@dataclass(frozen=True)
class ExecutionCapability:
    name: str
    family: str
    requires: tuple[str, ...] = ()
    local_fallback: str | None = None
    generative: bool = False
    temporal: bool = False
    material_output: bool = False


@dataclass
class ExecutionJob:
    capability: str
    status: str
    mode: str
    provider: str | None
    fallback: str | None
    dependencies: list[str]
    parameters: dict[str, Any]
    quality_score: float
    attempts: int = 0
    repaired: bool = False
    issues: list[str] = field(default_factory=list)
    artifact: dict[str, Any] | None = None


class Stage15CapabilityRegistry:
    """Stage-15 capability surface. Stage 16-19 concerns are intentionally excluded."""
    def __init__(self):
        C=[]
        def add(name, family, requires=(), local=None, gen=False, temporal=False, material=False):
            C.append(ExecutionCapability(name, family, tuple(requires), local, gen, temporal, material))

        # Runtime / resource / execution foundation.
        add("runtime.model_registry", "runtime", local="local:model-registry")
        add("runtime.resource_manager", "runtime", local="local:resource-manager")
        add("runtime.execution_boundary", "runtime", local="local:execution-boundary")
        add("runtime.device_probe", "runtime", local="local:device-probe")
        add("runtime.memory_budget", "runtime", requires=("runtime.resource_manager",), local="local:memory-budget")
        add("runtime.cache", "runtime", requires=("runtime.resource_manager",), local="local:artifact-cache")
        add("runtime.batch_scheduler", "runtime", requires=("runtime.resource_manager",), local="local:batch-scheduler")
        add("runtime.chunk_scheduler", "runtime", requires=("runtime.resource_manager",), local="local:chunk-scheduler")
        add("runtime.cancellation", "runtime", local="local:cancellation")
        add("runtime.provenance", "runtime", local="local:provenance")
        add("runtime.license_guard", "runtime", local="local:license-guard")
        add("runtime.safety_guard", "runtime", local="local:safety-guard")

        # Generation: video.
        add("generation.video.text_to_video", "video_generation", local="contract:text-to-video", gen=True, temporal=True, material=True)
        add("generation.video.image_to_video", "video_generation", local="contract:image-to-video", gen=True, temporal=True, material=True)
        add("generation.video.video_to_video", "video_generation", local="contract:video-to-video", gen=True, temporal=True, material=True)
        add("generation.video.continuation", "video_generation", local="contract:video-continuation", gen=True, temporal=True, material=True)
        add("generation.video.broll", "video_generation", local="contract:broll-generation", gen=True, temporal=True, material=True)
        add("generation.video.shot", "video_generation", local="contract:shot-generation", gen=True, temporal=True, material=True)
        add("generation.video.transition_shot", "video_generation", local="contract:transition-shot", gen=True, temporal=True, material=True)
        add("generation.video.establishing_shot", "video_generation", local="contract:establishing-shot", gen=True, temporal=True, material=True)
        add("generation.video.audio_driven", "video_generation", requires=("generation.video.shot",), local="contract:audio-driven-video", gen=True, temporal=True, material=True)
        add("generation.video.upscale", "video_post", local="contract:video-upscale", gen=True, temporal=True, material=True)
        add("generation.video.frame_interpolation", "video_post", local="contract:frame-interpolation", gen=True, temporal=True, material=True)

        # Generation: image.
        for n, local in [
            ("text_to_image","contract:text-to-image"),("variation","contract:image-variation"),
            ("inpaint","contract:inpaint"),("outpaint","contract:outpaint"),("relight","contract:relight"),
            ("style_transfer","contract:style-transfer"),("reference_conditioning","contract:reference-conditioning"),
            ("product_scene","contract:product-scene"),("background_generate","contract:background-generation")]:
            add(f"generation.image.{n}", "image_generation", local=local, gen=True, material=True)

        # Conditioning/control inputs.
        add("conditioning.text_prompt", "conditioning", local="local:prompt-normalizer")
        add("conditioning.negative_prompt", "conditioning", local="local:negative-prompt")
        add("conditioning.reference_image", "conditioning", local="local:reference-validator")
        add("conditioning.depth", "conditioning", local="local:depth-control")
        add("conditioning.pose", "conditioning", local="local:pose-control")
        add("conditioning.edge", "conditioning", local="local:edge-control")
        add("conditioning.mask", "conditioning", local="local:mask-control")
        add("conditioning.style", "conditioning", local="local:style-control")

        # Character / avatar execution.
        add("character.pose", "character", local="local:pose-analysis")
        add("character.motion_transfer", "character", requires=("character.pose",), local="contract:motion-transfer", gen=True, temporal=True, material=True)
        add("character.identity_consistency", "character", requires=("character.pose",), local="local:identity-check", temporal=True)
        add("character.expression", "character", requires=("character.pose",), local="contract:expression-control", gen=True, temporal=True, material=True)
        add("character.lipsync", "character", requires=("character.expression",), local="contract:lip-sync", gen=True, temporal=True, material=True)
        add("character.multi_subject", "character", requires=("character.identity_consistency",), local="contract:multi-subject", gen=True, temporal=True, material=True)
        add("character.avatar_motion", "character", requires=("character.motion_transfer",), local="contract:avatar-motion", gen=True, temporal=True, material=True)

        # Motion / virtual camera.
        add("motion.camera", "motion", local="local:camera-plan", gen=True, temporal=True)
        add("motion.camera_simulation", "motion", requires=("motion.camera",), local="contract:camera-simulation", gen=True, temporal=True, material=True)
        add("motion.object", "motion", local="contract:object-motion", gen=True, temporal=True, material=True)
        add("motion.motion_field", "motion", requires=("motion.object",), local="local:motion-field", temporal=True)
        add("motion.smoothing", "motion", requires=("motion.motion_field",), local="local:motion-smoothing", temporal=True)
        add("motion.stabilization", "motion", local="local:stabilization", temporal=True)

        # Scene reconstruction / compositing.
        add("scene.depth_estimate", "scene", local="local:depth-proxy")
        add("scene.depth_composite", "scene", requires=("scene.depth_estimate",), local="local:depth-composite")
        add("scene.perspective_match", "scene", requires=("scene.depth_estimate",), local="local:perspective-match")
        add("scene.camera_match", "scene", requires=("scene.depth_estimate",), local="local:camera-match")
        add("scene.lighting_match", "scene", local="local:lighting-analysis")
        add("scene.shadow_match", "scene", requires=("scene.lighting_match",), local="local:shadow-proxy")
        add("scene.reflection_match", "scene", requires=("scene.lighting_match",), local="local:reflection-proxy")
        add("scene.environment_reconstruction", "scene", requires=("scene.depth_estimate","scene.camera_match"), local="contract:environment-reconstruction", gen=True, temporal=True, material=True)
        add("scene.consistency", "scene", requires=("scene.depth_composite","scene.lighting_match"), local="local:scene-consistency", temporal=True)

        # VFX.
        add("vfx.environment", "vfx", local="local:procedural-vfx", gen=True, temporal=True, material=True)
        add("vfx.particles", "vfx", local="local:procedural-particles", gen=True, temporal=True, material=True)
        add("vfx.atmosphere", "vfx", local="local:atmosphere", gen=True, temporal=True, material=True)
        add("vfx.transformation", "vfx", requires=("scene.consistency",), local="contract:scene-transform", gen=True, temporal=True, material=True)
        add("vfx.energy", "vfx", local="contract:energy-vfx", gen=True, temporal=True, material=True)
        add("vfx.physics_proxy", "vfx", local="local:physics-proxy", gen=True, temporal=True, material=True)

        # Repair / replacement.
        add("repair.object_remove", "repair", local="local:mask-repair", gen=True, temporal=True, material=True)
        add("repair.object_replace", "repair", requires=("repair.object_remove",), local="contract:object-replace", gen=True, temporal=True, material=True)
        add("repair.background_replace", "repair", local="local:segmentation-composite", gen=True, temporal=True, material=True)
        add("repair.frame_extend", "repair", local="contract:frame-extension", gen=True, material=True)
        add("repair.scene_restore", "repair", requires=("scene.consistency",), local="contract:scene-restore", gen=True, temporal=True, material=True)
        add("repair.temporal_gap", "repair", requires=("temporal.consistency",), local="local:interpolation", gen=True, temporal=True, material=True)

        # Temporal intelligence.
        add("temporal.consistency", "temporal", local="local:temporal-validator", temporal=True)
        add("temporal.identity_lock", "temporal", requires=("character.identity_consistency",), local="local:identity-lock", temporal=True)
        add("temporal.motion_lock", "temporal", requires=("motion.motion_field",), local="local:motion-lock", temporal=True)
        add("temporal.color_lock", "temporal", local="local:color-lock", temporal=True)
        add("temporal.flicker_detect", "temporal", requires=("temporal.consistency",), local="local:flicker-check", temporal=True)
        add("temporal.flicker_repair", "temporal", requires=("temporal.flicker_detect",), local="local:temporal-repair", gen=True, temporal=True, material=True)
        add("temporal.scene_lock", "temporal", requires=("scene.consistency",), local="local:scene-lock", temporal=True)

        # Direction, quality and artifact validation.
        add("shot.director", "shot", local="local:shot-spec")
        add("shot.storyboard", "shot", requires=("shot.director",), local="local:storyboard")
        add("shot.continuity", "shot", requires=("shot.storyboard",), local="local:continuity-check", temporal=True)
        add("quality.generation_gate", "quality", requires=("temporal.consistency",), local="local:generation-critic")
        add("quality.temporal_gate", "quality", requires=("temporal.flicker_detect",), local="local:temporal-critic")
        add("quality.identity_gate", "quality", requires=("temporal.identity_lock",), local="local:identity-critic")
        add("quality.artifact_validation", "quality", local="local:artifact-validator")
        add("quality.provenance_validation", "quality", requires=("runtime.provenance",), local="local:provenance-validator")
        add("quality.final_acceptance", "quality", requires=("quality.generation_gate","quality.artifact_validation","quality.provenance_validation"), local="local:acceptance-gate")

        self.items=C
        self.by_name={x.name:x for x in C}

    def get(self, name): return self.by_name.get(name)


class Stage15Intent:
    def parse(self, command: str, media: dict[str, Any]) -> dict[str, Any]:
        c=str(command or "").lower()
        def anyof(*terms): return any(t in c for t in terms)
        cinematic=anyof("cinematic","film","movie","legendary","beast","premium")
        generation=anyof("generate","create","make","add","replace","extend","animate","transform","turn into")
        image=anyof("image","photo","thumbnail","poster","picture") or str(media.get("kind","")).lower()=="image"
        video=anyof("video","reel","short","scene","shot","b-roll","broll") or bool(media.get("duration"))
        character=anyof("character","person","avatar","animate","human") or bool(media.get("character"))
        vfx=anyof("vfx","fog","mist","smoke","rain","snow","particle","effect","energy","fire") or cinematic
        repair=anyof("remove","replace","repair","restore","extend","background")
        audio_driven=anyof("lip sync","lipsync","beat driven","music driven","audio driven","talking")
        reference=anyof("reference","match this","use this image","same style")
        upscale=anyof("upscale","4k","8k","higher resolution")
        interpolate=anyof("slow motion","interpolate","smooth fps","60fps","120fps")
        offline=anyof("offline","local","private","on-device")
        return {
            "cinematic":cinematic,"generation":generation,"image":image,"video":video,
            "character":character,"vfx":vfx,"repair":repair,
            "temporal":video or bool(media.get("duration")),"offline":offline,
            "audio_driven":audio_driven,"reference":reference,"upscale":upscale,
            "interpolate":interpolate,
            "quality":1.0 if anyof("premium","legendary","ultra","best","beast","maximum") else .9,
            "has_command":bool(str(command or "").strip()),
        }


class Stage15Executor:
    """Deterministic Stage-15 planner/executor boundary with exhaustive validation."""
    CONTRACT_VERSION="15.2"
    def __init__(self, registry=None):
        self.registry=registry or Stage15CapabilityRegistry()
        self.intent=Stage15Intent()

    def _requested(self, command, media, intent):
        caps=["runtime.model_registry","runtime.resource_manager","runtime.device_probe","runtime.execution_boundary",
              "runtime.memory_budget","runtime.cache","runtime.batch_scheduler","runtime.chunk_scheduler",
              "runtime.cancellation","runtime.provenance","runtime.license_guard","runtime.safety_guard",
              "conditioning.text_prompt","shot.director","shot.storyboard","shot.continuity"]
        if intent["generation"]:
            caps += ["conditioning.negative_prompt","quality.artifact_validation","quality.provenance_validation"]
        if intent["reference"]:
            caps += ["conditioning.reference_image","conditioning.style","generation.image.reference_conditioning"]
        if intent["video"] and intent["generation"]:
            caps += ["generation.video.shot","generation.video.text_to_video","generation.video.image_to_video",
                     "generation.video.video_to_video","generation.video.continuation","generation.video.broll",
                     "generation.video.transition_shot","generation.video.establishing_shot"]
            if intent["audio_driven"]: caps += ["generation.video.audio_driven"]
        if intent["image"] and intent["generation"]:
            caps += ["generation.image.text_to_image","generation.image.variation","generation.image.inpaint",
                     "generation.image.outpaint","generation.image.relight","generation.image.style_transfer",
                     "generation.image.product_scene"]
        if intent["character"]:
            caps += ["conditioning.pose","character.pose","character.motion_transfer","character.identity_consistency",
                     "character.expression","character.multi_subject","character.avatar_motion"]
            if intent["audio_driven"]: caps += ["character.lipsync"]
        if intent["cinematic"]:
            caps += ["conditioning.depth","motion.camera","motion.camera_simulation","scene.depth_estimate",
                     "scene.depth_composite","scene.perspective_match","scene.camera_match","scene.lighting_match",
                     "scene.shadow_match","scene.reflection_match","scene.environment_reconstruction","scene.consistency"]
        if intent["vfx"]:
            caps += ["vfx.environment","vfx.particles","vfx.atmosphere","vfx.transformation","vfx.energy","vfx.physics_proxy"]
        if intent["repair"]:
            caps += ["conditioning.mask","repair.object_remove","repair.object_replace","repair.background_replace",
                     "repair.frame_extend","repair.scene_restore","repair.temporal_gap"]
        if intent["temporal"]:
            caps += ["temporal.consistency","temporal.color_lock","temporal.flicker_detect","temporal.flicker_repair","temporal.scene_lock"]
        if intent["character"]:
            caps += ["temporal.identity_lock"]
        if intent["interpolate"]:
            caps += ["generation.video.frame_interpolation","motion.motion_field","motion.smoothing"]
        if intent["upscale"]:
            caps += ["generation.video.upscale"] if intent["video"] else ["generation.image.variation"]
        caps += ["quality.generation_gate","quality.temporal_gate","quality.artifact_validation","quality.final_acceptance"]
        return list(dict.fromkeys(caps))

    def _topological(self, caps):
        order=[]; visiting=set(); done=set()
        def visit(n):
            if n in done: return
            if n in visiting: raise ValueError(f"dependency-cycle:{n}")
            visiting.add(n); item=self.registry.get(n)
            if item:
                for d in item.requires: visit(d)
            visiting.remove(n); done.add(n); order.append(n)
        for n in caps: visit(n)
        return order

    def _normalize_media(self, media):
        m=dict(media or {})
        errors=[]
        numeric={}
        for key in ("duration","fps","width","height"):
            if key in m:
                try: value=float(m[key])
                except Exception:
                    errors.append(f"invalid:{key}"); continue
                if not math.isfinite(value) or value < 0:
                    errors.append(f"invalid:{key}"); continue
                numeric[key]=value
        if numeric.get("width",0)>0 and numeric.get("height",0)>0 and numeric["width"]*numeric["height"]>100_000_000:
            errors.append("resolution-budget-exceeded")
        return m, sorted(set(errors))

    def _provider_for(self, cap, installed):
        providers=set(installed or ())
        external=f"stage15:{cap}"
        if external in providers: return external,"executed"
        item=self.registry.get(cap)
        if item and item.local_fallback and item.local_fallback.startswith("local:"): return item.local_fallback,"local"
        return item.local_fallback if item else None,"contract"

    def _parameters(self, cap, command, media, upstream, intent):
        def num(key, default=0.0):
            try:
                x=float(media.get(key, default) or default)
                return x if math.isfinite(x) and x >= 0 else default
            except Exception:
                return default
        return {
            "command":str(command),"duration":num("duration"),
            "width":int(num("width")),"height":int(num("height")),
            "fps":num("fps"),"upstream_fingerprint":str(upstream or ""),
            "style_digest":str(media.get("style_digest", "")),"editing_digest":str(media.get("editing_digest", "")),
            "quality_target":float(intent.get("quality",.9)),"offline":bool(intent.get("offline")),
            "deterministic":True,
        }

    def _artifact(self, cap, mode, provider, params):
        aid=digest({"capability":cap,"mode":mode,"provider":provider,"parameters":params})[:24]
        return {"artifact_id":aid,"kind":"generation_manifest","materialized":False,
                "provider":provider,"capability":cap,"deterministic":True,
                "provenance":{"contract_version":self.CONTRACT_VERSION,"source":"stage15"}}

    def _job(self, cap, command, media, installed, upstream, failure_inject, completed, intent):
        item=self.registry.get(cap)
        deps=list(item.requires if item else ())
        missing=[d for d in deps if d not in completed]
        provider,mode=self._provider_for(cap,installed)
        issues=[]; repaired=False; attempts=1
        if cap in failure_inject:
            issues.append("provider-failure-injected")
            provider=item.local_fallback if item else None
            mode="local" if provider and str(provider).startswith("local:") else "deferred"
            repaired=mode=="local"; attempts+=1
        if missing:
            issues.append("dependency-not-completed"); mode="deferred"
        if mode=="contract": issues.append("runtime-not-installed")
        params=self._parameters(cap,command,media,upstream,intent)
        status="deferred" if mode=="deferred" else ("contract" if mode=="contract" else "executed")
        score=.97 if mode in {"local","executed"} else .84
        if issues and mode not in {"local"}: score-=.05
        artifact=self._artifact(cap,mode,provider,params) if status!="deferred" else None
        return ExecutionJob(cap,status,mode,provider,item.local_fallback if item else None,deps,params,clamp(score),attempts,repaired,sorted(set(issues)),artifact)

    def plan(self, command, media=None, installed=(), upstream=None, failure_inject=()):
        media,media_errors=self._normalize_media(media)
        upstream=upstream if isinstance(upstream,dict) else {"fingerprint":str(upstream or "")}
        upstream_fp=str(upstream.get("fingerprint",""))
        intent=self.intent.parse(command,media)
        requested=self._requested(command,media,intent)
        ordered=self._topological(requested)
        requested=ordered[:]
        completed=set(); jobs=[]
        for cap in ordered:
            job=self._job(cap,command,media,installed,upstream_fp,set(failure_inject or ()),completed,intent)
            jobs.append(job)
            if job.status in {"executed","contract"}: completed.add(cap)
        scores=[j.quality_score for j in jobs]; deferred=sum(j.status=="deferred" for j in jobs)
        result={"stage":15,"contract_version":self.CONTRACT_VERSION,"ok":True,"command":str(command),"intent":intent,
                "requested_capabilities":requested,"execution_order":ordered,"jobs":[asdict(j) for j in jobs],
                "coverage":{"requested":len(requested),"completed":len(completed),"executed":sum(j.status=="executed" for j in jobs),
                            "contract":sum(j.status=="contract" for j in jobs),"deferred":deferred},
                "quality_gate":{"score":clamp(sum(scores)/max(1,len(scores))),"threshold":.88,
                                 "passed":deferred==0 and sum(scores)/max(1,len(scores))>=.88},
                "repair_count":sum(j.attempts-1 for j in jobs),
                "runtime_policy":"external/generative providers execute only when explicitly installed; local primitives emit deterministic manifests unless they are real executable adapters",
                "artifact_policy":"artifact manifests never claim rendered/generated pixels; materialization requires an executable runtime",
                "resource_policy":{"memory_aware":True,"batching":True,"chunking":True,"cancellable":True,"cacheable":True},
                "provenance":{"stage":15,"contract_version":self.CONTRACT_VERSION,"upstream_fingerprint":upstream_fp,
                              "style_digest":str(media.get("style_digest","")),"editing_digest":str(media.get("editing_digest",""))},
                "handoff":{"upstream":"14","upstream_fingerprint":upstream_fp,"downstream":"15 generation/execution",
                            "non_destructive":True,"contract_version":self.CONTRACT_VERSION},
                "validation_errors":[]}
        result["validation_errors"]=sorted(set(media_errors+self.validate(result)))
        result["ok"]=not result["validation_errors"]
        # Fingerprint excludes itself, making replay deterministic.
        result["fingerprint"]=digest(result)
        return result

    def validate(self,result):
        errors=[]
        if result.get("stage")!=15: errors.append("stage-id")
        if result.get("contract_version")!=self.CONTRACT_VERSION: errors.append("contract-version")
        if not isinstance(result.get("jobs"),list) or not result["jobs"]: errors.append("jobs")
        seen=set()
        for j in result.get("jobs",[]):
            for f in ("capability","status","mode","provider","fallback","dependencies","parameters","quality_score","attempts","repaired","issues","artifact"):
                if f not in j: errors.append(f"job-missing:{f}")
            cap=j.get("capability")
            if cap in seen: errors.append("duplicate-capability")
            seen.add(cap)
            if cap not in self.registry.by_name: errors.append(f"unknown-capability:{cap}")
            if j.get("status") not in {"executed","contract","deferred"}: errors.append("status")
            if not 0<=float(j.get("quality_score",0))<=1: errors.append("score")
            if j.get("attempts",0)<1: errors.append("attempts")
            if j.get("status")=="deferred" and j.get("artifact") is not None: errors.append("deferred-artifact")
            if j.get("status")=="executed" and j.get("mode") not in {"executed","local"}: errors.append("executed-mode")
            if j.get("status")=="contract" and j.get("mode")!="contract": errors.append("contract-mode")
            if j.get("status") in {"executed","contract"} and not j.get("artifact"): errors.append("missing-artifact")
        if len(set(result.get("execution_order",[])))!=len(result.get("execution_order",[])): errors.append("duplicate-execution-order")
        if set(result.get("execution_order",[])) != set(result.get("requested_capabilities",[])): errors.append("execution-coverage-mismatch")
        return sorted(set(errors))

    def replay(self,result):
        expected=result.get("fingerprint"); clone=dict(result); clone.pop("fingerprint",None)
        recomputed=digest(clone); errors=self.validate(result)
        return {"valid":not errors and bool(expected),"match":bool(expected) and expected==recomputed,
                "fingerprint":expected,"recomputed_fingerprint":recomputed,"validation_errors":errors}

    def stress(self,command,media=None,iterations=10000,installed=(),failure_inject=()):
        iterations=max(1,min(int(iterations),250000)); fps=set(); failures=[]
        for i in range(iterations):
            r=self.plan(command,media,installed,failure_inject=failure_inject); rp=self.replay(r)
            if not r["ok"] or not rp["match"]: failures.append(i)
            fps.add(r.get("fingerprint"))
        return {"iterations":iterations,"passed":iterations-len(failures),"failed":len(failures),
                "deterministic":len(fps)==1,"fingerprints":len(fps),"failure_indices":failures[:20]}

    def audit_matrix(self,cases):
        reports=[]
        for c in cases:
            r=self.plan(c.get("command",""),c.get("media",{}),c.get("installed",()),c.get("upstream"),c.get("failure_inject",()))
            reports.append({"name":c.get("name","case"),"ok":r["ok"],"coverage":r["coverage"],"quality":r["quality_gate"],"validation_errors":r["validation_errors"]})
        return {"cases":len(reports),"passed":sum(x["ok"] for x in reports),"failed":sum(not x["ok"] for x in reports),"reports":reports}

    def capability_audit(self):
        families={}
        for x in self.registry.items: families.setdefault(x.family,[]).append(x.name)
        return {"capabilities":len(self.registry.items),"families":{k:sorted(v) for k,v in families.items()},"contract_version":self.CONTRACT_VERSION}
