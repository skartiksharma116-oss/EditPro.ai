import random,string,time,sys
from stage16_creative_brain import Stage16CreativeBrain
from stage17_final_completion import Stage17FinalCompletion
from stage18_scale_hardening import Stage18ScaleHardening
from editpro_pipeline import EditProPipeline

def fuzz_text(r,n): return ''.join(r.choice(string.printable) for _ in range(n))

# Deterministic deep isolated stress
r=random.Random(180000)
for cls, count in [(Stage16CreativeBrain,50000),(Stage17FinalCompletion,50000),(Stage18ScaleHardening,100000)]:
    s=cls(); t=time.time()
    for i in range(count):
        if cls is Stage16CreativeBrain:
            p=s.plan(fuzz_text(r,80), media={'duration':r.random()*100000,'width':r.choice([0,1920,3840,'bad',None]),'height':r.choice([0,1080,2160,'x']), 'fps':r.choice([24,30,60,-1,'bad'])}, visual=[], speech={}, stage15={})
        elif cls is Stage17FinalCompletion:
            p=s.plan(fuzz_text(r,80), {'duration':r.random()*100000,'width':r.choice([0,1920,'bad']),'height':r.choice([0,1080,'x']),'fps':r.choice([24,30,60,-1]),'target_format':fuzz_text(r,25)}, {})
        else:
            p=s.plan(fuzz_text(r,80), {'ram_mb':r.choice([256,1024,4096,16384,'bad',float('nan')]),'vram_mb':r.choice([0,2048,8192,'x',float('inf')]),'cpu_cores':r.choice([1,4,16,64,-1,'x'])},{'clip_count':r.choice([0,100,10000,100000,'x']),'duration_s':r.choice([0,60,3600,100000,'bad',float('nan')])},{'final_feature_digest':fuzz_text(r,20)})
        q=s.qa(p)
        if q['status'] not in ('PASS','REPAIR'): raise AssertionError((cls.__name__,i,q))
    print(cls.__name__,count,'PASS',round(time.time()-t,2),'s',flush=True)

# Cross-stage integration stress. Keep media bounded to avoid creating giant objects.
p=EditProPipeline(); t=time.time()
for i in range(1000):
    fmt=r.choice(['reel','youtube','landscape','square','story'])
    result=p.run_from_signals(fuzz_text(r,120), {'duration':r.random()*7200,'width':r.choice([720,1080,1920,3840]),'height':r.choice([720,1080,1920,2160]),'fps':r.choice([24,25,30,60]),'target_format':fmt,'hardware':{'ram_mb':r.choice([2048,4096,8192,16384]),'vram_mb':r.choice([0,2048,4096,8192]),'cpu_cores':r.choice([2,4,8,16])}})
    if not result.get('stages',{}).get('18',{}).get('inspection',{}).get('ok',False): raise AssertionError(('pipeline',i,result.get('stages',{}).get('18')))
print('PIPELINE_0_TO_18_1000 PASS',round(time.time()-t,2),'s',flush=True)
