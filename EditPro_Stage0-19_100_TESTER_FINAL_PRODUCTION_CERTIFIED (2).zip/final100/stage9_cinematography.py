"""EditPro.ai Stage 9: AI Cinematography Director.

Local-first deterministic director layer above Stage 8.
It converts media/visual/speech/timeline signals into an editorial shot plan.
Optional accelerators (PySceneDetect, PyAV, MediaPipe) are capability contracts;
the core remains dependency-light and CPU-safe.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple
import hashlib, json, math, re

SHOT_SCALES = {"extreme_wide","wide","medium","medium_close","close_up","extreme_close"}
SHOT_ANGLES = {"eye_level","low","high","overhead","dutch"}
CAMERA_MOVES = {"static","push_in","pull_out","pan_left","pan_right","tilt_up","tilt_down","orbit","tracking","handheld","crane"}
TRANSITIONS = {"cut","crossfade","dip_black","dip_white","match_cut","whip_pan","speed_ramp"}
MOODS = {"neutral","energetic","cinematic","emotional","romantic","uplifting","dark","calm","dramatic","documentary","luxury","epic"}
PACING = {"slow","adaptive","fast","beat","dialogue","trailer"}
FORMATS = {"square","portrait","landscape","reel","story","youtube","thumbnail","banner"}


def _finite(*xs: float) -> bool:
    return all(math.isfinite(float(x)) for x in xs)

def _clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(v)))

def _norm_label(x: Any) -> str:
    return re.sub(r"[^a-z0-9_ -]+", "", str(x or "").lower()).strip() or "scene"

@dataclass
class SubjectSignal:
    label: str
    confidence: float = 0.0
    x: float = 0.5
    y: float = 0.5
    w: float = 0.2
    h: float = 0.2
    importance: float = 0.5
    motion: float = 0.0
    def validate(self):
        if not self.label or not _finite(self.confidence,self.x,self.y,self.w,self.h,self.importance,self.motion):
            raise ValueError("invalid subject signal")
        if not all(0 <= v <= 1 for v in (self.confidence,self.x,self.y,self.w,self.h,self.importance,self.motion)):
            raise ValueError("subject values out of range")

@dataclass
class NarrativeBeat:
    start: int
    end: int
    kind: str = "scene"
    intensity: float = 0.5
    speech: bool = False
    keywords: List[str] = field(default_factory=list)
    def validate(self):
        if self.start < 0 or self.end <= self.start or not _finite(self.intensity): raise ValueError("invalid beat")
        if not 0 <= self.intensity <= 1: raise ValueError("invalid beat intensity")

@dataclass
class ShotCandidate:
    id: str
    start: int
    end: int
    scale: str = "medium"
    angle: str = "eye_level"
    movement: str = "static"
    subject: str = "scene"
    score: float = 0.0
    reason: str = ""
    transition_in: str = "cut"
    transition_out: str = "cut"
    crop_x: float = 0.5
    crop_y: float = 0.5
    focus_priority: float = 1.0
    source_hint: str = "original"
    energy: float = 0.5
    composition: str = "balanced"
    headroom: float = 0.5
    lead_room: float = 0.5
    screen_direction: str = "neutral"
    lens_hint: str = "natural"
    def validate(self):
        if not self.id or self.start < 0 or self.end <= self.start: raise ValueError("invalid shot")
        if self.scale not in SHOT_SCALES or self.angle not in SHOT_ANGLES or self.movement not in CAMERA_MOVES: raise ValueError("invalid shot vocabulary")
        if self.transition_in not in TRANSITIONS or self.transition_out not in TRANSITIONS: raise ValueError("invalid transition")
        if not all(0 <= v <= 1 for v in (self.score,self.focus_priority,self.crop_x,self.crop_y,self.energy,self.headroom,self.lead_room)): raise ValueError("invalid shot score/crop")
        if self.composition not in {"balanced","rule_of_thirds","centered","leading_space","symmetrical","negative_space"}: raise ValueError("invalid composition")
        if self.screen_direction not in {"neutral","left_to_right","right_to_left"}: raise ValueError("invalid screen direction")
        if self.lens_hint not in {"wide","natural","telephoto","macro"}: raise ValueError("invalid lens hint")

@dataclass
class DirectorConfig:
    style: str = "cinematic"
    pacing: str = "adaptive"
    target_format: str = "landscape"
    intensity: float = 0.55
    max_shots: int = 120
    min_shot_frames: int = 8
    max_shot_frames: int = 180
    preserve_dialogue: bool = True
    continuity_strict: bool = True
    avoid_excessive_motion: bool = True
    protect_faces: bool = True
    smart_reframe: bool = True
    scene_detection: bool = True
    beat_sync: bool = True
    honor_scene_boundaries: bool = True
    preserve_establishing_shots: bool = True
    composition_guidance: bool = True
    eyeline_protection: bool = True
    max_motion_streak: int = 2
    quality_floor: float = 0.48
    def validate(self):
        if self.pacing not in PACING: raise ValueError("invalid pacing")
        if self.target_format not in FORMATS: raise ValueError("invalid format")
        if not _finite(self.intensity,self.quality_floor) or not 0 <= self.intensity <= 1 or not 0 <= self.quality_floor <= 1: raise ValueError("invalid intensity")
        if self.max_shots < 1 or self.max_shot_frames < self.min_shot_frames or self.min_shot_frames < 1: raise ValueError("invalid shot bounds")
        if self.max_motion_streak < 0: raise ValueError("invalid motion streak")

@dataclass
class CinematographyPlan:
    fps: int
    duration_frames: int
    mood: str
    visual_strategy: str
    shots: List[ShotCandidate] = field(default_factory=list)
    camera_keyframes: List[Dict[str,Any]] = field(default_factory=list)
    continuity_notes: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str,Any] = field(default_factory=dict)
    digest: str = ""
    def validate(self):
        if self.fps <= 0 or self.duration_frames <= 0: raise ValueError("invalid timeline")
        if self.mood not in MOODS: raise ValueError("invalid mood")
        prev = 0
        for i,s in enumerate(self.shots):
            s.validate()
            if i == 0 and s.start != 0: raise ValueError("shots must start at frame zero")
            if i and s.start != prev: raise ValueError("shots must provide continuous coverage")
            prev = s.end
        if self.shots and self.shots[-1].end != self.duration_frames: raise ValueError("shots must cover full duration")
        for k in self.camera_keyframes:
            if int(k.get("frame",-1)) < 0 or int(k.get("frame",-1)) > self.duration_frames: raise ValueError("camera keyframe outside timeline")

class CinematographyAnalyzer:
    """Normalizes heterogeneous signals without inventing unavailable evidence."""
    @staticmethod
    def analyze(command: str, visual: Optional[List[Dict[str,Any]]] = None,
                speech: Optional[Dict[str,Any]] = None, media: Optional[Dict[str,Any]] = None,
                timeline: Optional[Dict[str,Any]] = None) -> Dict[str,Any]:
        text=(command or "").lower().strip()
        if not text: raise ValueError("command required")
        visual=visual or []; speech=speech or {}; media=media or {}; timeline=timeline or {}
        mood="cinematic"
        mood_words={
            "emotional":"emotional","sad":"emotional","calm":"calm","peaceful":"calm","documentary":"documentary",
            "dramatic":"dramatic","dark":"dark","hype":"energetic","energetic":"energetic","fast":"energetic",
            "romantic":"romantic","happy":"uplifting","uplifting":"uplifting","luxury":"luxury","premium":"luxury","epic":"epic"
        }
        for k,v in mood_words.items():
            if re.search(r"\b"+re.escape(k)+r"\b",text): mood=v; break
        pacing="adaptive"
        if "dialogue" in text or "talking" in text or "interview" in text: pacing="dialogue"
        if any(x in text for x in ("slow","emotional","cinematic","calm")): pacing="slow"
        if any(x in text for x in ("fast","hype","viral","energetic","shorts")): pacing="fast"
        if "beat" in text or "music" in text: pacing="beat"
        if "trailer" in text: pacing="trailer"
        subjects=[]
        for obj in ("person","face","car","product","character","logo","text","landscape","building","road","sky","food","group","hand","action"):
            if re.search(r"\b"+re.escape(obj)+r"\b",text): subjects.append(obj)
        subject_signals=[]
        for item in visual:
            if not isinstance(item,dict): continue
            label=_norm_label(item.get("label") or item.get("class") or "scene")
            if label not in subjects: subjects.append(label)
            try:
                subject_signals.append(asdict(SubjectSignal(label,_clamp(float(item.get("confidence",item.get("score",0.7)))),_clamp(float(item.get("x",item.get("cx",0.5)))),_clamp(float(item.get("y",item.get("cy",0.5)))),_clamp(float(item.get("w",0.2))),_clamp(float(item.get("h",0.2))),_clamp(float(item.get("importance",item.get("confidence",0.5)))),_clamp(float(item.get("motion",0))))))
            except (TypeError,ValueError):
                continue
        if not subjects: subjects=["scene"]
        transcript=speech.get("transcript") if isinstance(speech,dict) else None
        speech_count=len(transcript) if isinstance(transcript,list) else 0
        speech_segments=speech.get("segments",[]) if isinstance(speech,dict) else []
        beats=[]
        for b in timeline.get("beats",[]) if isinstance(timeline,dict) else []:
            if isinstance(b,dict):
                try: beats.append(asdict(NarrativeBeat(int(b.get("start",0)),int(b.get("end",1)),str(b.get("kind","scene")),_clamp(float(b.get("intensity",0.5))),bool(b.get("speech",False)),[str(x) for x in b.get("keywords",[])])))
                except (TypeError,ValueError): pass
        return {"mood":mood,"pacing":pacing,"subjects":list(dict.fromkeys(subjects)),"subject_signals":subject_signals,
                "visual_samples":len(visual),"speech_words":speech_count,"speech_segments":speech_segments,"beats":beats,
                "duration":float(media.get("duration",0) or 0),"fps":float(media.get("fps",30) or 30),
                "camera_motion":timeline.get("camera_motion",[]) if isinstance(timeline,dict) else [],
                "music_beats":timeline.get("music_beats",[]) if isinstance(timeline,dict) else [],
                "scene_cuts":timeline.get("scene_cuts",[]) if isinstance(timeline,dict) else [],
                "format":timeline.get("format") if isinstance(timeline,dict) else None}

class ShotPlanner:
    def __init__(self, config: DirectorConfig | None = None):
        self.config=config or DirectorConfig(); self.config.validate()

    def _shot_len(self,mood:str,fps:int,energy:float=0.5)->int:
        base={"slow":72,"adaptive":45,"fast":22,"beat":30,"dialogue":70,"trailer":28}[self.config.pacing]
        if mood in {"emotional","calm","romantic"}: base=max(base,60)
        if mood in {"energetic","dramatic","epic"}: base=min(base,34)
        if energy > .78: base=max(self.config.min_shot_frames,int(base*.72))
        return max(self.config.min_shot_frames,min(self.config.max_shot_frames,base))

    def _subject_at(self, analysis:Dict[str,Any], idx:int)->SubjectSignal:
        raw=analysis.get("subject_signals") or []
        if raw:
            x=raw[idx%len(raw)]
            try:
                s=SubjectSignal(**x); s.validate(); return s
            except Exception: pass
        label=(analysis.get("subjects") or ["scene"])[idx%len(analysis.get("subjects") or ["scene"])]
        return SubjectSignal(str(label),.55,.5,.5,.28,.35,.55,.1)

    def _crop_for_format(self,s:SubjectSignal)->Tuple[float,float]:
        # Bias crop toward subject center while leaving a safety margin for faces/action.
        return (_clamp(s.x),_clamp(s.y))

    def _choose_scale(self,mood:str,idx:int,subject:SubjectSignal)->str:
        if subject.label in {"face","person","character"} and subject.confidence >= .65:
            return ["medium_close","close_up","medium"][idx%3]
        if mood in {"emotional","romantic","dramatic"}: return ["wide","medium_close","close_up","medium"][idx%4]
        if mood in {"energetic","epic"}: return ["wide","medium","close_up","medium_close"][idx%4]
        return ["wide","medium","medium_close","close_up"][idx%4]

    def _choose_move(self,mood:str,idx:int,subject:SubjectSignal)->str:
        if subject.motion > .7: return "tracking"
        if mood in {"cinematic","emotional","romantic","luxury"}: return ["static","push_in","pan_right","pull_out"][idx%4]
        if mood in {"energetic","epic"}: return ["tracking","push_in","pan_left","handheld"][idx%4]
        if mood=="dramatic": return ["static","push_in","handheld"][idx%3]
        return "static" if idx%3 else "pan_right"

    def _transition(self,mood:str,idx:int)->str:
        if idx==0: return "crossfade"
        if mood in {"calm","emotional","romantic","luxury"} and idx%4==0: return "crossfade"
        if mood in {"energetic","epic"} and idx%4==3: return "whip_pan"
        if mood=="dramatic" and idx%5==4: return "dip_black"
        return "cut"

    def _composition(self, subject: SubjectSignal, movement: str, idx: int) -> tuple[str,float,float,str,str]:
        if subject.label in {"face","person","character"}:
            # Keep eyes comfortably inside the safe area and leave lead room in the motion direction.
            headroom = _clamp(0.42 + (0.08 if subject.y > 0.55 else -0.02))
            direction = "right_to_left" if idx % 2 else "left_to_right"
            comp = "rule_of_thirds" if idx % 3 else "leading_space"
            lens = "telephoto" if movement in {"push_in","tracking"} else "natural"
            return comp, headroom, 0.62, direction, lens
        if subject.label in {"landscape","building","road","sky"}:
            return ("negative_space" if idx % 2 else "rule_of_thirds"), 0.5, 0.5, "neutral", "wide"
        if subject.label in {"product","food","logo"}:
            return "centered" if idx % 2 else "symmetrical", 0.5, 0.5, "neutral", "macro" if subject.label in {"product","food"} else "natural"
        return "balanced", 0.5, 0.5, "neutral", "natural"

    @staticmethod
    def _timeline_frame(value: Any, fps: int, duration: int) -> Optional[int]:
        """Normalize timeline positions from explicit frame/second payloads or safe numeric heuristics."""
        try:
            if isinstance(value, dict):
                if "frame" in value:
                    x=float(value["frame"]); return max(1,min(duration-1,int(round(x))))
                if "frames" in value:
                    x=float(value["frames"]); return max(1,min(duration-1,int(round(x))))
                if "second" in value: value=value["second"]
                elif "seconds" in value: value=value["seconds"]
                elif "time" in value: value=value["time"]
                else: return None
                x=float(value)
                return max(1,min(duration-1,int(round(x*fps))))
            x=float(value)
            if not math.isfinite(x) or x < 0: return None
            duration_seconds=duration/max(1,fps)
            # Values inside the media's real-time duration are treated as seconds.
            # Larger values are treated as frame numbers. This removes the exact-duration
            # ambiguity that previously turned a 3.0-second cut into frame 3 at 30 fps.
            if x <= duration_seconds + 1e-9:
                frame=int(round(x*fps))
            else:
                frame=int(round(x))
            return max(1,min(duration-1,frame))
        except (TypeError,ValueError,OverflowError):
            return None

    @staticmethod
    def _boundary_frame(value: Any, fps: int, duration: int) -> Optional[int]:
        return ShotPlanner._timeline_frame(value, fps, duration)

    def _keyframes(self,shots:List[ShotCandidate],duration:int)->List[Dict[str,Any]]:
        out=[]
        for s in shots:
            end_scale={"push_in":1.10,"pull_out":.92,"tracking":1.04,"handheld":1.015}.get(s.movement,1.0)
            dx={"pan_left":-.035,"pan_right":.035}.get(s.movement,0.0)
            dy={"tilt_up":-.035,"tilt_down":.035}.get(s.movement,0.0)
            out.append({"frame":s.start,"shot_id":s.id,"movement":s.movement,"scale":1.0,"x":s.crop_x,"y":s.crop_y,"easing":"ease_in_out"})
            out.append({"frame":s.end,"shot_id":s.id,"movement":s.movement,"scale":end_scale,"x":_clamp(s.crop_x+dx),"y":_clamp(s.crop_y+dy),"easing":"ease_in_out"})
        return out

    def plan(self,analysis:Dict[str,Any],fps:int,duration_frames:int)->CinematographyPlan:
        if fps<=0 or duration_frames<=0: raise ValueError("invalid timeline")
        mood=analysis.get("mood") if analysis.get("mood") in MOODS else "cinematic"
        subjects=analysis.get("subjects") or ["scene"]
        beats=[NarrativeBeat(**b) for b in analysis.get("beats",[]) if isinstance(b,dict)]
        for b in beats:
            b.start=max(0,min(duration_frames-1,b.start)); b.end=max(b.start+1,min(duration_frames,b.end)); b.validate()
        shots=[]; frame=0; idx=0; previous_move="static"; motion_streak=0
        boundaries={}
        if self.config.honor_scene_boundaries:
            for raw in analysis.get("scene_cuts",[]):
                bf=self._boundary_frame(raw,fps,duration_frames)
                if bf is not None: boundaries[bf]="scene_cut"
        while frame<duration_frames and len(shots)<self.config.max_shots:
            beat=next((b for b in beats if b.start<=frame<b.end),None)
            energy=beat.intensity if beat else (0.72 if mood in {"energetic","epic","dramatic"} else .48)
            step=self._shot_len(mood,fps,energy)
            if self.config.preserve_dialogue and analysis.get("speech_segments"):
                for seg in analysis["speech_segments"]:
                    if isinstance(seg,dict):
                        try:
                            ss=int(round(float(seg.get("start",0))*fps)); ee=int(round(float(seg.get("end",0))*fps))
                            if ss<=frame<ee: step=max(step,min(self.config.max_shot_frames,ee-frame)); break
                        except (TypeError,ValueError): pass
            if self.config.beat_sync and analysis.get("music_beats"):
                for mb in analysis["music_beats"]:
                    try:
                        bf=self._timeline_frame(mb,fps,duration_frames)
                        if bf is not None and frame<bf<frame+step and bf-frame>=self.config.min_shot_frames: step=bf-frame; break
                    except (TypeError,ValueError): continue
            end=min(duration_frames,frame+step)
            if self.config.honor_scene_boundaries:
                next_cut=min((b for b in boundaries if frame < b < end), default=None)
                if next_cut is not None and next_cut-frame >= self.config.min_shot_frames: end=next_cut
            if self.config.beat_sync:
                next_beat=min((b.end for b in beats if frame < b.end < end), default=None)
                if next_beat is not None and next_beat-frame >= self.config.min_shot_frames: end=next_beat
            subject=self._subject_at(analysis,idx)
            scale=self._choose_scale(mood,idx,subject)
            move=self._choose_move(mood,idx,subject)
            if self.config.avoid_excessive_motion and move!="static" and motion_streak >= self.config.max_motion_streak: move="static"
            transition=self._transition(mood,idx)
            if self.config.preserve_establishing_shots and idx == 0: scale="wide" if subject.label not in {"face","person","character"} else scale
            composition, headroom, lead_room, screen_direction, lens_hint = self._composition(subject, move, idx) if self.config.composition_guidance else ("balanced",.5,.5,"neutral","natural")
            if self.config.continuity_strict and previous_move in {"pan_left","pan_right"} and move in {"pan_left","pan_right"} and previous_move!=move:
                move="static"
            crop_x,crop_y=self._crop_for_format(subject) if self.config.smart_reframe else (.5,.5)
            kind=beat.kind if beat else "scene"
            reason=f"{mood}/{self.config.pacing}; {kind}; prioritize {subject.label}; {scale}; {move}"
            score=_clamp(.55+.22*subject.confidence+.12*subject.importance+.08*energy)
            if score<self.config.quality_floor: score=self.config.quality_floor
            if self.config.continuity_strict and screen_direction != "neutral" and idx > 0:
                prev_dir=shots[-1].screen_direction
                if prev_dir != "neutral" and prev_dir != screen_direction: screen_direction="neutral"
            shots.append(ShotCandidate(f"shot-{idx:04d}",frame,end,scale,"eye_level",move,subject.label,score,reason,transition,"cut",crop_x,crop_y,_clamp(subject.importance+.25),"original",energy,composition,headroom,lead_room,screen_direction,lens_hint))
            motion_streak = motion_streak + 1 if move != "static" else 0
            previous_move=move; frame=end; idx+=1
        # If max_shots was reached, merge the tail rather than silently leaving uncovered frames.
        if frame<duration_frames and shots:
            shots[-1].end=duration_frames
        notes=["Maintain screen direction across adjacent shots.","Protect primary subject from edge cropping.","Prefer motivated camera movement over movement for its own sake."]
        if analysis.get("speech_words"): notes.append("Protect dialogue cadence: avoid cutting mid-utterance where timing signals are available.")
        if self.config.continuity_strict: notes.append("Apply 180-degree-axis continuity unless the user explicitly requests a stylized break.")
        if self.config.avoid_excessive_motion: notes.append("Limit consecutive moving-camera shots to reduce visual fatigue.")
        if self.config.smart_reframe: notes.append("Use subject-aware crop centers for portrait/reel/story framing.")
        warnings=[]
        if not analysis.get("subject_signals"): warnings.append("No object/face coordinates supplied; center-safe framing fallback used.")
        if not analysis.get("beats"): warnings.append("No explicit narrative beats supplied; adaptive pacing fallback used.")
        if self.config.honor_scene_boundaries and not analysis.get("scene_cuts"): warnings.append("No scene-cut boundaries supplied; shot planner used adaptive timing.")
        strategy=f"{mood} / {self.config.pacing} / {self.config.target_format} / continuity={self.config.continuity_strict} / smart_reframe={self.config.smart_reframe}"
        plan=CinematographyPlan(fps,duration_frames,mood,strategy,shots,self._keyframes(shots,duration_frames),notes,warnings,
            {"subjects":subjects,"capabilities":{"scene_detection":"optional","pyav":"optional","mediapipe":"optional","ffmpeg":"local","opentimelineio":"optional"},"director_version":"9.2"})
        plan.validate(); plan.digest=self.digest(plan); return plan

    @staticmethod
    def digest(plan:CinematographyPlan)->str:
        data=asdict(plan); data["digest"]=""
        return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()

class Stage9Pipeline:
    """Public Stage 9 facade."""
    def analyze(self,command,visual=None,speech=None,media=None,timeline=None):
        return CinematographyAnalyzer.analyze(command,visual,speech,media,timeline)
    def plan(self,command,visual=None,speech=None,media=None,*,fps=30,duration_frames=90,target_format="landscape",style="cinematic",timeline=None):
        a=self.analyze(command,visual,speech,media,timeline)
        pacing=a.get("pacing","adaptive")
        cfg=DirectorConfig(style=style,target_format=target_format if target_format in FORMATS else "landscape",pacing=pacing)
        return ShotPlanner(cfg).plan(a,fps,duration_frames)
    def inspect(self,plan:CinematographyPlan)->Dict[str,Any]:
        plan.validate(); moves={}; transitions={}; scales={}
        for s in plan.shots:
            moves[s.movement]=moves.get(s.movement,0)+1; transitions[s.transition_in]=transitions.get(s.transition_in,0)+1; scales[s.scale]=scales.get(s.scale,0)+1
        return {"ok":True,"shots":len(plan.shots),"coverage_frames":sum(s.end-s.start for s in plan.shots),"duration_frames":plan.duration_frames,
                "coverage_ratio":sum(s.end-s.start for s in plan.shots)/plan.duration_frames,"movement_mix":moves,"transition_mix":transitions,"scale_mix":scales,
                "digest":plan.digest,"continuity_notes":len(plan.continuity_notes),"warnings":list(plan.warnings)}

    def export_otio(self, plan: CinematographyPlan) -> Dict[str, Any]:
        """Return an OTIO-compatible editorial interchange payload without requiring OTIO."""
        plan.validate()
        clips=[]
        for s in plan.shots:
            clips.append({"name":s.id,"source_range":{"start_time":s.start,"duration":s.end-s.start},"metadata":{
                "scale":s.scale,"angle":s.angle,"movement":s.movement,"subject":s.subject,
                "composition":s.composition,"lens_hint":s.lens_hint,"screen_direction":s.screen_direction}})
        return {"schema":"OTIO-compatible","rate":plan.fps,"duration":plan.duration_frames,"tracks":[{"kind":"Video","clips":clips}],"metadata":{"editpro_stage":9,"digest":plan.digest}}

# Optional capability contracts. These never become mandatory dependencies.
class CapabilityRegistry:
    PROVIDERS={"PySceneDetect":"shot/scene boundary detection","PyAV":"precise FFmpeg frame access","MediaPipe":"on-device face/pose/hand landmarks","FFmpeg":"local render/filter backend","OpenTimelineIO":"editorial timeline interchange"}
    @classmethod
    def available(cls)->Dict[str,bool]:
        out={}
        for name in cls.PROVIDERS:
            try:
                mod={"PySceneDetect":"scenedetect","PyAV":"av","MediaPipe":"mediapipe","FFmpeg":"ffmpeg"}.get(name)
                if name=="OpenTimelineIO": mod="opentimelineio"
                __import__(mod); out[name]=True
            except Exception: out[name]=False
        return out
