"""EditPro.ai Stage 11: AI Meme Engine.

Local-first, deterministic meme-placement intelligence. The engine never downloads
or scrapes meme assets. It works with an explicit asset catalog supplied by the app,
with provenance/license metadata so only approved/licensed/public-domain assets are
eligible for automatic selection.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import hashlib, json, math, re

EMOTIONS={"neutral","funny","awkward","shock","surprise","happy","sad","angry","dramatic","wholesome","confused","excited","embarrassed"}
FORMATS={"square","portrait","landscape","reel","story","youtube","thumbnail","banner","instagram_post","instagram_story","youtube_thumbnail","youtube_banner"}
ASSET_TYPES={"image","gif","video","sticker","text","audio_reaction"}
LICENSE_CLASSES={"licensed","public_domain","user_owned","app_approved"}
MEME_STYLES={"subtle","reaction","caption","chaotic","cinematic","minimal","classic"}

def finite(*xs): return all(math.isfinite(float(x)) for x in xs)
def clamp(v,lo=0.,hi=1.): return max(lo,min(hi,float(v)))
def norm(x): return re.sub(r"[^a-z0-9_ -]+","",str(x or "").lower()).strip()

@dataclass
class MemeAsset:
    id:str
    path:str=""
    asset_type:str="image"
    license_class:str="app_approved"
    tags:List[str]=field(default_factory=list)
    emotions:List[str]=field(default_factory=list)
    style:str="classic"
    duration:float=0.0
    audio:bool=False
    width:int=0
    height:int=0
    source_uri:str=""
    attribution:str=""
    def __post_init__(self):
        self.validate()
    def validate(self):
        if not self.id or self.asset_type not in ASSET_TYPES or self.license_class not in LICENSE_CLASSES: raise ValueError("invalid meme asset")
        if self.style not in MEME_STYLES or not finite(self.duration): raise ValueError("invalid meme asset style/duration")
        if self.duration<0 or self.width<0 or self.height<0: raise ValueError("invalid meme asset dimensions")
        if any(not isinstance(x,str) for x in self.tags+self.emotions): raise ValueError("invalid meme asset tags")
        if any(e not in EMOTIONS for e in self.emotions): raise ValueError("invalid meme asset emotion")

@dataclass
class MemeMoment:
    start:float
    end:float
    emotion:str="funny"
    confidence:float=.7
    intensity:float=.6
    keywords:List[str]=field(default_factory=list)
    dialogue:bool=False
    beat:bool=False
    motion:float=0.
    novelty:float=.7
    def validate(self):
        if not finite(self.start,self.end,self.confidence,self.intensity,self.motion,self.novelty): raise ValueError("invalid meme moment")
        if self.start<0 or self.end<=self.start or not 0<=self.confidence<=1 or not 0<=self.intensity<=1 or not 0<=self.motion<=1 or not 0<=self.novelty<=1: raise ValueError("invalid meme moment")
        if self.emotion not in EMOTIONS: raise ValueError("invalid meme emotion")

@dataclass
class MemeDecision:
    moment_start:float
    moment_end:float
    asset_id:str=""
    score:float=0.
    context_score:float=0.
    emotion_score:float=0.
    timing_score:float=0.
    relatability_score:float=0.
    visual_fit_score:float=0.
    audio_fit_score:float=0.
    cringe_penalty:float=0.
    action:str="skip"
    placement:str="safe_bottom"
    scale:float=.35
    caption:str=""
    reason:str=""
    def validate(self):
        if not finite(self.moment_start,self.moment_end,self.score,self.context_score,self.emotion_score,self.timing_score,self.relatability_score,self.visual_fit_score,self.audio_fit_score,self.cringe_penalty,self.scale): raise ValueError("invalid meme decision")
        if self.moment_start<0 or self.moment_end<=self.moment_start or not 0<=self.scale<=1: raise ValueError("invalid meme decision range")
        if any(not 0<=v<=1 for v in (self.score,self.context_score,self.emotion_score,self.timing_score,self.relatability_score,self.visual_fit_score,self.audio_fit_score,self.cringe_penalty)): raise ValueError("invalid meme score range")
        if self.action not in {"use","skip"}: raise ValueError("invalid meme action")
        if self.placement not in {"safe_bottom","safe_top","left","right","center","tracked_subject"}: raise ValueError("invalid meme placement")

@dataclass
class MemePlan:
    duration:float
    target_format:str
    style:str
    decisions:List[MemeDecision]=field(default_factory=list)
    selected_count:int=0
    skipped_count:int=0
    warnings:List[str]=field(default_factory=list)
    metadata:Dict[str,Any]=field(default_factory=dict)
    digest:str=""
    def validate(self):
        if not finite(self.duration) or self.duration<=0 or self.target_format not in FORMATS or self.style not in MEME_STYLES: raise ValueError("invalid meme plan")
        last=-1.
        for d in self.decisions:
            d.validate()
            if d.moment_start < last: raise ValueError("meme decisions must be ordered")
            if d.moment_end>self.duration+1e-9: raise ValueError("meme decision outside duration")
            last=d.moment_start
        if self.selected_count != sum(d.action=="use" for d in self.decisions): raise ValueError("selected count mismatch")
        if self.skipped_count != sum(d.action=="skip" for d in self.decisions): raise ValueError("skipped count mismatch")

class MemeAssetCatalog:
    def __init__(self, assets:Optional[List[MemeAsset]]=None): self.assets=[]; [self.add(a) for a in (assets or [])]
    def add(self,a):
        if isinstance(a,dict): a=MemeAsset(**{k:v for k,v in a.items() if k in MemeAsset.__dataclass_fields__})
        a.validate()
        if any(existing.id == a.id for existing in self.assets): raise ValueError("duplicate meme asset id")
        self.assets.append(a)
    def eligible(self): return [a for a in self.assets if a.license_class in {"licensed","public_domain","user_owned","app_approved"}]

class MemeAnalyzer:
    @staticmethod
    def moments(command,duration,visual=None,speech=None,beats=None):
        if not isinstance(command,str) or not command.strip(): raise ValueError("command required")
        duration=max(.001,float(duration)); text=norm(command); visual=visual or []; speech=speech or []; beats=beats or []
        requested=any(k in text for k in ("meme","funny","viral","reaction","comedy","humor","humour"))
        moments=[]
        for item in visual:
            if not isinstance(item,dict): continue
            try:
                st=max(0,min(duration,float(item.get("start",0)))); en=max(st,min(duration,float(item.get("end",st+1))))
                if en<=st: continue
                emo=norm(item.get("emotion","funny")); emo=emo if emo in EMOTIONS else "funny"
                moments.append(MemeMoment(st,en,emo,clamp(item.get("confidence",.7)),clamp(item.get("intensity",.6)),[norm(x) for x in item.get("keywords",[]) if norm(x)],bool(item.get("dialogue",False)),bool(item.get("beat",False)),clamp(item.get("motion",0)),clamp(item.get("novelty",.7))))
            except (TypeError,ValueError): continue
        for x in speech:
            if not isinstance(x,dict): continue
            try:
                st=max(0,min(duration,float(x.get("start",0)))); en=max(st,min(duration,float(x.get("end",st+1))))
                if en<=st: continue
                tx=norm(x.get("text",x.get("word",""))); emo="funny" if any(k in tx for k in ("lol","haha","really","what","seriously","bro","wait")) else "awkward"
                moments.append(MemeMoment(st,en,emo,clamp(x.get("confidence",.7)),.65,[k for k in tx.split() if len(k)>3][:8],True,False,0.,.65))
            except (TypeError,ValueError): continue
        for b in beats:
            try:
                t=float(b.get("time",b.get("start"))) if isinstance(b,dict) else float(b)
                if 0<=t<duration: moments.append(MemeMoment(t,min(duration,t+.8),"funny",.5,.5,[],False,True,.3,.6))
            except (TypeError,ValueError): pass
        if not moments and requested:
            # Safe deterministic fallback: one conservative moment, not an invented meme asset.
            moments=[MemeMoment(0,min(duration,max(.8,min(2.,duration))),"funny",.25,.45,[],False,False,0.,.5)]
        moments.sort(key=lambda m:(m.start,m.end,m.emotion))
        merged=[]
        for m in moments:
            m.validate()
            if merged and m.start < merged[-1].end:
                # Keep the stronger moment while preserving timeline boundaries.
                if m.confidence*m.intensity > merged[-1].confidence*merged[-1].intensity: merged[-1]=m
            else: merged.append(m)
        return merged

class MemeRanker:
    @staticmethod
    def rank(moment,asset,target_format,style,used_ids=None):
        used_ids=used_ids or set(); tags=set(norm(x) for x in asset.tags); kws=set(moment.keywords); emo=set(asset.emotions)
        context=0.55 + (0.25 if kws & tags else 0.) + (0.10 if asset.style==style else 0.)
        emotion=.55 + (.40 if moment.emotion in emo else 0.)
        timing=.55 + (.25 if moment.beat and asset.audio else 0.) + (.10 if moment.dialogue and asset.audio else 0.)
        relatable=.65 + (.15 if "reaction" in tags or "relatable" in tags else 0.)
        visual=.75 if target_format in FORMATS else .5
        audio=.8 if (moment.beat and asset.audio) else .6
        novelty=.35 if asset.id in used_ids else .9
        cringe=0.0
        if asset.style=="chaotic" and style in {"minimal","cinematic"}: cringe+=.30
        if asset.duration and asset.duration>max(1.,moment.end-moment.start)*1.8: cringe+=.15
        score=.20*context+.18*emotion+.18*timing+.16*relatable+.12*visual+.10*audio+.06*novelty-.18*cringe
        return clamp(score), (context,emotion,timing,relatable,visual,audio,cringe)

class Stage11Pipeline:
    def __init__(self,catalog=None): self.catalog=MemeAssetCatalog(catalog or [])
    def plan(self,command,duration,target_format="landscape",style="classic",visual=None,speech=None,beats=None,assets=None,max_memes=8,allow_reuse=False):
        duration=max(.001,float(duration)); target_format=target_format if target_format in FORMATS else "landscape"; style=style if style in MEME_STYLES else "classic"; catalog=MemeAssetCatalog(assets) if assets is not None else self.catalog
        moments=MemeAnalyzer.moments(command,duration,visual,speech,beats); decisions=[]; used=set(); warnings=[]
        eligible=catalog.eligible()
        requested=any(k in norm(command) for k in ("meme","funny","viral","reaction","comedy","humor","humour"))
        if not requested:
            warnings.append("Meme intent not detected; engine remains non-destructive and skips insertion.")
            plan=MemePlan(duration,target_format,style,[],0,0,warnings,{"stage11_version":"11.0","asset_policy":"approved_or_licensed_only","anti_spam_seconds":.6,"no_forced_memes":True})
            plan.validate(); plan.digest=self.digest(plan); return plan
        if requested and not eligible: warnings.append("No approved/licensed/public-domain/user-owned meme assets supplied; meme insertion safely skipped.")
        for m in moments:
            if len([d for d in decisions if d.action=="use"])>=max(0,int(max_memes)): break
            candidates=[]
            for a in eligible:
                score,parts=MemeRanker.rank(m,a,target_format,style,used)
                candidates.append((score,a,parts))
            candidates.sort(key=lambda x:(-x[0],x[1].id))
            if not candidates or candidates[0][0]<.62:
                d=MemeDecision(m.start,m.end,score=(candidates[0][0] if candidates else 0.),action="skip",reason="quality_floor_or_no_eligible_asset")
            else:
                score,a,p=candidates[0]; used.add(a.id)
                duration_window=max(.05,m.end-m.start); scale=.28 if target_format in {"reel","story","portrait"} else .34
                placement="safe_bottom" if target_format in {"reel","story","portrait"} else "safe_top"
                d=MemeDecision(m.start,min(duration,m.end),a.id,score,*p[:6],p[6],"use",placement,scale,"",f"best_ranked_context_emotion_timing")
            decisions.append(d)
        # enforce minimum spacing between used memes to avoid meme spam
        last_end=-1.; final=[]
        for d in decisions:
            if d.action=="use" and d.moment_start < last_end+0.6:
                d=MemeDecision(d.moment_start,d.moment_end,action="skip",score=d.score,reason="anti_spam_spacing")
            if d.action=="use": last_end=d.moment_end
            final.append(d)
        decisions=final
        plan=MemePlan(duration,target_format,style,decisions,sum(d.action=="use" for d in decisions),sum(d.action=="skip" for d in decisions),warnings,{'stage11_version':'11.0','asset_policy':'approved_or_licensed_only','anti_spam_seconds':.6,'no_forced_memes':True})
        plan.validate(); plan.digest=self.digest(plan); return plan
    @staticmethod
    def digest(plan):
        d=asdict(plan); d['digest']=''; return hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    def inspect(self,plan): plan.validate(); return {'ok':True,'duration':plan.duration,'decisions':len(plan.decisions),'selected':plan.selected_count,'skipped':plan.skipped_count,'warnings':list(plan.warnings),'digest':plan.digest,'asset_count':len(self.catalog.assets)}
