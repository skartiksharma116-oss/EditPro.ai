const {spawn}=require('child_process'), fs=require('fs'), path=require('path');
(async()=>{
  const root=path.join(__dirname,'..'), port=4174;
  const server=spawn('node',[path.join(root,'server.js')],{env:{...process.env,PORT:String(port)},stdio:'ignore'});
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  try{
    await sleep(250);
    const get=async p=>{const r=await fetch(`http://127.0.0.1:${port}${p}`); return {status:r.status,text:await r.text()};};
    const health=await get('/api/health'); if(health.status!==200||!JSON.parse(health.text).ok) throw Error('health failed');
    const index=await get('/'); if(index.status!==200) throw Error('index failed');
    const app=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
    for(const id of ['videoInput','audioInput','addText','split','undo','redo','save','load','export','applyText']) if(!index.text.includes(`id="${id}"`)) throw Error(`missing control ${id}`);
    if(!app.includes("$('addText').onclick")) throw Error('addText handler missing');
    for(let i=0;i<1000;i++){
      const body=JSON.stringify({version:3,id:`smoke-${i}`,clips:[],selected:0,speed:1});
      const r=await fetch(`http://127.0.0.1:${port}/api/projects/smoke-${i}`,{method:'POST',headers:{'content-type':'application/json'},body});
      if(r.status!==200) throw Error('project write failed');
      const g=await get(`/api/projects/smoke-${i}`); if(g.status!==200||JSON.parse(g.text).version!==3) throw Error('project read failed');
    }
    const traversal=await get('/%2e%2e/%2e%2e/server.js'); if(traversal.status===200) throw Error('path traversal');
    const big=await fetch(`http://127.0.0.1:${port}/api/projects/big`,{method:'POST',headers:{'content-type':'application/json'},body:'x'.repeat(2*1024*1024+1)}); if(big.status!==413) throw Error('body limit failed');
    console.log('STAGE0_1_UI_SMOKE PASS (health, controls, 1,000 project round trips, traversal, body-limit)');
  }finally{server.kill();}
})().catch(e=>{console.error(e);process.exit(1)});
