# EditPro.ai Stage 0 + 1 PRO

A stronger, testable foundation. Stage 0 supplies a local backend, health endpoint, project persistence endpoint, autosave, and a renderer-ready job boundary. Stage 1 supplies a browser editor with upload, multi-clip state, split, trim, speed, text, audio asset state, undo/redo, save/load, responsive UI, and browser WebM export.

## Run
Node 20+ recommended.

```bash
npm install
npm start
```
Open http://127.0.0.1:4173

## Automated stress test

```bash
npm test
```

The included stress test performs 10,000 logical project-state operations and 1,000 real browser UI interaction cycles. It is NOT a claim of 10,000 full end-to-end renders or 10,000 device tests.

## Known Stage 0+1 boundary
Browser export currently creates a video WebM from the canvas preview. Server-side FFmpeg rendering, cloud object storage, authenticated multi-user projects, real background job queues, and GPU workers are intentionally the next backend production step. The API boundary is included so those can be added without replacing the editor.


Hardening: loaded/autosaved project data is normalized and invalid clip ranges/selected indexes are rejected or repaired.
