const http=require('http'),fs=require('fs'),path=require('path'),url=require('url');
const ROOT=__dirname, PUBLIC=path.join(ROOT,'public'), DATA=path.join(ROOT,'data');fs.mkdirSync(DATA,{recursive:true});
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.webm':'video/webm'};
const MAX_BODY=2*1024*1024;
function send(res,code,body,type='application/json'){res.writeHead(code,{'Content-Type':type,'Cache-Control':'no-store'});res.end(body)}
function safe(s){return String(s).replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,128)}
function publicFile(requestPath){
  let decoded; try{decoded=decodeURIComponent(requestPath)}catch{return null}
  const candidate=path.resolve(PUBLIC,'.'+(decoded||'/index.html'));
  const rel=path.relative(PUBLIC,candidate);
  return rel && !rel.startsWith('..'+path.sep) && rel!=='..' ? candidate : null;
}
const server=http.createServer((req,res)=>{const u=url.parse(req.url,true);if(req.method==='GET'&&u.pathname==='/api/health')return send(res,200,JSON.stringify({ok:true,stage:'0+1',version:'0.3.0',queue:'ready',renderer:'browser-webm',gpu:'adapter-ready'}));
if(req.method==='GET'&&u.pathname==='/api/jobs')return send(res,200,JSON.stringify({queued:0,running:0,completed:0,failed:0}));
if(req.method==='POST'&&u.pathname.startsWith('/api/projects/')){let id=safe(u.pathname.split('/').pop()),chunks=[],size=0,tooLarge=false;req.on('data',c=>{size+=c.length;if(size<=MAX_BODY)chunks.push(c);else tooLarge=true});req.on('end',()=>{if(tooLarge)return send(res,413,JSON.stringify({error:'payload_too_large'}));try{const body=JSON.parse(Buffer.concat(chunks));fs.writeFileSync(path.join(DATA,id+'.json'),JSON.stringify(body,null,2));send(res,200,JSON.stringify({ok:true,id}))}catch(e){send(res,400,JSON.stringify({error:'invalid_json'}))}});return}
if(req.method==='GET'&&u.pathname.startsWith('/api/projects/')){let id=safe(u.pathname.split('/').pop()),f=path.join(DATA,id+'.json');if(!fs.existsSync(f))return send(res,404,JSON.stringify({error:'not_found'}));return send(res,200,fs.readFileSync(f,'utf8'));}
let file=publicFile(u.pathname==='/'?'/index.html':u.pathname);if(!file)return send(res,403,'Forbidden','text/plain');fs.readFile(file,(e,b)=>{if(e)return send(res,404,'Not found','text/plain');send(res,200,b,mime[path.extname(file)]||'application/octet-stream')});});
const PORT=process.env.PORT||4173;server.listen(PORT,'127.0.0.1',()=>console.log(`EditPro.ai http://127.0.0.1:${PORT}`));
