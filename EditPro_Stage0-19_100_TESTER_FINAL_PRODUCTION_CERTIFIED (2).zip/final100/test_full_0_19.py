import json, subprocess, tempfile
from pathlib import Path
from editpro_pipeline import EditProPipeline

def make_media(path):
    subprocess.run(['ffmpeg','-y','-f','lavfi','-i','testsrc=size=640x360:rate=24:duration=1.5','-f','lavfi','-i','sine=frequency=880:duration=1.5','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(path)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

def main():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/'real.mp4'; make_media(p)
        app=EditProPipeline()
        out=app.run(p,intent='make a premium cinematic reel',target_format='reel')
        assert out['ok']
        assert '19' in out['stages']
        assert out['stages']['19']['inspection']['ok']
        h=out['stages']['19']['handoff']
        assert h['stage']==19 and h['capability_count']>=500
        # signal path with hostile metadata must remain safe and coordinated
        sig=app.run_from_signals({'duration':'nan','width':999999,'height':-1,'fps':9999},intent='make a cinematic reel',target_format='reel',speech={'transcript':[{'text':'hello','start':0,'end':0.2},{'text':'x','start':-5,'end':99}]})
        assert sig['ok'] and sig['stages']['19']['inspection']['ok']
    print(json.dumps({'full_pipeline_0_19':'PASS','real_media':'PASS','hostile_signal_boundary':'PASS'}))
if __name__=='__main__': main()
