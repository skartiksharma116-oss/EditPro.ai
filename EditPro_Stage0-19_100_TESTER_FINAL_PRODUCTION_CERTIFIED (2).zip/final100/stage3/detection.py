"""Detection contract and safe fallback. Real ML detectors can plug in without changing Stage 3."""
import math
class DetectionProvider:
    name='base'
    def detect(self, frame): raise NotImplementedError
class SafeDetectionProvider(DetectionProvider):
    name='safe'
    def detect(self, frame):
        if not isinstance(frame,dict): return []
        # No fabricated objects: only consume explicit detector output if supplied.
        raw=frame.get('detections',[])
        return [d for d in raw if isinstance(d,dict) and self._valid(d)]
    @staticmethod
    def _valid(d):
        try: vals=[float(d[k]) for k in ('x','y','w','h','confidence')]
        except (KeyError,TypeError,ValueError): return False
        return all(math.isfinite(v) for v in vals) and vals[2]>0 and vals[3]>0 and 0<=vals[4]<=1
