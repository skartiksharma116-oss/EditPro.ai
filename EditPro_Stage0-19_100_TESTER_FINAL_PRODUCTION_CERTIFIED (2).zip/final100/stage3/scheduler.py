"""Responsive bounded scheduler for Stage 3 background intelligence."""
from concurrent.futures import ThreadPoolExecutor, Future
from dataclasses import dataclass
import heapq, itertools, threading, time, os

@dataclass
class Job:
    priority:int; seq:int; fn:object; args:tuple; kwargs:dict; future:Future

class ResponsiveScheduler:
    def __init__(self, workers=None, max_queue=256):
        cpu=os.cpu_count() or 1
        self.workers=max(1,min(int(workers or max(1,cpu-1)),cpu)); self.max_queue=max(1,int(max_queue))
        self._heap=[]; self._seq=itertools.count(); self._cv=threading.Condition(); self._closed=False
        self._executor=ThreadPoolExecutor(max_workers=self.workers,thread_name_prefix='editpro-stage3')
        self._dispatcher=threading.Thread(target=self._dispatch,daemon=True); self._dispatcher.start()
    def submit(self,fn,*args,priority=10,**kwargs):
        with self._cv:
            if self._closed: raise RuntimeError('scheduler_closed')
            if len(self._heap)>=self.max_queue: raise RuntimeError('scheduler_queue_full')
            fut=Future(); heapq.heappush(self._heap,(-int(priority),next(self._seq),Job(int(priority),0,fn,args,kwargs,fut))); self._cv.notify()
            return fut
    def _dispatch(self):
        while True:
            with self._cv:
                while not self._heap and not self._closed:self._cv.wait()
                if self._closed and not self._heap:return
                _,_,job=heapq.heappop(self._heap)
            if job.future.set_running_or_notify_cancel():
                inner=self._executor.submit(job.fn,*job.args,**job.kwargs)
                def done(src,j=job):
                    if src.cancelled(): j.future.cancel()
                    else:
                        try:j.future.set_result(src.result())
                        except BaseException as e:j.future.set_exception(e)
                inner.add_done_callback(done)
    def shutdown(self,wait=True,cancel_pending=True):
        with self._cv:
            self._closed=True
            if cancel_pending:
                while self._heap:self._heap.pop()[2].future.cancel()
            self._cv.notify_all()
        self._executor.shutdown(wait=wait,cancel_futures=cancel_pending)
        if wait:self._dispatcher.join(timeout=5)
