from dataclasses import dataclass, asdict
import math

@dataclass
class TrackState:
    track_id:int; label:str; x:float; y:float; w:float; h:float; confidence:float; missed:int=0

class PersistentTracker:
    """Lightweight IoU tracker; model adapters can replace detections later."""
    def __init__(self, iou_threshold=.25, max_missed=8):
        self.iou_threshold=float(iou_threshold); self.max_missed=int(max(0,max_missed)); self.next_id=1; self.tracks={}
    @staticmethod
    def iou(a,b):
        ax,ay,aw,ah=a; bx,by,bw,bh=b
        if min(aw,ah,bw,bh)<=0:return 0.0
        x1=max(ax,bx); y1=max(ay,by); x2=min(ax+aw,bx+bw); y2=min(ay+ah,by+bh)
        inter=max(0,x2-x1)*max(0,y2-y1); union=aw*ah+bw*bh-inter
        return inter/union if union>0 else 0.0
    def update(self,detections):
        if not isinstance(detections,list): detections=[]
        clean=[]
        for d in detections:
            if not isinstance(d,dict):continue
            try: box=tuple(float(d.get(k,0)) for k in ('x','y','w','h')); c=float(d.get('confidence',0)); label=str(d.get('label','object'))[:64]
            except (TypeError,ValueError):continue
            if not all(math.isfinite(v) for v in box+(c,)) or box[2]<=0 or box[3]<=0:continue
            clean.append((box,c,label))
        used=set(); result=[]
        for tid,t in list(self.tracks.items()):
            best=(-1,None)
            for i,(box,c,label) in enumerate(clean):
                if i in used or label!=t.label:continue
                score=self.iou((t.x,t.y,t.w,t.h),box)
                if score>best[0]:best=(score,i)
            if best[0]>=self.iou_threshold:
                i=best[1]; box,c,label=clean[i]; used.add(i); t.x,t.y,t.w,t.h=box; t.confidence=c; t.missed=0
            else:t.missed+=1
            if t.missed>self.max_missed: del self.tracks[tid]
        for i,(box,c,label) in enumerate(clean):
            if i in used:continue
            self.tracks[self.next_id]=TrackState(self.next_id,label,*box,c); self.next_id+=1
        for t in self.tracks.values():
            result.append(asdict(t))
        return sorted(result,key=lambda x:x['track_id'])
