from .intelligence import VisualIntelligence
from .tracking import PersistentTracker
from .runtime import LRUCache,DependencyGraph,ResourceGovernor,ModelRouter
from .quality import EditQualityGate
from .camera import VirtualCamera
from .critic import EditSelfCritic

class Stage3Pipeline:
    """Foundation pipeline. Specialized advanced creative systems intentionally excluded."""
    def __init__(self):
        self.vision=VisualIntelligence(); self.tracker=PersistentTracker(); self.cache=LRUCache(256); self.graph=DependencyGraph(); self.governor=ResourceGovernor(); self.router=ModelRouter()
        self.gate=EditQualityGate(); self.camera=VirtualCamera(); self.critic=EditSelfCritic(); self.graph.set('tracking',['frames','detections']); self.graph.set('attention',['tracking']); self.graph.set('reframe',['attention']); self.graph.set('virtual_camera',['reframe']); self.graph.set('validation',['reframe','virtual_camera'])
    def run(self, duration, width, height, frames=None, objects=None, target=(9,16), available_runtimes=('cpu',), reset_tracking=True):
        if not all(isinstance(x,(int,float)) and x>0 for x in (duration,width,height)): raise ValueError('Invalid media dimensions')
        if reset_tracking: self.tracker=PersistentTracker()
        signals=self.vision.frame_signals(frames or [],duration)
        cuts=self.vision.shot_boundaries(signals)
        tracks=self.tracker.update(objects or [])
        zones=self.vision.attention_zones(tracks,width,height)
        crop=self.vision.safe_reframe(zones,*target)
        quality=self.gate.check(crop,tracks)
        if not quality['ok']:
            crop={'x':0.0,'y':0.0,'w':1.0,'h':1.0,'confidence':0.0}
            quality={'ok':True,'issues':quality['issues'],'action':'fallback_original'}
        route=self.router.route(available_runtimes)
        camera=self.camera.plan(crop)
        result={'signals':signals,'cuts':cuts,'tracks':tracks,'attention_zones':zones,'reframe':crop,'runtime':route,'resources':self.governor.profile(),'affected_on_tracking_change':self.graph.affected(['tracking']),'quality':quality,'virtual_camera':camera}
        result['critic']=self.critic.review(result)
        return result
