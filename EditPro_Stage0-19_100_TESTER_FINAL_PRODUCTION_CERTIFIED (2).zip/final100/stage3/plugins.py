class PluginRegistry:
    def __init__(self): self._plugins={}
    def register(self,name,version,capabilities):
        name=str(name).strip(); version=str(version).strip(); caps=tuple(sorted(set(str(x) for x in (capabilities or ()))))
        if not name or not version or name in self._plugins: raise ValueError('invalid_or_duplicate_plugin')
        self._plugins[name]={'name':name,'version':version,'capabilities':caps}; return dict(self._plugins[name])
    def get(self,name): return self._plugins.get(name)
    def list(self): return [self._plugins[k] for k in sorted(self._plugins)]
