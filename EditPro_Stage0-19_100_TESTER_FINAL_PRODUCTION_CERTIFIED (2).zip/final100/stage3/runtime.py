import os, time, hashlib, json
from collections import OrderedDict

class LRUCache:
    def __init__(self,max_items=128): self.max_items=max(1,int(max_items)); self.data=OrderedDict()
    def get(self,key):
        if key not in self.data:return None
        v=self.data.pop(key); self.data[key]=v; return v
    def put(self,key,value):
        if key in self.data:self.data.pop(key)
        self.data[key]=value
        while len(self.data)>self.max_items:self.data.popitem(last=False)

class DependencyGraph:
    def __init__(self): self.deps={}
    def set(self,node,parents=()): self.deps[str(node)]=tuple(str(x) for x in parents)
    def affected(self,changed):
        changed=set(map(str,changed)); out=set(changed); again=True
        while again:
            again=False
            for n,p in self.deps.items():
                if n not in out and any(x in out for x in p):out.add(n);again=True
        return sorted(out)

class ResourceGovernor:
    def __init__(self,max_workers=None):
        cpu=os.cpu_count() or 1; self.max_workers=max(1,min(int(max_workers or max(1,cpu-1)),cpu))
    def profile(self): return {'cpu_count':os.cpu_count() or 1,'max_workers':self.max_workers}

class ModelRouter:
    def route(self,available):
        a=set(available or [])
        for x in ('tensorrt','cuda','migraphx','openvino','coreml','directml','webgpu','cpu'):
            if x in a:return x
        return 'cpu'
