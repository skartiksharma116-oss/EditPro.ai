import math
class VirtualCamera:
    def plan(self, crop, target_fps=30, max_speed=.25):
        if not isinstance(crop,dict): return {'mode':'original','keyframes':[]}
        c=max(0,min(1,float(crop.get('confidence',0))))
        if c<.35: return {'mode':'original','keyframes':[]}
        x,y,w,h=[float(crop[k]) for k in ('x','y','w','h')]
        if not all(math.isfinite(v) for v in (x,y,w,h)): return {'mode':'original','keyframes':[]}
        return {'mode':'follow','keyframes':[{'t':0.0,'x':x,'y':y,'w':w,'h':h},{'t':1.0/max(1,target_fps),'x':x,'y':y,'w':w,'h':h}],'max_speed':max(0.01,min(.5,float(max_speed)))}
