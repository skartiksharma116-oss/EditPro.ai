class EditSelfCritic:
    def review(self,result):
        issues=[]
        q=result.get('quality',{}) if isinstance(result,dict) else {}
        if not q.get('ok',False): issues.append('quality_gate')
        crop=result.get('reframe',{}) if isinstance(result,dict) else {}
        if crop.get('confidence',0)<.35 and crop.get('w',1)<.99: issues.append('low_confidence_crop')
        return {'accept':not issues,'issues':issues,'action':'accept' if not issues else 'fallback_original'}
