from __future__ import annotations
import hashlib, json, os, platform, time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import re, math

@dataclass(frozen=True)
class ModelArtifact:
    name: str
    version: str
    path: str
    sha256: str
    size: int

class ModelRegistry:
    def __init__(self, root):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def register(self,name,version,path):
        if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}',name): raise ValueError('invalid_model_name')
        if not isinstance(version,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}',version): raise ValueError('invalid_model_version')
        p=Path(path)
        if not p.is_file(): raise FileNotFoundError('model_not_found')
        h=hashlib.sha256(); size=0
        with p.open('rb') as f:
            for b in iter(lambda:f.read(1024*1024),b''):
                size+=len(b); h.update(b)
        art=ModelArtifact(str(name),str(version),str(p),h.hexdigest(),size)
        (self.root/(name+'-'+version+'.json')).write_text(json.dumps(asdict(art),sort_keys=True))
        return art
    def verify(self,artifact):
        p=Path(artifact.path)
        if not p.is_file(): return False
        h=hashlib.sha256(); size=0
        with p.open('rb') as f:
            for b in iter(lambda:f.read(1024*1024),b''):
                size+=len(b); h.update(b)
        return size==artifact.size and h.hexdigest()==artifact.sha256

class ExternalAvailability:
    @staticmethod
    def cloud_ai(): return bool(os.getenv('EDITPRO_CLOUD_AI_URL'))
    @staticmethod
    def aws_device_farm(): return bool(os.getenv('AWS_ACCESS_KEY_ID') and os.getenv('AWS_SECRET_ACCESS_KEY'))
    @staticmethod
    def nvidia():
        return bool(os.getenv('EDITPRO_NVIDIA_ENDPOINT'))
    @staticmethod
    def amd():
        return bool(os.getenv('EDITPRO_AMD_ENDPOINT'))

class PerformanceBudget:
    def __init__(self,preview_ms=100,interaction_ms=1000,export_start_ms=5000):
        self.preview_ms=preview_ms; self.interaction_ms=interaction_ms; self.export_start_ms=export_start_ms
    def check(self,metrics):
        vals={k:metrics.get(k) for k in ('preview_p95_ms','interaction_p95_ms','export_start_p95_ms')}
        for k,v in vals.items():
            if not isinstance(v,(int,float)) or not math.isfinite(v) or v < 0: raise ValueError('invalid_performance_metric')
        return {
            'preview_ok': vals['preview_p95_ms']<=self.preview_ms,
            'interaction_ok': vals['interaction_p95_ms']<=self.interaction_ms,
            'export_start_ok': vals['export_start_p95_ms']<=self.export_start_ms,
        }

def environment_report():
    return {
        'python':platform.python_version(),'os':platform.platform(),
        'cloud_ai':ExternalAvailability.cloud_ai(),
        'aws_device_farm':ExternalAvailability.aws_device_farm(),
        'nvidia_external':ExternalAvailability.nvidia(),
        'amd_external':ExternalAvailability.amd(),
    }
