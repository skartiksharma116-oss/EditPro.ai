class EditQualityGate:
    def check(self,reframe,tracks=None):
        issues=[]
        if not isinstance(reframe,dict): issues.append('missing_reframe')
        else:
            for k in ('x','y','w','h','confidence'):
                v=reframe.get(k)
                if not isinstance(v,(int,float)) or not 0<=v<=1: issues.append('invalid_'+k)
            if reframe.get('w',0)<=0 or reframe.get('h',0)<=0: issues.append('empty_crop')
        for t in tracks or []:
            if t.get('confidence',0)<.15: issues.append('low_tracking_confidence')
        return {'ok':not issues,'issues':sorted(set(issues)),'action':'accept' if not issues else 'fallback_original'}
