"""Stage 3 visual intelligence foundation: deterministic, lightweight, model-ready."""
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple
import math

@dataclass(frozen=True)
class FrameSignal:
    time: float; motion: float; brightness: float; contrast: float; attention: float

@dataclass(frozen=True)
class Track:
    track_id: int; label: str; start: float; end: float; confidence: float
    boxes: Tuple[Tuple[float,float,float,float], ...]

class VisualIntelligence:
    def __init__(self, sample_cap=240):
        self.sample_cap=max(1,min(int(sample_cap),1000))
    def frame_signals(self, frames, duration):
        if not isinstance(frames,list) or duration<=0: return []
        out=[]
        for f in frames[:self.sample_cap]:
            if not isinstance(f,dict) or any(k not in f for k in ('time','motion','brightness','contrast')): continue
            try:
                t=float(f['time']); vals=[float(f[k]) for k in ('motion','brightness','contrast')]
            except (TypeError,ValueError,OverflowError): continue
            if not all(math.isfinite(v) for v in [t,*vals]): continue
            t=max(0,min(duration,t))
            motion=max(0,min(1,vals[0])); bright=max(0,min(1,vals[1])); contrast=max(0,min(1,vals[2]))
            attention=max(0,min(1,.55*motion+.25*contrast+.20*(1-abs(bright-.5)*2)))
            out.append(asdict(FrameSignal(t,motion,bright,contrast,attention)))
        return sorted(out, key=lambda x:x['time'])
    def shot_boundaries(self, frames, threshold=.65):
        if not isinstance(frames,list): return []
        cuts=[]
        for a,b in zip(frames,frames[1:]):
            if not isinstance(a,dict) or not isinstance(b,dict): continue
            try: delta=abs(float(b.get('brightness',0))-float(a.get('brightness',0)))+abs(float(b.get('contrast',0))-float(a.get('contrast',0)))
            except (TypeError,ValueError): continue
            if delta >= threshold: cuts.append(float(b.get('time',0)))
        return sorted(set(x for x in cuts if math.isfinite(x) and x>=0))
    def attention_zones(self, objects, width, height):
        if width<=0 or height<=0 or not isinstance(objects,list): return []
        out=[]
        for o in objects:
            if not isinstance(o,dict): continue
            try: x,y,w,h=map(float,(o.get('x',0),o.get('y',0),o.get('w',0),o.get('h',0))); c=float(o.get('confidence',0))
            except (TypeError,ValueError): continue
            if not all(math.isfinite(v) for v in (x,y,w,h,c)) or w<=0 or h<=0: continue
            x=max(0,min(width,x)); y=max(0,min(height,y)); w=max(0,min(width-x,w)); h=max(0,min(height-y,h))
            if w<=0 or h<=0: continue
            area=min(1,(w*h)/(width*height)); score=max(0,min(1,.7*c+.3*area))
            out.append({'track_id':o.get('track_id'),'label':str(o.get('label','object'))[:64],'x':x,'y':y,'w':w,'h':h,'score':score})
        return sorted(out,key=lambda z:(-z['score'],str(z['track_id'])))
    def safe_reframe(self, zones, target_w, target_h, margin=.08):
        if target_w<=0 or target_h<=0: raise ValueError('Invalid target dimensions')
        if not zones: return {'x':0.0,'y':0.0,'w':1.0,'h':1.0,'confidence':0.0}
        z=zones[0]; x,y,w,h=z['x'],z['y'],z['w'],z['h']; conf=z['score']
        # normalized center-following crop; conservative to avoid clipping.
        cx=(x+w/2); cy=(y+h/2)
        aspect=target_w/target_h
        crop_h=min(1.0,max(h*(1+margin*2), .15)); crop_w=min(1.0,crop_h*aspect)
        if crop_w>1: crop_w=1; crop_h=min(1,crop_w/aspect)
        if crop_h>1: crop_h=1; crop_w=min(1,crop_h*aspect)
        left=max(0,min(1-crop_w,cx-crop_w/2)); top=max(0,min(1-crop_h,cy-crop_h/2))
        return {'x':left,'y':top,'w':crop_w,'h':crop_h,'confidence':conf}
