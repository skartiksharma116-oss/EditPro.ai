from ai.vision import inspect_media,sample_visuals
from .pipeline import Stage3Pipeline
from .quality import EditQualityGate

class Stage3Production:
    def __init__(self): self.pipeline=Stage3Pipeline(); self.gate=EditQualityGate()
    def run(self,path,target=(9,16),available_runtimes=('cpu',)):
        media=inspect_media(path)
        if not media.get('width') or not media.get('height'): raise ValueError('unsupported_video_media')
        visuals=sample_visuals(path,samples=min(12,max(3,int(media['duration']*2))))
        frames=[]
        prev=None
        for v in visuals:
            motion=0.0 if prev is None else min(1.0,abs(v['mean_luma']-prev)/128.0)
            frames.append({'time':v['time'],'motion':motion,'brightness':v['mean_luma']/255.0,'contrast':min(1.0,v['contrast_proxy']/64.0)})
            prev=v['mean_luma']
        result=self.pipeline.run(media['duration'],media['width'],media['height'],frames=frames,target=target,available_runtimes=available_runtimes)
        result['quality']=self.gate.check(result['reframe'],result['tracks']); result['media']=media
        return result
