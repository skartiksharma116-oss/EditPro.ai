import random, math, time, json, hashlib
from editpro_pipeline import EditProPipeline
from stage16_creative_brain import Stage16CreativeBrain

random.seed(160016)

def media_case(i):
    durations=[0,0.1,1,3.3,10,60,300,3600]
    fps=[1,15,24,25,30,50,60,120]
    sizes=[(1,1),(320,240),(1280,720),(1920,1080),(3840,2160)]
    d=random.choice(durations)
    w,h=random.choice(sizes)
    return {"duration":d,"width":w,"height":h,"fps":random.choice(fps),"target_format":random.choice(["reel","story","landscape","square","youtube","thumbnail","9:16","16:9"]),"format":random.choice(["mp4","mov","mxf","wav",""])}

def speech_case(d):
    out=[]
    n=random.randint(0,12)
    for j in range(n):
        a=random.uniform(-2,max(0.01,float(d)+2))
        b=a+random.choice([0.01,0.1,0.5,2.0])
        out.append({"start":a,"end":b,"text":random.choice(["hello","","meme","cinematic",123,None]),"speaker":random.choice(["A","B",None,""])})
    random.shuffle(out)
    return {"transcript":out,"language":random.choice(["en","hi",None]),"beats":[random.uniform(-1,max(1,float(d)+1)) for _ in range(random.randint(0,15))]}

def visual_case():
    return [{"label":random.choice(["person","car","sky","face","object",None]),"confidence":random.random()} for _ in range(random.randint(0,15))]

p=EditProPipeline()
start=time.time(); failures=[]
for i in range(1000):
    m=media_case(i); s=speech_case(m["duration"]); v=visual_case()
    try:
        r=p.run_from_signals(m, visual=v, speech=s, intent=random.choice([
            "make a premium cinematic reel with music",
            "make a funny meme short",
            "make a documentary with clean audio",
            "make an emotional youtube video",
            "make a safe editable reference-style story",
            "make a fast montage with beat sync"
        ]), target_format=m["target_format"], style=random.choice(["balanced","cinematic","energetic","emotional","documentary","unknown"]))
        if not r.get("ok"):
            failures.append((i,"pipeline_not_ok"))
    except Exception as e:
        failures.append((i,type(e).__name__,str(e)[:300]))
end=time.time()
print(json.dumps({"suite":"full_0_16_signal_fuzz","cases":1000,"failures":failures[:20],"failure_count":len(failures),"seconds":round(end-start,3),"cases_per_sec":round(1000/(end-start),2)},indent=2))

# Determinism stress on representative cases
start=time.time(); det_fail=0
for i in range(2000):
    m={"duration":60,"width":1920,"height":1080,"fps":30,"target_format":"reel"}
    v=[{"label":"person"},{"label":"car"}]
    s={"transcript":[{"start":0,"end":1,"text":"hello","speaker":"A"}],"beats":[1,2,3]}
    cmd="make premium cinematic reel with music meme reference style"
    a=p.run_from_signals(m,v,s,cmd,"reel")
    b=p.run_from_signals(m,v,s,cmd,"reel")
    if a["stages"]["16"]["handoff"]["creative_digest"] != b["stages"]["16"]["handoff"]["creative_digest"]:
        det_fail+=1
print(json.dumps({"suite":"deterministic_replay","cases":2000,"failures":det_fail,"seconds":round(time.time()-start,3)},indent=2))

# Stage16 hostile fuzz, expanded
b=Stage16CreativeBrain(); start=time.time(); hostile=0
for i in range(20000):
    m={"duration":random.choice([None,-1,0,1,"bad",float('nan'),float('inf')]),"width":random.choice([None,-1,0,1920,"x"]),"height":random.choice([None,-2,0,1080,"y"]),"fps":random.choice([None,0,-30,30,"bad"])}
    cmd=random.choice(["",None,123,"\x00"*1000,"premium "*100,"make reel meme music reference"])
    try:
        plan=b.plan(cmd,m,visual_case(),speech_case(m.get("duration") if isinstance(m.get("duration"),(int,float)) and math.isfinite(m.get("duration")) else 0))
        q=b.qa(plan)
        assert isinstance(plan.get("fingerprint"),str) and len(plan["fingerprint"])==64
        assert q["status"] in {"PASS","REPAIR","REJECT"}
    except Exception:
        hostile+=1
print(json.dumps({"suite":"stage16_hostile_fuzz","cases":20000,"failures":hostile,"seconds":round(time.time()-start,3)},indent=2))

print("HARD_TEST_DONE")
raise SystemExit(1 if failures or det_fail or hostile else 0)
