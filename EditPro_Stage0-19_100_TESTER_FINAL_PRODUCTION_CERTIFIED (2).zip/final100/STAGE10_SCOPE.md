# Stage 10 — AI Audio Studio

Stage 10 is the audio intelligence, synchronization and mastering layer above the Stage 9 cinematography director.

## Included
- audio metadata/probing with local FFmpeg fallback
- deterministic mood/style analysis
- speech-timing ingestion and validation
- BPM/beat-grid generation with measured-beat preservation
- dialogue ducking event planning
- voice/music/SFX/ambience/source-role model
- voice cleanup chain planning
- music chain planning
- master loudness/true-peak targets using FFmpeg loudnorm
- two-pass mastering contract
- beat-to-camera synchronization contract for Stage 9
- deterministic automation events
- audio timeline export contract
- CPU/local-first operation
- optional capability contracts for Whisper, Essentia, Demucs and librosa
- safe failure when optional providers are unavailable

## Research-backed provider strategy
FFmpeg is the mandatory local execution foundation. Its official filters include EBU R128 loudnorm and sidechain compression. Whisper provides multilingual speech recognition and VAD-related capabilities. Essentia provides BPM/beat positions and extensive music descriptors. Demucs is retained only as an optional compatibility provider because its upstream repository is archived; it is never required by the core.

## Explicitly deferred
- Meme Engine
- full image/asset studio
- global style engine
- cloud-only proprietary mastering
- mandatory paid APIs

## Quality rule
Advanced providers can improve analysis, but the EditPro core must remain functional with local CPU + FFmpeg fallback.
