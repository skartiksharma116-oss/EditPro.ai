from dataclasses import dataclass
from stage6_vfx import VFXPlanner,TemporalCritic,VFXRepairEngine,VFXProviderRegistry,VFXPacket
@dataclass
class Stage6Pipeline:
 profile: object=None
 def __post_init__(self):
  self.planner=VFXPlanner(); self.critic=TemporalCritic(); self.repair=VFXRepairEngine(); self.registry=VFXProviderRegistry()
 def process(self,intent,track_id=None,frames=(0,0),observations=(),capabilities=('cpu',)):
  packet=self.planner.plan(intent,track_id,frames); packet.validate()
  critic=self.critic.score(packet,observations); repair=None
  if critic['score']<.82: repair=self.repair.repair(packet,critic,max_attempts=3)
  packet.validate(); provider=self.registry.route(capabilities=capabilities)
  return {'ok':True,'provider':provider[0],'packet':packet,'critic':critic,'repair':repair}
