"""EditPro.ai Stage 13: Global Style Engine.

Local-first, deterministic style system that turns natural-language creative intent
into a reusable project style packet. It coordinates visual language across template,
compositor, cinematography, audio, meme, and asset layers without requiring a paid
model or pretending an unavailable generative provider executed.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import hashlib, json, math, re

STYLE_MODES = {"cinematic","clean","minimal","vibrant","luxury","retro","neon","documentary","playful","balanced","custom"}
COLOR_HARMONIES = {"analogous","complementary","triadic","monochrome","split_complementary","neutral"}
FONT_ROLES = {"display","heading","body","caption","accent"}
MOTION_LEVELS = {"none","subtle","balanced","dynamic","extreme"}
PROVIDERS = {"deterministic_cpu","optional_style_model"}

def finite(x):
    try: return math.isfinite(float(x))
    except (TypeError, ValueError): return False

def clamp(v, lo=0.0, hi=1.0): return max(lo, min(hi, float(v)))

def norm(x): return re.sub(r"[^a-z0-9_ -]+", "", str(x or "").lower()).strip()

def digest_obj(x): return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(",",":"), ensure_ascii=False).encode()).hexdigest()

def hex_color(x):
    s=str(x or "").strip().lstrip("#")
    return len(s) in (3,6,8) and all(c in "0123456789abcdefABCDEF" for c in s)

@dataclass
class Palette:
    colors: List[str] = field(default_factory=lambda: ["#FFFFFF", "#111111", "#888888"])
    harmony: str = "neutral"
    contrast: float = .7
    saturation: float = .5
    temperature: float = .5
    def validate(self):
        if self.harmony not in COLOR_HARMONIES or not self.colors or len(self.colors) > 24: raise ValueError("invalid palette")
        if any(not hex_color(c) for c in self.colors): raise ValueError("invalid color")
        if not all(finite(x) and 0 <= float(x) <= 1 for x in (self.contrast,self.saturation,self.temperature)): raise ValueError("invalid palette controls")

@dataclass
class TypographyRule:
    role: str
    family: str = "system"
    weight: int = 500
    size_scale: float = 1.0
    letter_spacing: float = 0.0
    case: str = "normal"
    def validate(self):
        if self.role not in FONT_ROLES or not str(self.family).strip(): raise ValueError("invalid typography")
        if isinstance(self.weight,bool) or not isinstance(self.weight,int) or not 100 <= self.weight <= 1000: raise ValueError("invalid font weight")
        if not finite(self.size_scale) or self.size_scale <= 0 or self.size_scale > 8: raise ValueError("invalid font scale")
        if not finite(self.letter_spacing) or abs(self.letter_spacing) > 20: raise ValueError("invalid letter spacing")
        if self.case not in {"normal","upper","lower","title"}: raise ValueError("invalid text case")

@dataclass
class MotionStyle:
    level: str = "balanced"
    easing: str = "ease_in_out"
    transition_seconds: float = .35
    camera_energy: float = .5
    text_energy: float = .5
    def validate(self):
        if self.level not in MOTION_LEVELS or not str(self.easing).strip(): raise ValueError("invalid motion style")
        if not finite(self.transition_seconds) or not 0 <= self.transition_seconds <= 10: raise ValueError("invalid transition duration")
        if not all(finite(x) and 0 <= float(x) <= 1 for x in (self.camera_energy,self.text_energy)): raise ValueError("invalid motion energy")

@dataclass
class StyleProfile:
    name: str
    mode: str = "balanced"
    palette: Palette = field(default_factory=Palette)
    typography: List[TypographyRule] = field(default_factory=lambda: [TypographyRule("heading"), TypographyRule("body"), TypographyRule("caption", size_scale=.8)])
    motion: MotionStyle = field(default_factory=MotionStyle)
    vfx_intensity: float = .5
    grain: float = 0.0
    glow: float = 0.0
    audio_energy: float = .5
    meme_energy: float = .3
    brand_tokens: Dict[str, str] = field(default_factory=dict)
    provenance: str = "deterministic"
    digest: str = ""
    def validate(self):
        if not str(self.name).strip() or self.mode not in STYLE_MODES: raise ValueError("invalid style profile")
        self.palette.validate(); self.motion.validate()
        if not self.typography or len(self.typography) > 16: raise ValueError("invalid typography rules")
        for t in self.typography: t.validate()
        for x in (self.vfx_intensity,self.grain,self.glow,self.audio_energy,self.meme_energy):
            if not finite(x) or not 0 <= float(x) <= 1: raise ValueError("invalid style intensity")
        if any(not isinstance(k,str) or not isinstance(v,str) for k,v in self.brand_tokens.items()): raise ValueError("invalid brand tokens")

@dataclass
class StylePlan:
    command: str
    profile: StyleProfile
    targets: List[str] = field(default_factory=lambda: ["stage7","stage8","stage9","stage10","stage11","stage12"])
    overrides: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    digest: str = ""
    def validate(self):
        if not str(self.command).strip(): raise ValueError("style command required")
        self.profile.validate()
        if not self.targets or any(not isinstance(x,str) or not x.strip() for x in self.targets): raise ValueError("invalid style targets")

class StyleIntentParser:
    @staticmethod
    def infer(command: str, mode: str = "balanced") -> StyleProfile:
        text=norm(command); requested=mode if mode in STYLE_MODES else "balanced"
        if requested == "balanced":
            for m in ("cinematic","luxury","neon","retro","minimal","vibrant","clean","documentary","playful"):
                if m in text: requested=m; break
        presets={
            "cinematic":(["#F2E8D5","#171717","#7B1E1E"],.82,.42,.42,.68,.65,.58,.55,.28),
            "luxury":(["#F4EFE2","#151515","#B89B5E"],.9,.32,.46,.35,.38,.5,.42,.18),
            "neon":(["#0B1020","#00F5D4","#FF2BD6"],.92,.9,.58,.92,.72,.72,.78,.65),
            "retro":(["#F4D8A8","#3D2B1F","#C65D3A"],.7,.72,.48,.52,.45,.58,.5,.55),
            "minimal":(["#FFFFFF","#111111","#B7B7B7"],.76,.18,.5,.22,.2,.28,.2,.12),
            "vibrant":(["#FFF7D6","#FF3B30","#146BFF","#17C964"],.86,.88,.55,.7,.75,.72,.7,.58),
            "clean":(["#FFFFFF","#18202A","#3B82F6"],.74,.38,.52,.35,.28,.35,.32,.2),
            "documentary":(["#E8E2D3","#242424","#68715E"],.72,.3,.44,.42,.3,.38,.35,.15),
            "playful":(["#FFF8E7","#FF6B6B","#4D96FF","#FFD93D"],.8,.86,.55,.76,.65,.7,.68,.7),
            "balanced":(["#FFFFFF","#111111","#4F6DFF"],.7,.5,.5,.5,.5,.5,.5,.3),
            # Custom is a valid public mode. Until explicit custom overrides are
            # supplied, start from the balanced safety baseline rather than
            # crashing on a missing preset.
            "custom":(["#FFFFFF","#111111","#4F6DFF"],.7,.5,.5,.5,.5,.5,.5,.3),
        }
        colors,contrast,sat,temp,vfx,grain,glow,audio,meme=presets[requested]
        return StyleProfile(name=f"{requested}_auto", mode=requested,
            palette=Palette(colors, "monochrome" if requested=="minimal" else "neutral", contrast,sat,temp),
            motion=MotionStyle("dynamic" if requested in {"neon","vibrant","playful"} else "balanced", "ease_in_out", .32 if requested!="cinematic" else .45, .72 if requested in {"neon","vibrant"} else .48, .68 if requested in {"neon","playful"} else .45),
            vfx_intensity=vfx, grain=grain, glow=glow, audio_energy=audio, meme_energy=meme)

class Stage13StyleEngine:
    def __init__(self, providers=None):
        self.available=set(providers or {"deterministic_cpu"})
        if not self.available: self.available.add("deterministic_cpu")
    def create_profile(self, command: str, mode: str="balanced", overrides: Optional[Dict[str,Any]]=None) -> StyleProfile:
        p=StyleIntentParser.infer(command, mode)
        for k,v in (overrides or {}).items():
            if k == "palette" and isinstance(v,dict):
                p.palette=Palette(**{**asdict(p.palette),**v})
            elif k == "motion" and isinstance(v,dict):
                p.motion=MotionStyle(**{**asdict(p.motion),**v})
            elif hasattr(p,k): setattr(p,k,v)
        p.validate(); p.digest=digest_obj(asdict(p)); return p
    def plan(self, command: str, mode: str="balanced", targets=None, overrides=None) -> StylePlan:
        p=self.create_profile(command,mode,overrides)
        t=list(targets or ["stage7","stage8","stage9","stage10","stage11","stage12"])
        warnings=[]
        if "optional_style_model" not in self.available: warnings.append("Optional generative style provider unavailable; deterministic style path is active.")
        plan=StylePlan(command,p,t,overrides or {},warnings)
        plan.validate(); plan.digest=digest_obj({"command":command,"profile":asdict(p),"targets":t,"overrides":overrides or {}}); return plan
    def handoff(self, plan: StylePlan) -> Dict[str,Any]:
        plan.validate()
        p=plan.profile
        return {"style_digest":plan.digest,"profile_digest":p.digest,"mode":p.mode,"palette":asdict(p.palette),"typography":[asdict(x) for x in p.typography],"motion":asdict(p.motion),"intensity":{"vfx":p.vfx_intensity,"grain":p.grain,"glow":p.glow,"audio":p.audio_energy,"meme":p.meme_energy},"brand_tokens":dict(p.brand_tokens),"targets":list(plan.targets),"provenance":p.provenance,"deterministic":True}
    def inspect(self, plan: StylePlan) -> Dict[str,Any]:
        plan.validate(); h=self.handoff(plan)
        return {"ok":True,"style_digest":plan.digest,"profile_digest":plan.profile.digest,"target_count":len(plan.targets),"palette_size":len(plan.profile.palette.colors),"typography_rules":len(plan.profile.typography),"warnings":list(plan.warnings),"handoff":h}

# Backward-friendly aliases for the project convention.
StyleEngine = Stage13StyleEngine
