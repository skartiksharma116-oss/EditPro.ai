from dataclasses import dataclass
@dataclass(frozen=True)
class VFXAlternative:
 name:str; capability:str; available_locally:bool; notes:str=''

PROVIDERS=[
 VFXAlternative('OpenCV + NumPy','mask/paint/procedural',True,'CPU baseline'),
 VFXAlternative('FFmpeg filters','compositing/filter primitives',True,'CPU baseline'),
 VFXAlternative('SAM 3.1','promptable segmentation/tracking',False,'external model runtime'),
 VFXAlternative('SAM 2.1','video mask tracking',False,'external model runtime'),
 VFXAlternative('ProMatting / MODNet family','matting',False,'model weights required'),
 VFXAlternative('NVIDIA TensorRT','GPU inference',False,'NVIDIA runtime required'),
 VFXAlternative('OpenVINO','Intel inference',False,'runtime/hardware optional'),
 VFXAlternative('Core ML','Apple inference',False,'Apple runtime required'),
 VFXAlternative('WebGPU','browser GPU inference',False,'browser/device dependent'),
 VFXAlternative('Cloud generative VFX','generative effects/inpainting',False,'provider credentials/model access required'),
]

def capability_report():
    return [{'name':p.name,'capability':p.capability,'local':p.available_locally,'notes':p.notes} for p in PROVIDERS]
