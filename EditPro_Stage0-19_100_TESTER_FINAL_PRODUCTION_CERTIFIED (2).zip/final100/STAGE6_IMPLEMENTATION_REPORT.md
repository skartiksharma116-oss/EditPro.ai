# EditPro.ai Stage 6 - AI VFX Operating System

Stage 6 is a VFX intelligence layer built on Stage 5 tracking. It provides a deterministic, non-destructive VFX plan/packet architecture with masking, surface transforms, effect planning, temporal criticism, bounded repair, provider routing, caching identity, and future-provider contracts.

## Included
- AI VFX Director / intent planner
- Object-aware effect attachment through Stage 5 track IDs
- Mask and roto foundation
- Keying contracts
- Object removal / paint / clone contracts
- Screen/sign/poster/surface replacement
- Procedural effects: glow, neon, fire, smoke, fog, rain, snow, sparks, lightning, energy, shockwave, particles, trails, blur, flash, atmosphere
- Relighting/light wrap/spill suppression contracts
- Camera/motion effect contracts
- Temporal consistency critic
- VFX repair engine
- Provider registry and CPU-safe fallback
- VFXPacket API for later stages
- Strict validation against malformed/non-finite data
- Non-destructive planning

## Deliberately excluded
Stage 7 character/motion generation, Stage 8 full compositing system, Stage 9 cinematography/camera director, Stage 10 audio studio, Stage 11 meme engine, Stage 12 image/asset engine, Stage 13 style engine, and Stage 14+ multi-AI expansion remain later-stage responsibilities. Stage 6 only exposes contracts needed to hand work forward.

## External capabilities
SAM 3.1, SAM 2.1, model-based matting, TensorRT/OpenVINO/Core ML/WebGPU, and cloud generative VFX are registered as alternatives but are not falsely claimed to have executed locally when their runtimes/weights are absent.
