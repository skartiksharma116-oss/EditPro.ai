# Stage 11 Scope Lock

Stage 11 is the AI Meme Engine. It owns meme context detection, candidate scoring,
asset provenance gating, timing, placement, anti-spam and safe fallback behavior.

It deliberately does not own:
- general cinematography (Stage 9)
- audio mastering (Stage 10)
- full compositing/3D (Stage 8)
- the later image/asset studio
- later multi-AI tournament systems
