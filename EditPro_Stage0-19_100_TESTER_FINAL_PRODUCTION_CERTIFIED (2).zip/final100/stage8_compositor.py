"""EditPro.ai Stage 8: hardened local-first 2D/3D compositing foundation.
No paid/cloud dependency is required. Optional open-source/browser backends are contracts only.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Tuple, Optional, Iterable
import hashlib, html, json, math, random, re

SUPPORTED_FORMATS = {
    "square": (1080,1080), "portrait": (1080,1920), "landscape": (1920,1080),
    "youtube_thumbnail": (1280,720), "instagram_story": (1080,1920),
    "reel": (1080,1920), "poster": (1080,1350), "youtube_banner": (2560,1440),
}
BLEND_MODES = {"normal","add","screen","multiply","overlay","darken","lighten"}
LAYER_KINDS = {"background","video","image","text","shape","character","3d","particle","effect","audio"}


def _finite(*values): return all(math.isfinite(float(v)) for v in values)

@dataclass
class Transform:
    x: float=0.0; y: float=0.0; z: float=0.0
    rotation_x: float=0.0; rotation_y: float=0.0; rotation_z: float=0.0
    scale_x: float=1.0; scale_y: float=1.0; scale_z: float=1.0; opacity: float=1.0
    anchor_x: float=0.5; anchor_y: float=0.5
    def validate(self):
        vals=[self.x,self.y,self.z,self.rotation_x,self.rotation_y,self.rotation_z,self.scale_x,self.scale_y,self.scale_z,self.opacity,self.anchor_x,self.anchor_y]
        if not _finite(*vals): raise ValueError("transform contains non-finite value")
        if min(self.scale_x,self.scale_y,self.scale_z)<0: raise ValueError("scale cannot be negative")
        if not 0<=self.opacity<=1: raise ValueError("opacity must be 0..1")
        if not 0<=self.anchor_x<=1 or not 0<=self.anchor_y<=1: raise ValueError("anchor must be 0..1")

@dataclass
class Mask:
    kind: str="rectangle"; points: List[Tuple[float,float]]=field(default_factory=list)
    feather: float=0.0; invert: bool=False; opacity: float=1.0
    def validate(self):
        if self.kind not in {"rectangle","ellipse","polygon"}: raise ValueError("unsupported mask")
        if not _finite(self.feather,self.opacity) or not 0<=self.feather<=1 or not 0<=self.opacity<=1: raise ValueError("invalid mask settings")
        for p in self.points:
            if len(p)!=2 or not _finite(*p): raise ValueError("invalid mask point")
        if self.kind=="polygon" and len(self.points)<3: raise ValueError("polygon needs 3 points")

@dataclass
class ChromaKey:
    enabled: bool=False; hue: float=120.0; tolerance: float=0.16; softness: float=0.08; spill: float=0.0
    def validate(self):
        if not _finite(self.hue,self.tolerance,self.softness,self.spill): raise ValueError("invalid chroma settings")
        if not 0<=self.tolerance<=1 or not 0<=self.softness<=1 or not 0<=self.spill<=1: raise ValueError("invalid chroma settings")

@dataclass
class Keyframe:
    frame: int; value: float; easing: str="linear"
    def validate(self):
        if self.frame<0 or not _finite(self.value): raise ValueError("invalid keyframe")
        if self.easing not in {"linear","ease_in","ease_out","ease_in_out","step"}: raise ValueError("unsupported easing")

@dataclass
class Asset:
    id: str; path: str; kind: str="image"; width: int=0; height: int=0
    def validate(self):
        if not self.id.strip() or not self.path.strip(): raise ValueError("asset id/path required")
        if self.kind not in {"image","video","audio","model","font"}: raise ValueError("unsupported asset kind")
        if self.width<0 or self.height<0: raise ValueError("invalid asset dimensions")

@dataclass
class SceneLayer:
    id: str; kind: str; start: int=0; end: int=1
    transform: Transform=field(default_factory=Transform); blend_mode: str="normal"
    masks: List[Mask]=field(default_factory=list); chroma: ChromaKey=field(default_factory=ChromaKey)
    properties: Dict[str,Any]=field(default_factory=dict); keyframes: Dict[str,List[Keyframe]]=field(default_factory=dict)
    asset_id: Optional[str]=None
    def validate(self):
        if not self.id.strip(): raise ValueError("layer id required")
        if self.kind not in LAYER_KINDS: raise ValueError("unsupported layer kind")
        if self.start<0 or self.end<=self.start: raise ValueError("invalid layer timing")
        if self.blend_mode not in BLEND_MODES: raise ValueError("unsupported blend mode")
        self.transform.validate(); self.chroma.validate()
        for m in self.masks: m.validate()
        for name, frames in self.keyframes.items():
            if not isinstance(name,str): raise ValueError("invalid keyframe property")
            for k in frames: k.validate()
            if any(a.frame>=b.frame for a,b in zip(frames,frames[1:])): raise ValueError("keyframes must be strictly ordered")

@dataclass
class Camera:
    position: Tuple[float,float,float]=(0,0,10); target: Tuple[float,float,float]=(0,0,0)
    fov: float=45.0; shake: float=0.0; near: float=0.01; far: float=10000.0
    def validate(self):
        if not 1<=self.fov<=179 or not _finite(self.fov,self.shake,self.near,self.far): raise ValueError("invalid camera")
        if self.shake<0 or self.near<=0 or self.far<=self.near: raise ValueError("invalid camera range")
        if not all(_finite(*p) for p in (self.position,self.target)): raise ValueError("invalid camera vector")

@dataclass
class Light:
    id: str; kind: str="ambient"; intensity: float=1.0; position: Tuple[float,float,float]=(0,0,5)
    color: str="#ffffff"; cast_shadow: bool=False; direction: Tuple[float,float,float]=(0,0,-1)
    def validate(self):
        if not self.id.strip() or self.kind not in {"ambient","directional","point"}: raise ValueError("invalid light")
        if not _finite(self.intensity,*self.position,*self.direction) or self.intensity<0: raise ValueError("invalid light intensity")
        if not re.fullmatch(r"#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?",self.color): raise ValueError("invalid light color")

@dataclass
class ParticleSystem:
    id: str; kind: str="dust"; count: int=100; seed: int=0; speed: float=1.0; lifetime: float=1.0
    gravity: float=0.0; size: float=2.0; opacity: float=0.5
    def validate(self):
        if not self.id.strip() or self.count<0 or self.count>250000: raise ValueError("invalid particle count")
        if not _finite(self.speed,self.lifetime,self.gravity,self.size,self.opacity) or self.speed<0 or self.lifetime<=0 or self.size<0 or not 0<=self.opacity<=1: raise ValueError("invalid particle values")
        if self.kind not in {"dust","smoke","rain","snow","sparks","fog","fire_like"}: raise ValueError("unsupported particle kind")
    def sample(self,frame:int,limit:int=512):
        self.validate(); n=min(self.count,max(0,int(limit))); rng=random.Random(self.seed+frame*7919)
        return [(rng.random(),rng.random(),rng.random(),rng.random()) for _ in range(n)]

@dataclass
class Scene:
    width: int=1920; height: int=1080; fps: int=30; duration_frames: int=30
    layers: List[SceneLayer]=field(default_factory=list); camera: Camera=field(default_factory=Camera)
    lights: List[Light]=field(default_factory=list); particles: List[ParticleSystem]=field(default_factory=list)
    assets: Dict[str,Asset]=field(default_factory=dict); metadata: Dict[str,Any]=field(default_factory=dict)
    camera_keyframes: Dict[str,List[Keyframe]]=field(default_factory=dict)
    def validate(self):
        if self.width<16 or self.height<16 or self.width>8192 or self.height>8192: raise ValueError("invalid scene size")
        if self.fps not in {1,2,5,10,12,15,20,24,25,30,50,60,90,120}: raise ValueError("unsupported fps")
        if self.duration_frames<=0 or self.duration_frames>10_000_000: raise ValueError("invalid duration")
        self.camera.validate(); ids=set()
        for aid,a in self.assets.items():
            if aid!=a.id: raise ValueError("asset key/id mismatch")
            a.validate()
        for l in self.layers:
            l.validate()
            if l.id in ids: raise ValueError("duplicate layer id")
            ids.add(l.id)
            if l.asset_id and l.asset_id not in self.assets: raise ValueError("layer references missing asset")
        for name, frames in self.camera_keyframes.items():
            if name not in {"x","y","z","target_x","target_y","target_z","fov","shake"}: raise ValueError("unsupported camera keyframe property")
            for k in frames: k.validate()
            if any(a.frame>=b.frame for a,b in zip(frames,frames[1:])): raise ValueError("camera keyframes must be strictly ordered")
        for x in self.lights: x.validate()
        for x in self.particles: x.validate()

class KeyframeEngine:
    @staticmethod
    def value(frames:List[Keyframe],frame:int,default:float)->float:
        if not frames: return default
        for k in frames: k.validate()
        if frame<=frames[0].frame: return frames[0].value
        if frame>=frames[-1].frame: return frames[-1].value
        for a,b in zip(frames,frames[1:]):
            if a.frame<=frame<=b.frame:
                if a.easing=="step": return a.value
                t=(frame-a.frame)/(b.frame-a.frame)
                if a.easing=="ease_in": t=t*t
                elif a.easing=="ease_out": t=1-(1-t)*(1-t)
                elif a.easing=="ease_in_out": t=t*t*(3-2*t)
                return a.value+(b.value-a.value)*t
        return default
    @classmethod
    def transform(cls,layer:SceneLayer,frame:int)->Transform:
        t=Transform(**asdict(layer.transform))
        mapping={"x":"x","y":"y","z":"z","rotation_x":"rotation_x","rotation_y":"rotation_y","rotation_z":"rotation_z","scale_x":"scale_x","scale_y":"scale_y","scale_z":"scale_z","opacity":"opacity"}
        for prop,attr in mapping.items():
            if prop in layer.keyframes: setattr(t,attr,cls.value(layer.keyframes[prop],frame,getattr(t,attr)))
        t.validate(); return t

class MaskEngine:
    @staticmethod
    def alpha_at(mask:Mask,x:float,y:float,width:int,height:int)->float:
        mask.validate(); inside=False
        if mask.kind=="rectangle": inside=0<=x<=width and 0<=y<=height
        elif mask.kind=="ellipse":
            nx=(x-width/2)/(width/2 or 1); ny=(y-height/2)/(height/2 or 1); inside=nx*nx+ny*ny<=1
        else:
            px=x/width; py=y/height; pts=mask.points; j=len(pts)-1
            for i,p in enumerate(pts):
                xi,yi=p; xj,yj=pts[j]
                if ((yi>py)!=(yj>py)) and px < (xj-xi)*(py-yi)/(yj-yi+1e-12)+xi: inside=not inside
                j=i
        a=mask.opacity if inside else 0.0
        return 1-a if mask.invert else a
    @staticmethod
    def bounds(mask:Mask,width:int,height:int):
        mask.validate()
        if mask.kind in {"rectangle","ellipse"}: return (0,0,width,height)
        xs=[max(0,min(width,p[0]*width)) for p in mask.points]; ys=[max(0,min(height,p[1]*height)) for p in mask.points]
        return (min(xs),min(ys),max(xs),max(ys))

class ChromaKeyEngine:
    @staticmethod
    def alpha(rgb:Tuple[int,int,int],key_hue:float=120.0,tolerance:float=.16,softness:float=.08):
        import colorsys
        if len(rgb)!=3 or not all(0<=int(c)<=255 for c in rgb): raise ValueError("RGB must be 0..255")
        h,s,v=colorsys.rgb_to_hsv(rgb[0]/255,rgb[1]/255,rgb[2]/255); d=abs(((h*360-key_hue+180)%360)-180)/180
        if d<=tolerance: return max(0.0,min(1.0,(d-tolerance+max(1e-6,softness))/max(1e-6,softness)))
        return 1.0
    @staticmethod
    def remove_spill(rgb:Tuple[int,int,int],spill:float)->Tuple[int,int,int]:
        spill=max(0,min(1,float(spill))); r,g,b=rgb; g=int(g*(1-spill)+max(r,b)*spill); return r,g,b

class TrackingEngine:
    @staticmethod
    def interpolate(observations:List[Tuple[int,float,float]],frame:int):
        if not observations: raise ValueError("tracking observations required")
        obs=sorted(observations)
        if any(len(o)!=3 or not _finite(*o) or o[0]<0 for o in obs): raise ValueError("invalid tracking observation")
        if any(a[0]>=b[0] for a,b in zip(obs,obs[1:])): raise ValueError("tracking frames must be unique and ordered")
        if frame<=obs[0][0]: return obs[0][1:]
        if frame>=obs[-1][0]: return obs[-1][1:]
        for a,b in zip(obs,obs[1:]):
            if a[0]<=frame<=b[0]:
                t=(frame-a[0])/(b[0]-a[0]); return (a[1]+t*(b[1]-a[1]),a[2]+t*(b[2]-a[2]))
        raise RuntimeError("unreachable")
    @staticmethod
    def attach(layer:SceneLayer, observations:List[Tuple[int,float,float]], frame:int, scale=1.0):
        x,y=TrackingEngine.interpolate(observations,frame); layer.transform.x=float(x)*scale; layer.transform.y=float(y)*scale; layer.transform.validate(); return layer

class SceneAnalyzer:
    @staticmethod
    def analyze(command:str)->Dict[str,Any]:
        text=(command or "").lower().strip()
        if not text: raise ValueError("command required")
        objects=[x for x in ("car","person","face","logo","text","background","road","sky","product","character","building") if re.search(r"\b"+x+r"\b",text)]
        effects=[x for x in ("fog","mist","dust","rain","snow","sparks","glow","blur","shadow","fire","smoke","light") if x in text]
        camera="static"
        for c in ("zoom","pan","orbit","dolly","shake","tilt"):
            if c in text: camera=c; break
        return {"objects":objects,"effects":effects,"camera":camera,"compositing":"hybrid" if "3d" in text or "3d" in text.replace(" ","") else "2d","tracking":any(x in text for x in ("track","follow","lock"))}

class ScenePlanner:
    @staticmethod
    def from_command(command:str,width:int=1920,height:int=1080,fps:int=30,duration_frames:int=90)->Scene:
        a=SceneAnalyzer.analyze(command); s=Scene(width,height,fps,duration_frames); s.metadata.update({"analysis":a,"command":command,"stage":8})
        s.layers.append(SceneLayer("background","background",0,duration_frames,properties={"color":"#101318"}))
        if any(w in command.lower() for w in ("video","reel","footage","clip")):
            s.layers.append(SceneLayer("source-video","video",0,duration_frames,properties={"source":"project_input"}))
        for i,obj in enumerate(a["objects"]):
            if obj=="text": kind="text"
            elif obj in {"car","product","character"} and a["compositing"]=="hybrid": kind="3d"
            else: kind="image"
            props={"subject":obj}
            if obj=="text": props["text"]="EditPro"
            s.layers.append(SceneLayer(f"{kind}-{i}",kind,0,duration_frames,properties=props))
        for i,e in enumerate(a["effects"]):
            if e in {"fog","mist","dust","rain","snow","sparks","smoke","fire"}: s.particles.append(ParticleSystem(f"p-{i}","fire_like" if e=="fire" else e,count=400,seed=i,opacity=.45))
            else: s.layers.append(SceneLayer(f"effect-{i}","effect",0,duration_frames,properties={"effect":e}))
        if a["camera"]=="zoom":
            s.camera.fov=55; s.camera_keyframes["fov"]=[Keyframe(0,55),Keyframe(max(1,duration_frames-1),35,"ease_in_out")]
        elif a["camera"] in {"pan","dolly","tilt","orbit"}:
            axis={"pan":"x","dolly":"z","tilt":"target_y","orbit":"x"}[a["camera"]]; end=80 if axis in {"x","target_y"} else -2; s.camera_keyframes[axis]=[Keyframe(0,0),Keyframe(max(1,duration_frames-1),end,"ease_in_out")]
        elif a["camera"] in {"shake","pan","tilt","orbit","dolly"}: s.metadata["camera_action"]=a["camera"]
        if a["tracking"]: s.metadata["tracking_required"]=True
        if a["compositing"]=="hybrid": s.lights.extend([Light("ambient","ambient",.7),Light("key","directional",1.1,position=(2,3,5),direction=(-.2,-.4,-1))])
        s.validate(); return s

class ProviderRegistry:
    PROVIDERS={
        "threejs":{"kind":"3d","license":"MIT","status":"optional","role":"WebGL/WebGPU 3D scene layer"},
        "pixijs":{"kind":"2d","license":"MIT","status":"optional","role":"2D accelerated compositing"},
        "webmotion":{"kind":"video","license":"MIT","status":"optional","role":"browser deterministic composition/WebCodecs"},
        "openvideo":{"kind":"video","license":"open-source","status":"optional","role":"Pixi/WebCodecs browser editor path"},
        "elah":{"kind":"video","license":"open-source","status":"optional","role":"renderer-agnostic WebGL2/WebCodecs editor infrastructure"},
        "ffmpeg":{"kind":"renderer","license":"LGPL/GPL depending build","status":"local","role":"codec/mux/render backend"},
        "opencv":{"kind":"vision","license":"Apache-2.0","status":"local-optional","role":"mask/chroma/tracking utilities"},
    }
    @classmethod
    def available(cls):
        import importlib.util, shutil
        out={}
        for name,info in cls.PROVIDERS.items():
            mod={"opencv":"cv2"}.get(name); installed=bool(shutil.which("ffmpeg")) if name=="ffmpeg" else (bool(importlib.util.find_spec(mod)) if mod else False)
            out[name]={**info,"installed":installed}
        return out

class SVGRenderer:
    @staticmethod
    def render(scene:Scene,frame:int=0)->str:
        scene.validate()
        if not 0<=frame<scene.duration_frames: raise ValueError("frame outside scene")
        bg="#101318"
        for l in scene.layers:
            if l.kind=="background" and l.start<=frame<l.end: bg=str(l.properties.get("color",bg))
        parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{scene.width}" height="{scene.height}" viewBox="0 0 {scene.width} {scene.height}">',f'<rect width="100%" height="100%" fill="{html.escape(bg,quote=True)}"/>']
        y=60
        for l in scene.layers:
            if not l.start<=frame<l.end: continue
            t=KeyframeEngine.transform(l,frame); op=t.opacity
            if l.kind=="text" or l.kind=="effect":
                txt=html.escape(str(l.properties.get("text") or l.properties.get("effect") or l.properties.get("subject","")))
                parts.append(f'<text x="{60+t.x:.3f}" y="{y+t.y:.3f}" font-family="sans-serif" font-size="42" opacity="{op:.4f}" fill="#ffffff">{txt}</text>'); y+=60
            elif l.kind=="shape":
                color=html.escape(str(l.properties.get("color","#ffffff")),quote=True); w=float(l.properties.get("width",200)); h=float(l.properties.get("height",120))
                parts.append(f'<rect x="{t.x-w*t.anchor_x:.3f}" y="{t.y-h*t.anchor_y:.3f}" width="{w*abs(t.scale_x):.3f}" height="{h*abs(t.scale_y):.3f}" fill="{color}" opacity="{op:.4f}"/>')
            elif l.kind=="3d":
                parts.append(f'<g opacity="{op:.4f}"><rect x="{scene.width/2+t.x-70:.2f}" y="{scene.height/2-t.y-70:.2f}" width="140" height="140" fill="#4b8fd8"/></g>')
        parts.append("</svg>"); return "".join(parts)

class SceneSerializer:
    @staticmethod
    def to_dict(scene:Scene): scene.validate(); return asdict(scene)
    @staticmethod
    def from_dict(data:Dict[str,Any])->Scene:
        if not isinstance(data,dict): raise ValueError("scene data must be object")
        layers=[]
        for raw in data.get("layers",[]):
            raw=dict(raw); raw["transform"]=Transform(**raw.get("transform",{})); raw["chroma"]=ChromaKey(**raw.get("chroma",{})); raw["masks"]=[Mask(**m) for m in raw.get("masks",[])]
            raw["keyframes"]={k:[Keyframe(**x) for x in v] for k,v in raw.get("keyframes",{}).items()}; layers.append(SceneLayer(**raw))
        assets={k:Asset(**v) for k,v in data.get("assets",{}).items()}
        cam=Camera(**data.get("camera",{})); lights=[Light(**x) for x in data.get("lights",[])]; particles=[ParticleSystem(**x) for x in data.get("particles",[])]
        ck={k:[Keyframe(**x) for x in v] for k,v in data.get("camera_keyframes",{}).items()}
        s=Scene(width=data.get("width",1920),height=data.get("height",1080),fps=data.get("fps",30),duration_frames=data.get("duration_frames",30),layers=layers,camera=cam,lights=lights,particles=particles,assets=assets,metadata=data.get("metadata",{}),camera_keyframes=ck); s.validate(); return s
    @staticmethod
    def digest(scene:Scene):
        raw=json.dumps(SceneSerializer.to_dict(scene),sort_keys=True,separators=(",",":"),allow_nan=False).encode(); return hashlib.sha256(raw).hexdigest()

class Stage8Pipeline:
    def plan(self,command:str,width=1920,height=1080,fps=30,duration_frames=90): return ScenePlanner.from_command(command,width,height,fps,duration_frames)
    def render_frame_svg(self,scene:Scene,frame=0): return SVGRenderer.render(scene,frame)
    def inspect(self,scene:Scene):
        scene.validate(); return {"layers":len(scene.layers),"particles":len(scene.particles),"lights":len(scene.lights),"assets":len(scene.assets),"digest":SceneSerializer.digest(scene)}
    def serialize(self,scene:Scene)->Dict[str,Any]: return SceneSerializer.to_dict(scene)
    def restore(self,data:Dict[str,Any])->Scene: return SceneSerializer.from_dict(data)

__all__=["SUPPORTED_FORMATS","BLEND_MODES","Transform","Mask","ChromaKey","Keyframe","Asset","SceneLayer","Camera","Light","ParticleSystem","Scene","KeyframeEngine","MaskEngine","ChromaKeyEngine","TrackingEngine","SceneAnalyzer","ScenePlanner","ProviderRegistry","SVGRenderer","SceneSerializer","Stage8Pipeline"]
