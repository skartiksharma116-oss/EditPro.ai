from __future__ import annotations
import json, os, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; UI=ROOT/'_ui'/'EditProAI_Stage0_1_PRO_FINAL2'/'public'
sys.path.insert(0,str(ROOT))
from stage3.pipeline import Stage3Pipeline
PIPE=Stage3Pipeline()

def send(h,code,obj):
    b=json.dumps(obj,separators=(',',':')).encode(); h.send_response(code); h.send_header('Content-Type','application/json'); h.send_header('Cache-Control','no-store'); h.send_header('Content-Length',str(len(b))); h.end_headers(); h.wfile.write(b)
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path=='/api/health': return send(self,200,{'ok':True,'stage':'3','ui':'integrated','engine':'foundation'})
        if self.path=='/':
            p=UI/'index.html'; b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html'); self.end_headers(); self.wfile.write(b); return
        return send(self,404,{'error':'not_found'})
    def do_POST(self):
        if self.path!='/api/stage3/analyze': return send(self,404,{'error':'not_found'})
        try:
            n=int(self.headers.get('Content-Length','0')); data=json.loads(self.rfile.read(n) or b'{}')
            required=('duration','width','height')
            if not isinstance(data,dict) or any(k not in data for k in required): raise ValueError('missing_required_field')
            r=PIPE.run(float(data['duration']),float(data['width']),float(data['height']),frames=data.get('frames',[]),objects=data.get('objects',[]),target=tuple(data.get('target',[9,16])),available_runtimes=tuple(data.get('available_runtimes',['cpu'])))
            return send(self,200,{'ok':True,'result':r})
        except (ValueError,TypeError,KeyError,OverflowError): return send(self,400,{'ok':False,'error':'invalid_stage3_request'})
        except Exception: return send(self,500,{'ok':False,'error':'stage3_internal_error'})
    def log_message(self,*args): pass
if __name__=='__main__':
    port=int(os.getenv('PORT','4183')); ThreadingHTTPServer(('127.0.0.1',port),H).serve_forever()
