from http.server import BaseHTTPRequestHandler,HTTPServer
import json
from stage4.pipeline import Stage4Pipeline
from orchestration import EditProOrchestrator, AdvancedOrchestrator, AdaptiveCreativeEngine, ResourceProfile

class Handler(BaseHTTPRequestHandler):
    pipeline=Stage4Pipeline()
    def _send(self,status,payload):
        data=json.dumps(payload,separators=(',',':')).encode(); self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_POST(self):
        if self.path not in ('/api/stage4/analyze','/api/orchestrate'): self._send(404,{'error':'not_found'}); return
        try:
            n=int(self.headers.get('Content-Length','0')); body=json.loads(self.rfile.read(n).decode())
            if not isinstance(body,dict): raise ValueError('object required')
            if self.path=='/api/orchestrate':
                av=set(map(str,body.get('available',('cpu',))))
                prof=ResourceProfile('api-runtime',cpu=True,cuda='cuda' in av,tensorrt='tensorrt' in av,migraphx='migraphx' in av,openvino='openvino' in av,directml='directml' in av,coreml='coreml' in av,webgpu='webgpu' in av,cloud='cloud' in av,max_workers=max(1,min(int(body.get('max_workers',2)),64)),memory_mb=max(256,min(int(body.get('memory_mb',4096)),262144)))
                result=AdaptiveCreativeEngine(AdvancedOrchestrator(profile=prof)).execute(body)
            else:
                if not isinstance(body.get('words'),list): raise ValueError('words required')
                result=self.pipeline.run(body['words'],body.get('duration'),body.get('language'),body.get('speakers'),body.get('visual_context'),body.get('profile','clean'),body.get('command'),tuple(body.get('available',('cpu',))))
            self._send(200,result)
        except Exception as e:self._send(400,{'error':type(e).__name__,'message':str(e)})
    def log_message(self,*args): pass

def create_server(host='127.0.0.1',port=8794): return HTTPServer((host,port),Handler)
