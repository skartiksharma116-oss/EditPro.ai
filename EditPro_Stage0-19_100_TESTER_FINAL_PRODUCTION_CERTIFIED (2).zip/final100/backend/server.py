from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os, json
ROOT=Path(__file__).resolve().parent.parent; FRONT=(ROOT/'frontend').resolve()

class H(BaseHTTPRequestHandler):
    def _send_json(self, payload, status=200):
        body=json.dumps(payload).encode()
        self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if self.path=='/api/health': return self._send_json({'ok':True,'stage':'2','systems':['editor','video-understanding','ai-director','pipeline','provider-contracts']})
        if self.path=='/api/stage2': return self._send_json({'pipeline':'media -> analyzer -> director -> validator','destructive':False,'provider_fallbacks':True})
        rel = self.path.split('?',1)[0].lstrip('/')
        try: p=(FRONT/rel).resolve()
        except Exception: return self.send_error(404)
        try: p.relative_to(FRONT)
        except ValueError: return self.send_error(404)
        if not p.is_file(): return self.send_error(404)
        body=p.read_bytes(); c='text/html' if p.suffix=='.html' else 'text/css' if p.suffix=='.css' else 'application/javascript'
        self.send_response(200); self.send_header('Content-Type',c); self.send_header('Content-Length',str(len(body))); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body)
    def log_message(self,*args): pass

if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',int(os.getenv('PORT','8098'))),H).serve_forever()
