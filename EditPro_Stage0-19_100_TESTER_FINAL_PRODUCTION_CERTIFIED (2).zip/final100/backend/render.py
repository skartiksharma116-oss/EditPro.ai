import shutil, subprocess, sys
if len(sys.argv)!=3: raise SystemExit('Usage: python render.py input output')
if not shutil.which('ffmpeg'): raise SystemExit('FFmpeg not installed')
r=subprocess.run(['ffmpeg','-y','-i',sys.argv[1],'-map','0:v:0','-map','0:a?','-c:v','libx264','-preset','veryfast','-crf','18','-c:a','aac','-movflags','+faststart',sys.argv[2]])
raise SystemExit(r.returncode)
