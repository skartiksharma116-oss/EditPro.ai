import random
from stage12_asset_studio import *

def main():
    lib=AssetLibrary([
        AssetRecord('a',kind='user_import',license_class='user_owned',width=1920,height=1080,metadata=AssetMetadata(tags=['person','thumbnail'],objects=['person'])),
        AssetRecord('b',kind='background',license_class='app_approved',width=1080,height=1920,metadata=AssetMetadata(tags=['cinematic'],objects=['sky']))])
    p=Stage12Pipeline(lib)
    plan=p.plan('make a premium thumbnail',5,'thumbnail',asset_query='thumbnail',edits=[{'operation':'background_remove'},{'operation':'smart_crop'}])
    assert p.inspect(plan)['ok'] and len(plan.selected_assets)==1
    r=p.apply_edit('a',{'operation':'background_remove'})
    assert r.provider=='pillow_cpu' and r.output_id.startswith('a__')
    assert lib.search('cinematic')[0].id=='b'
    for i in range(10000):
        aid=f'x{i}'
        a=AssetRecord(aid,kind='generated',license_class='app_approved',width=random.randint(1,4000),height=random.randint(1,4000))
        a.validate()
    bad=False
    try: AssetRecord('bad',kind='x')
    except ValueError: bad=True
    assert bad
    print('STAGE12_PASS=10008')
if __name__=='__main__': main()
