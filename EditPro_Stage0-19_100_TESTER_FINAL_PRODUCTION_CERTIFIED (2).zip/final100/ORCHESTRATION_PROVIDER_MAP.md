# EditPro.ai Provider / Alternative Map

This is a routing map, not a claim that every provider is installed.

| Capability | Primary alternatives wired into contract | Local fallback | Cloud fallback |
|---|---|---|---|
| ASR | Whisper large-v3-turbo, Whisper large-v3, Qwen3-ASR, Parakeet, Canary-Qwen | available local ASR runtime | cloud ASR |
| Segmentation | SAM2, YOLO segmentation | SAM2/YOLO | cloud segmentation |
| Tracking | ByteTrack, OC-SORT | either | cloud vision |
| Depth | Depth Anything | local depth | cloud vision |
| Pose | RTMPose | local pose | cloud vision |
| Face | face landmarks | local | cloud face |
| Video generation | Runway, Veo, Kling | none yet | cloud video |
| Video editing | Runway Aleph | none yet | cloud video edit |
| Images | model router / generative fill router | local model contract | cloud |
| Upscaling | Real-ESRGAN | local | cloud |
| Interpolation | RIFE | local | cloud |
| Audio restoration | restoration worker | local | cloud audio |
| Separation | Demucs | local | cloud audio |
| Voice | voice/dubbing router | local TTS contract | cloud |
| Music | music intelligence | local | cloud |
| Memes | rights-aware router | local index contract | web/cloud index |
| Color | OpenColorIO/ACES | local | GPU color |
| Motion graphics | WebGPU | local | Blender/cloud |
| VFX | Blender, Houdini | local | cloud VFX |
| Rendering | FFmpeg, NVENC, QSV, VideoToolbox | CPU | cloud render |
| Search | multimodal project index | local | cloud search |
| Memory | semantic project memory | local | cloud |
| Critic | multimodal critic | local | cloud |
| Comparison | result comparator | local | cloud |
| Cloud workers | cloud router | local worker | cloud |
| Device optimization | device profile router | local | n/a |
| Collaboration | project sync | local project store | cloud |
| Publishing | platform export router | local | cloud publishing |
| Accessibility | accessibility critic | local | cloud |
| Security | privacy policy engine | local | n/a |
| Director | EditPro creative director | local | cloud director |
| Timeline | non-destructive timeline | local | n/a |
| Assets | asset intelligence | local | cloud |
| Creator pack | thumbnail/title/metadata router | local contract | cloud |

## Routing rule

1. Prefer a compatible provider based on requested priority.
2. Respect local-only privacy mode.
3. Never report an unavailable runtime as executed.
4. If no provider is available, mark the task `deferred` and preserve the reason.
5. Keep provider provenance in the audit trail.
