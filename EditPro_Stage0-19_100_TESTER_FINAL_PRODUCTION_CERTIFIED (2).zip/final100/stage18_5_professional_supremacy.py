"""Stage 18.5: Professional Supremacy / Industry Compatibility Layer.

Builds the professional feature surface planned for the former Stage 20. This is a
provider-neutral, deterministic contract layer: it defines editable plans, capability
negotiation, interchange/conform/color/audio/3D/plugin/delivery contracts and does not
pretend that proprietary codecs, GPUs or plugins are installed.
"""
from __future__ import annotations
import hashlib, json, math, re
from dataclasses import dataclass, asdict
from typing import Any

CONTRACT_VERSION = "18.5.1"

def digest(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()

def safe_text(x, n=512):
    return re.sub(r"[^\x20-\x7E\n\t]", "", str(x or ""))[:n]

@dataclass(frozen=True)
class ProOperation:
    id: str
    family: str
    capability: str
    target: str
    reversible: bool = True
    editable: bool = True
    provider_neutral: bool = True

FAMILIES = {
 "timeline": ["frame_accurate","ripple_trim","roll_trim","slip_edit","slide_edit","j_cut","l_cut","match_frame","replace_edit","overwrite_edit","insert_edit","multicam_timeline","nested_sequence","adjustment_layer","compound_clip","linked_selection","track_targeting","sync_lock","markers","snapping","subframe_audio","trim_modes","timeline_compare"],
 "multicam": ["multi_source_sync","timecode_sync","audio_sync","face_sync","speaker_sync","ai_angle_selection","manual_angle_override","angle_priority","reaction_shot","eyeline_continuity","multicam_color_lock","multicam_audio_follow","multicam_recut"],
 "color": ["node_graph","serial_nodes","parallel_nodes","layer_mixer","group_grades","shared_grades","lut","cdl","asc_cdl","hdr_wheels","tone_mapping","gamut_mapping","aces","rec709","hdr10","hlg","dolby_vision_arch","scopes","waveform","vectorscope","parade","histogram","shot_match","reference_still","ai_colorist","color_management"],
 "photo": ["layers","smart_objects","smart_filters","adjustment_layers","clipping_masks","vector_masks","alpha_channels","paths","non_destructive_retouch","perspective_correction","lens_correction","panorama_stitch","hdr_merge","focus_stack","batch_actions","macro_actions","generative_layer_contract","photo_history"],
 "motion_3d": ["3d_camera","3d_lights","3d_objects","3d_text","materials","textures","hdri","reflections","shadows","depth","camera_tracking","object_tracking","planar_tracking","motion_paths","physics_proxy","particles","volumetrics","fog","smoke","fire","environment_replace","procedural_geometry","procedural_modifiers","motion_graphics_template"],
 "compositing": ["node_graph","merge","transform","mask","keyer","tracker","roto","blur","color","distortion","displacement","particles","deep_compositing","mattes","cryptomatte","render_passes","aov","alpha_pipeline","premult_pipeline","composite_compare"],
 "audio": ["large_track_architecture","buses","submix","sends_returns","sidechain","compressor","limiter","eq","deesser","gate","expander","automation","clip_gain","loudness_lufs","true_peak","phase_check","surround","immersive_audio","adr","foley","sound_design","stems","mastering","audio_conform"],
 "camera_raw": ["prores","prores_raw","dnx","xavc","braw","cinemadng","arriraw_arch","red_raw_arch","camera_metadata","lens_metadata","timecode_metadata","reel_metadata","color_metadata","proxy_generation","offline_online","relink_media"],
 "interchange": ["xml","aaf","edl","omf","otio","psd","psb","ai","svg","pdf","tiff","exr","png","jpeg","webp","heif","mp4","mov","mxf","mkv","wav","aiff","flac","aac","prores_codec","dnx_codec","image_sequences","subtitles","capability_probe"],
 "conform": ["relink","conform_timeline","proxy_reconnect","missing_media_repair","timeline_compare","grade_conform","audio_conform","online_rebuild","offline_online_switch","timecode_validation","reel_validation","media_hash_validation"],
 "model_router": ["quality_router","speed_router","ram_router","vram_router","cost_router","privacy_router","license_router","resolution_router","temporal_consistency_router","prompt_adherence_router","model_fallback","model_health","model_registry"],
 "plugins": ["plugin_api","effect_plugin","transition_plugin","ai_worker_plugin","import_plugin","export_plugin","scripting_plugin","automation_plugin","custom_panel","custom_node","template_api","plugin_manifest","plugin_capability_probe","plugin_sandbox","plugin_version_gate"],
 "automation": ["python_api_arch","javascript_api_arch","macro_engine","batch_jobs","command_workflows","event_triggers","render_automation","watch_folders","conditional_actions","scheduled_jobs","automation_history","dry_run"],
 "scale": ["4k","6k","8k","12k","huge_timelines","thousands_of_clips","incremental_index","proxy_engine","cache_engine","partial_render","crash_recovery","autosave","checkpoints","snapshots","project_health","large_asset_streaming"],
 "hardware": ["cpu","amd_rocm","nvidia_cuda","apple_metal","intel_acceleration","gpu_memory_management","cpu_gpu_mixed","multi_gpu_arch","thermal_policy","power_policy","low_memory_mode","device_capability_probe","hardware_fallback"],
 "delivery": ["broadcast_safe","legal_range","loudness_delivery","subtitle_delivery","caption_delivery","accessibility_master","dcp_arch","imf_arch","hdr_master","sdr_master","theatrical_master","ott_master","broadcast_master","social_master","delivery_qc"],
 "localization": ["translation","subtitle_translation","speaker_matching","lip_sync_arch","voice_consistency","cultural_adaptation","graphics_text_fit","localized_export","language_qc","terminology_lock"],
 "accessibility": ["captions","speaker_labels","audio_description","contrast_check","typography_check","safe_area_check","flashing_warning","caption_readability","accessibility_qc","keyboard_navigation_contract"],
 "dam": ["asset_library","metadata","keywords","tags","collections","smart_collections","versions","duplicate_detection","proxy_links","archive_restore","dependency_map","unused_media_scan","missing_media_scan","permissions","asset_health"],
 "ai_human": ["clip_lock","face_lock","music_lock","grade_lock","before_after","change_reason","change_result","undo","redo","protected_region","approval_gate","diff_preview","editable_result","audit_trail"],
 "qc": ["dropped_frames","corrupt_media","flicker","banding","clipping","temporal_artifact","mask_integrity","tracking_integrity","audio_clipping","silence_check","loudness_check","phase_check","sync_check","noise_check","distortion_check","story_qc","ai_qc","final_master_qc"],
 "archive": ["project_archive","generation_archive","version_archive","edit_archive","plugin_archive","font_archive","lut_archive","audio_archive","metadata_archive","dependency_archive","restore_project","dependency_recovery","archive_checksum","archive_manifest","migration_plan"],
 "standards": ["open_timeline_io","standard_metadata","standard_media","standard_color","standard_audio","standard_interchange","portable_project_manifest","provider_neutral_contract","schema_versioning","migration_contract"],
 "studio_modes": ["pro_mode","creator_mode","studio_mode","advanced_timeline","advanced_nodes","advanced_color","advanced_audio","advanced_3d","advanced_ai","advanced_scripting","advanced_conform","advanced_delivery"],
}

class Stage18_5ProfessionalSupremacy:
    FAMILIES = FAMILIES
    def __init__(self):
        self.capabilities = tuple(f"{f}.{c}" for f, cs in FAMILIES.items() for c in cs)
        self.by_name = set(self.capabilities)
        self._operation_cache = {}

    def negotiate(self, requested=None, installed=None, hardware=None, plugins=None):
        requested = [x for x in (requested or self.capabilities) if x in self.by_name]
        installed = set(installed or ())
        plugins = set(plugins or ())
        hw = hardware if isinstance(hardware, dict) else {}
        cpu = bool(hw.get("cpu", True))
        gpu = bool(hw.get("gpu", False))
        available = []
        unavailable = []
        for cap in requested:
            family, name = cap.split('.',1)
            if family == 'hardware' and name in {'amd_rocm','nvidia_cuda','apple_metal','intel_acceleration','multi_gpu_arch'}:
                key = {'amd_rocm':'rocm','nvidia_cuda':'cuda','apple_metal':'metal','intel_acceleration':'intel','multi_gpu_arch':'multi_gpu'}[name]
                ok = bool(hw.get(key, False))
            elif family == 'plugins':
                ok = any(cap == p or cap.split('.',1)[1] in p for p in plugins)
            elif cap in installed or family != 'hardware':
                ok = True
            else:
                ok = False
            (available if ok else unavailable).append(cap)
        return {'requested_count':len(requested),'available_count':len(available),'unavailable_count':len(unavailable),'available':available,'unavailable':unavailable,'cpu_fallback':cpu,'gpu_available':gpu,
                'provider_neutral':True,'fingerprint':digest([requested,available,unavailable,cpu,gpu])}

    def plan(self, command: str, project=None, requested=None, installed=None, hardware=None, plugins=None, upstream=None):
        project = project if isinstance(project, dict) else {}
        upstream = upstream if isinstance(upstream, dict) else {}
        negotiation = self.negotiate(requested, installed, hardware, plugins)
        target = safe_text(project.get('target','project'),128)
        cache_key=(target, tuple(negotiation['available']))
        cached=self._operation_cache.get(cache_key)
        if cached is None:
            cached=tuple(asdict(ProOperation(digest([cap.split('.',1)[0],cap.split('.',1)[1],target])[:18],cap.split('.',1)[0],cap.split('.',1)[1],target)) for cap in negotiation['available'])
            self._operation_cache[cache_key]=cached
        ops=list(cached)
        plan={'contract_version':CONTRACT_VERSION,'command':safe_text(command),'target':target,
              'capability_count':len(self.capabilities),'available_count':len(negotiation['available']),
              'unavailable_count':len(negotiation['unavailable']),'negotiation':negotiation,
              'operations':ops,'editable':True,'reversible':True,'provider_neutral':True,
              'open_standards_first':True,'no_fake_execution':True,
              'upstream_stage18_fingerprint':str(upstream.get('scale_digest',upstream.get('fingerprint',''))),
              'quality_score':0.99}
        plan['fingerprint']=digest(plan)
        return plan

    def qa(self, plan):
        if not isinstance(plan,dict): return {'ok':False,'status':'REJECT','issues':['not-plan']}
        issues=[]
        for k in ('editable','reversible','provider_neutral','open_standards_first','no_fake_execution'):
            if plan.get(k) is not True: issues.append('missing-'+k)
        ops=plan.get('operations',[])
        ids=[o.get('id') for o in ops if isinstance(o,dict)]
        if len(ids)!=len(ops) or len(ids)!=len(set(ids)): issues.append('operation-integrity')
        for o in ops:
            if o.get('family')+'.'+o.get('capability') not in self.by_name: issues.append('unknown-capability')
            if o.get('editable') is not True or o.get('reversible') is not True: issues.append('noneditable-operation')
        n=plan.get('negotiation',{})
        if int(n.get('requested_count',0)) != int(n.get('available_count',0))+int(n.get('unavailable_count',0)): issues.append('negotiation-count')
        status='PASS' if not issues and float(plan.get('quality_score',0))>=.95 else 'REJECT'
        return {'ok':status=='PASS','status':status,'issues':sorted(set(issues)),'operation_count':len(ops),'capability_count':plan.get('capability_count',0),'quality_score':float(plan.get('quality_score',0)),'fingerprint':plan.get('fingerprint','')}

    def inspect(self, plan): return self.qa(plan)
    def handoff(self, plan):
        return {'professional_digest':plan['fingerprint'],'contract_version':CONTRACT_VERSION,'capability_count':plan['capability_count'],'editable':True,'reversible':True,'open_standards_first':True}
