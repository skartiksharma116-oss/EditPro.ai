# EditPro.ai Stage 6

Stage 6 is the **AI VFX Operating System** layer.

It consumes Stage 5 tracking/object intelligence and produces non-destructive `VFXPacket` plans that can be rendered by local procedural workers or external AI providers when available.

This package intentionally does not claim that unavailable external model weights, GPUs, cloud credentials, or proprietary APIs executed locally.

## Quick smoke test
```bash
PYTHONPATH=. python tests/stage6_ultra.py
```

Expected: 1,000,000 VFX planning/critic/repair cycles plus adversarial validation.
