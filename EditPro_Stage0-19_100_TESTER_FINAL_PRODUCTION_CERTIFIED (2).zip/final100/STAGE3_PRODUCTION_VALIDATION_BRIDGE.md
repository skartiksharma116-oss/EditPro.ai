# Stage 3 Production Validation Bridge

This bridge turns unavailable external environments into executable validation adapters without falsely claiming external execution.

## Real external targets when credentials/endpoints exist
- NVIDIA endpoint: `EDITPRO_NVIDIA_ENDPOINT`
- AMD endpoint: `EDITPRO_AMD_ENDPOINT`
- Cloud AI endpoint: `EDITPRO_CLOUD_AI_URL`
- AWS Device Farm: AWS credentials

## Local equivalent validation
- deterministic model artifact registry with SHA-256 verification
- GPU/AI/device contract mutation testing
- failure injection and fallback testing
- UI performance-budget checks
- plugin conformance
- reproducible regression suites

## Truth rule
A local contract test is never labeled as physical NVIDIA/AMD/device execution. External execution is marked available only when its runtime credentials/endpoints are actually present.

## Model policy
Production models must be versioned, hash-verified and immutable once promoted. A changed artifact is a new model version.
