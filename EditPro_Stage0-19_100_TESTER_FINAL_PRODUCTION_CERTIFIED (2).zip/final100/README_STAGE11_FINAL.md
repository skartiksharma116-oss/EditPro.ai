# EditPro.ai Stage 11 — AI Meme Engine

Stage 11 adds context-aware meme/reaction placement intelligence above Stages 7–10.

## Scope
- Context + emotion + timing analysis
- Candidate ranking
- Anti-cringe quality floor
- Anti-spam spacing
- Beat/dialogue awareness
- Format-aware placement
- Approved/licensed/public-domain/user-owned asset policy
- Deterministic plans and SHA-256 digests
- Safe no-asset and no-meme fallbacks
- Integration with the Stage 0–10 orchestration facade

## Asset policy
The engine does **not** scrape or download random meme media. Assets must be supplied to the catalog with an explicit provenance class: `licensed`, `public_domain`, `user_owned`, or `app_approved`.

## Validation
- Stage 11 deterministic/adversarial suite: 120,000 checks
- Stage 0→11 integration stress: 1,000 checks
- Stage 8 integration: 10,000 checks
- Stage 8 raster + FFmpeg preview: PASS
- Stage 10 stress: 21,008 checks
- Python compileall: PASS

Long-running legacy audits that exceed the execution window are not counted as passes.
