"""EditPro.ai Stage 12: Full Image & Asset Studio.

Local-first, deterministic asset intelligence and safe image operations. Optional AI
providers are contracts only; CPU/Pillow/OpenCV-style fallbacks keep the core usable.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple
import hashlib, json, math, mimetypes, os, re

FORMATS={"square","portrait","landscape","reel","story","youtube","thumbnail","banner","instagram_post","instagram_story","youtube_thumbnail","youtube_banner"}
ASSET_KINDS={"image","background","poster","thumbnail","logo","icon","sticker","character","product","generated","template","user_import"}
LICENSE_CLASSES={"licensed","public_domain","user_owned","app_approved"}
EDIT_OPS={"crop","smart_crop","resize","reframe","background_remove","background_replace","object_remove","object_replace","restore","upscale","color_correct","lighting","sharpen","deblur","portrait_enhance","mask_refine","video_reframe"}
PROVIDERS={"pillow_cpu","opencv_cpu","rembg_optional","lama_optional","realesrgan_optional","segment_anything_optional","ocr_optional"}

def finite(*xs): return all(math.isfinite(float(x)) for x in xs)
def clamp(v,lo=0.,hi=1.): return max(lo,min(hi,float(v)))
def norm(x): return re.sub(r"[^a-z0-9_ -]+","",str(x or "").lower()).strip()
def digest_obj(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()

@dataclass
class AssetMetadata:
    tags:List[str]=field(default_factory=list)
    objects:List[str]=field(default_factory=list)
    faces:int=0
    ocr_text:str=""
    quality_score:float=.5
    duplicate_group:str=""
    source_uri:str=""
    attribution:str=""
    def validate(self):
        if not 0<=self.faces<=1000 or not finite(self.quality_score) or not 0<=self.quality_score<=1: raise ValueError("invalid metadata")
        if any(not isinstance(x,str) for x in self.tags+self.objects): raise ValueError("invalid metadata labels")

@dataclass
class AssetRecord:
    id:str
    path:str=""
    kind:str="user_import"
    license_class:str="user_owned"
    mime_type:str=""
    width:int=0
    height:int=0
    duration:float=0.0
    version:int=1
    metadata:AssetMetadata=field(default_factory=AssetMetadata)
    parent_id:str=""
    digest:str=""
    def __post_init__(self):
        if isinstance(self.metadata,dict): self.metadata=AssetMetadata(**self.metadata)
        self.validate()
    def validate(self):
        self.metadata.validate()
        if not isinstance(self.id,str) or not self.id.strip() or self.kind not in ASSET_KINDS or self.license_class not in LICENSE_CLASSES:
            raise ValueError("invalid asset record")
        if isinstance(self.width,bool) or isinstance(self.height,bool) or isinstance(self.version,bool):
            raise ValueError("invalid asset dimensions/version")
        if not isinstance(self.width,int) or not isinstance(self.height,int) or not isinstance(self.version,int):
            raise ValueError("invalid asset dimensions/version")
        if self.width<0 or self.height<0 or not finite(self.duration) or self.duration<0 or self.version<1:
            raise ValueError("invalid asset dimensions/version")
        if not self.digest: self.digest=digest_obj({"id":self.id,"path":self.path,"kind":self.kind,"width":self.width,"height":self.height,"version":self.version})

@dataclass
class EditRequest:
    operation:str
    params:Dict[str,Any]=field(default_factory=dict)
    provider_preference:List[str]=field(default_factory=lambda:["pillow_cpu","opencv_cpu"])
    def validate(self):
        if self.operation not in EDIT_OPS: raise ValueError("unsupported edit operation")
        if not isinstance(self.params,dict): raise ValueError("invalid edit params")
        if any(p not in PROVIDERS for p in self.provider_preference): raise ValueError("unknown provider")

@dataclass
class EditResult:
    source_id:str
    operation:str
    provider:str
    output_id:str
    warnings:List[str]=field(default_factory=list)
    changed:bool=True
    digest:str=""
    def validate(self):
        if not self.source_id or self.operation not in EDIT_OPS or self.provider not in PROVIDERS or not self.output_id: raise ValueError("invalid edit result")

@dataclass
class AssetPlan:
    command:str
    duration:float
    target_format:str
    selected_assets:List[str]=field(default_factory=list)
    edits:List[EditRequest]=field(default_factory=list)
    warnings:List[str]=field(default_factory=list)
    metadata:Dict[str,Any]=field(default_factory=dict)
    digest:str=""
    def validate(self):
        if not isinstance(self.command,str) or not self.command.strip() or not finite(self.duration) or self.duration<=0 or self.target_format not in FORMATS: raise ValueError("invalid asset plan")
        for e in self.edits: e.validate()

class AssetLibrary:
    def __init__(self,assets:Optional[List[AssetRecord]]=None):
        self.assets=[]
        for a in (assets or []): self.add(a)
    def add(self,a):
        if isinstance(a,dict): a=AssetRecord(**a)
        a.validate()
        if any(x.id==a.id for x in self.assets): raise ValueError("duplicate asset id")
        self.assets.append(a)
    def get(self,asset_id):
        for a in self.assets:
            if a.id==asset_id: return a
        return None
    def eligible(self): return [a for a in self.assets if a.license_class in LICENSE_CLASSES]
    def search(self,query="",kind=None,tags=None):
        q=set(norm(query).split()); tags=set(norm(x) for x in (tags or [])); out=[]
        for a in self.eligible():
            if kind and a.kind!=kind: continue
            hay=set(norm(a.id).split())|set(norm(a.kind).split())|set(norm(x) for x in a.metadata.tags)|set(norm(x) for x in a.metadata.objects)
            if q and not (q & hay): continue
            if tags and not tags.issubset(hay): continue
            out.append(a)
        return sorted(out,key=lambda x:(-x.metadata.quality_score,x.id))
    def duplicate_groups(self):
        groups={}
        for a in self.assets: groups.setdefault(a.digest,[]).append(a.id)
        return {k:v for k,v in groups.items() if len(v)>1}

class AssetAnalyzer:
    @staticmethod
    def inspect(path:str,width:int=0,height:int=0,mime_type:str="",ocr_text:str="",objects=None,faces:int=0):
        if not path or not isinstance(path,str): raise ValueError("path required")
        mt=mime_type or mimetypes.guess_type(path)[0] or "application/octet-stream"
        quality=.5
        if width and height:
            area=width*height; quality=clamp(0.35+min(area/4_000_000,.4)+(0.15 if width>=height else .1))
        meta=AssetMetadata(tags=[],objects=[norm(x) for x in (objects or []) if norm(x)],faces=int(faces),ocr_text=str(ocr_text or ""),quality_score=quality)
        meta.validate(); return {"mime_type":mt,"width":max(0,int(width)),"height":max(0,int(height)),"metadata":meta}
    @staticmethod
    def score(asset:AssetRecord):
        asset.validate(); return {"quality":asset.metadata.quality_score,"resolution":clamp((asset.width*asset.height)/8_000_000 if asset.width and asset.height else 0),"metadata_completeness":clamp((len(asset.metadata.tags)+len(asset.metadata.objects)+(1 if asset.metadata.ocr_text else 0))/8)}

class Stage12ProviderRegistry:
    def __init__(self,available=None): self.available=set(available or {"pillow_cpu","opencv_cpu"})
    def choose(self,preferred):
        preferred=list(preferred or [])
        for p in preferred:
            if p in self.available: return p
        if "pillow_cpu" in self.available: return "pillow_cpu"
        if self.available: return sorted(self.available)[0]
        # CPU is the non-optional safety net. An empty provider set must never
        # turn a safe fallback into an IndexError.
        self.available.add("pillow_cpu")
        return "pillow_cpu"

class Stage12Pipeline:
    def __init__(self,library=None,providers=None):
        self.library=library if isinstance(library,AssetLibrary) else AssetLibrary(library or [])
        self.providers=Stage12ProviderRegistry(providers)
    def plan(self,command,duration,target_format="landscape",asset_query="",kind=None,tags=None,edits=None,asset_ids=None):
        target_format=target_format if target_format in FORMATS else "landscape"; duration=max(.001,float(duration))
        selected=[]
        for aid in (asset_ids or []):
            if self.library.get(aid): selected.append(aid)
        if asset_query or kind or tags:
            selected.extend(a.id for a in self.library.search(asset_query,kind,tags) if a.id not in selected)
        reqs=[]
        for e in (edits or []): reqs.append(e if isinstance(e,EditRequest) else EditRequest(**e))
        warnings=[]
        if not selected: warnings.append("No matching assets supplied; plan remains safe and non-destructive.")
        if any(e.operation in {"background_remove","object_remove","object_replace","restore","upscale","deblur"} for e in reqs):
            if not any(p in self.providers.available for p in ("rembg_optional","lama_optional","realesrgan_optional")): warnings.append("Optional AI providers unavailable; CPU fallback contract will be used.")
        plan=AssetPlan(command,duration,target_format,selected,reqs,warnings,{"stage12_version":"12.0","provenance_policy":"approved_or_licensed_or_user_owned","video_aware":True,"cpu_fallback":True})
        plan.validate(); plan.digest=digest_obj({"command":plan.command,"duration":plan.duration,"target_format":plan.target_format,"selected_assets":plan.selected_assets,"edits":[asdict(e) for e in plan.edits],"metadata":plan.metadata}); return plan
    def apply_edit(self,asset_id,request):
        a=self.library.get(asset_id)
        if not a: raise ValueError("asset not found")
        req=request if isinstance(request,EditRequest) else EditRequest(**request); req.validate()
        provider=self.providers.choose(req.provider_preference)
        next_version=max([x.version for x in self.library.assets if x.id==a.id or x.parent_id==a.id] or [a.version]) + 1
        out_id=f"{a.id}__{req.operation}__v{next_version}"
        while self.library.get(out_id):
            next_version += 1
            out_id=f"{a.id}__{req.operation}__v{next_version}"
        warnings=[]
        if req.operation in {"background_remove","object_remove","object_replace","restore","upscale","deblur"} and provider=="pillow_cpu": warnings.append("CPU fallback used; quality may be lower than optional AI model output.")
        out=EditResult(a.id,req.operation,provider,out_id,warnings,True)
        out.digest=digest_obj(asdict(out)); out.validate()
        # Stage 12 is explicitly versioned. Keep the result in the same catalog so
        # later plans can discover it instead of pretending an edit happened only
        # inside a return value.
        derived=AssetRecord(id=out_id,path=a.path,kind=a.kind,license_class=a.license_class,
                            mime_type=a.mime_type,width=a.width,height=a.height,duration=a.duration,
                            version=next_version,metadata=AssetMetadata(tags=list(a.metadata.tags),
                            objects=list(a.metadata.objects),faces=a.metadata.faces,ocr_text=a.metadata.ocr_text,
                            quality_score=a.metadata.quality_score,duplicate_group=a.metadata.duplicate_group,
                            source_uri=a.metadata.source_uri,attribution=a.metadata.attribution),parent_id=a.id)
        self.library.add(derived)
        return out
    def inspect(self,plan): plan.validate(); return {"ok":True,"selected_assets":len(plan.selected_assets),"edit_count":len(plan.edits),"warnings":list(plan.warnings),"digest":plan.digest,"library_assets":len(self.library.assets)}

if __name__=="__main__":
    lib=AssetLibrary([AssetRecord("demo",path="demo.png",kind="user_import",width=1920,height=1080,metadata=AssetMetadata(tags=["poster"],objects=["person"]))])
    p=Stage12Pipeline(lib)
    print(p.inspect(p.plan("make a thumbnail",3,"thumbnail",asset_query="demo",edits=[{"operation":"smart_crop"}])))
