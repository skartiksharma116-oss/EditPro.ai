"""Tiny local human-review environment. Open / after starting it; reviewers score outputs blindly."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import html, json, os
PORT=int(os.getenv('PORT','8102')); RESULTS='human_scores.jsonl'
PAGE='''<!doctype html><meta name="viewport" content="width=device-width"><title>EditPro Stage 3 Human Evaluation</title><h1>Stage 3 Human Evaluation</h1><p>Review a generated edit plan against the source clip. Score 1-5.</p><form method="post"><label>Case <input name="case"></label><br><label>Visual accuracy <input name="visual" type="number" min="1" max="5" required></label><br><label>Speech accuracy <input name="speech" type="number" min="1" max="5" required></label><br><label>Timing <input name="timing" type="number" min="1" max="5" required></label><br><label>Usefulness <input name="usefulness" type="number" min="1" max="5" required></label><br><label>Comments <textarea name="comments"></textarea></label><br><button>Save</button></form>'''
class H(BaseHTTPRequestHandler):
 def do_GET(self):
  self.send_response(200); self.send_header('Content-Type','text/html'); self.end_headers(); self.wfile.write(PAGE.encode())
 def do_POST(self):
  n=int(self.headers.get('Content-Length','0')); from urllib.parse import parse_qs
  d={k:v[0] for k,v in parse_qs(self.rfile.read(n).decode()).items()}; open(RESULTS,'a').write(json.dumps(d)+'\n')
  self.send_response(303); self.send_header('Location','/'); self.end_headers()
 def log_message(self,*a): pass
if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',PORT),H).serve_forever()
