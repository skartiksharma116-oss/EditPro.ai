from stage7_design import Stage7Pipeline

if __name__=='__main__':
    p=Stage7Pipeline()
    r=p.process('Create a cinematic reel cover for my travel video',character_intent='walk and wave')
    print({'ok':r['ok'],'template_id':r['template_id'],'motion':r['motion'].actions if r['motion'] else None,'provider':r['provider']})
