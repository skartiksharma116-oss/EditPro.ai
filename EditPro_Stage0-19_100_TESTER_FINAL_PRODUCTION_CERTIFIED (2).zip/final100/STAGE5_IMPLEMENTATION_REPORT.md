# EditPro.ai Stage 5: AI Tracking & Object Intelligence

## Scope
Stage 5 only: detection/tracking identity, multi-object tracking, prediction, occlusion tolerance, camera-motion-aware contracts, confidence/quality checks, track repair hooks, custom target contracts, multi-model routing, caching-ready deterministic tracking data, resource-aware routing, privacy-aware local preference, and downstream handoff contracts for later stages.

## Alternatives researched
- ByteTrack / BoT-SORT / Deep OC-SORT for general MOT.
- NVIDIA NvSORT / NvDeepSORT / NvDCF for NVIDIA acceleration.
- SAM2 / SAM2-based mask tracking for segmentation-aware tracking.
- CoTracker / TAPIR for point/trajectory tracking.
- Kalman/IoU baseline for low-resource prediction.
NVIDIA DeepStream documents IOU, NvSORT, NvDeepSORT, NvDCF and newer MaskTracker/SAM2-based tracking, including tradeoffs for speed, occlusion robustness and GPU load. These are provider alternatives, not claims that the current host has those runtimes installed.

## Runtime truth
Current sandbox hardware does not expose NVIDIA CUDA, AMD MIGraphX, Intel OpenVINO, Apple CoreML, or external cloud credentials. Stage 5 therefore provides provider contracts and deterministic CPU fallback rather than falsely claiming external execution.

## Testing
Mixed 10,000-cycle stress test covers 12 media profiles and 8 resource/power profiles with randomized object counts, classes, motion, occlusion/misses, tracker thresholds and priorities. Adversarial malformed/NaN inputs are rejected. Existing Stage 2/3/4 suites remain available for regression.
