"""Hardened local CPU renderer for Stage 8 previews and short deterministic exports."""
from __future__ import annotations
from pathlib import Path
import math, subprocess, tempfile, shutil
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageChops, ImageEnhance
from stage8_compositor import Scene, SceneLayer, ParticleSystem, KeyframeEngine, ChromaKeyEngine, MaskEngine

class MediaFrameLoader:
    """Local frame extraction bridge. Uses ffmpeg when available and never uploads media."""
    @staticmethod
    def extract(path, frame, fps, output_size=None):
        path=Path(path)
        if not path.exists(): raise FileNotFoundError(str(path))
        if not shutil.which("ffmpeg"): raise RuntimeError("ffmpeg is required for video frame extraction")
        with tempfile.TemporaryDirectory(prefix="editpro8_frame_") as td:
            out=Path(td)/"frame.png"
            vf=f"select=eq(n\\,{int(frame)})"
            if output_size: vf += f",scale={int(output_size[0])}:{int(output_size[1])}:force_original_aspect_ratio=decrease"
            subprocess.run(["ffmpeg","-y","-loglevel","error","-i",str(path),"-vf",vf,"-frames:v","1",str(out)],check=True)
            if not out.exists(): raise RuntimeError("frame extraction returned no frame")
            return Image.open(out).convert("RGBA").copy()

class RasterCompositor:
    def __init__(self,font_path=None): self.font_path=font_path
    def _font(self,size=42):
        try:
            if self.font_path and Path(self.font_path).exists(): return ImageFont.truetype(self.font_path,size)
            return ImageFont.truetype("DejaVuSans.ttf",size)
        except Exception: return ImageFont.load_default()
    def _color(self,c,alpha=255):
        if isinstance(c,(tuple,list)) and len(c)>=3: return tuple(map(int,c[:3]))+(alpha,)
        c=str(c or "#101318");
        if c.startswith("#") and len(c) in (4,7):
            if len(c)==4: c="#"+"".join(x*2 for x in c[1:])
            return tuple(int(c[i:i+2],16) for i in (1,3,5))+(alpha,)
        return (16,19,24,alpha)
    def _project(self,x,y,z,scene,frame):
        cam=scene.camera; dz=cam.position[2]-z
        if dz<=cam.near: return None
        f=1/math.tan(math.radians(cam.fov)/2); sx=scene.width/2+(x-cam.position[0])*scene.width*.5*f/dz; sy=scene.height/2-(y-cam.position[1])*scene.height*.5*f/dz
        if cam.shake:
            import random; r=random.Random(frame*104729); sx+=(r.random()-.5)*cam.shake; sy+=(r.random()-.5)*cam.shake
        return sx,sy
    def _blend(self,base,layer,mode):
        if mode=="normal": return Image.alpha_composite(base,layer)
        rgb=base.convert("RGB"); lr=layer.convert("RGB")
        if mode=="multiply": mixed=ImageChops.multiply(rgb,lr)
        elif mode=="screen": mixed=ImageChops.screen(rgb,lr)
        elif mode=="add": mixed=ImageChops.add(rgb,lr,scale=1.0,offset=0)
        elif mode=="darken": mixed=ImageChops.darker(rgb,lr)
        elif mode=="lighten": mixed=ImageChops.lighter(rgb,lr)
        else:
            # Pillow has no portable overlay helper across versions, so implement per-channel.
            mixed=Image.new("RGB",rgb.size); bp=rgb.load(); lp=lr.load(); mp=mixed.load()
            for y in range(rgb.height):
                for x in range(rgb.width):
                    out=[]
                    for b,l in zip(bp[x,y],lp[x,y]): out.append(int(2*b*l/255 if b<128 else 255-2*(255-b)*(255-l)/255))
                    mp[x,y]=tuple(out)
        mixed=mixed.convert("RGBA"); mixed.putalpha(layer.getchannel("A")); return Image.alpha_composite(base,mixed)
    def _apply_masks(self,img,layer):
        if not layer.masks: return img
        mask=Image.new("L",img.size,255); px=mask.load()
        for y in range(img.height):
            for x in range(img.width):
                a=1.0
                for m in layer.masks: a*=MaskEngine.alpha_at(m,x,y,img.width,img.height)
                px[x,y]=max(0,min(255,int(a*255)))
        img.putalpha(ImageChops.multiply(img.getchannel("A"),mask)); return img
    def _draw_particles(self,draw,scene,frame,p):
        for x,y,z,a in p.sample(frame,limit=1500):
            if p.kind in {"rain","snow"}: y=(y+frame*p.speed/scene.fps)%1
            elif p.kind in {"smoke","fog"}: y=(y-frame*p.speed*.01)%1
            else: y=(y+frame*p.speed*.002)%1
            px=int(x*scene.width); py=int(y*scene.height); r=max(1,int(p.size*(.5+z)))
            if p.kind in {"fire_like","sparks"}: col=(255,150+int(90*z),40,int(255*p.opacity))
            elif p.kind in {"fog","smoke"}: col=(220,225,230,int(110*p.opacity))
            elif p.kind=="rain": col=(150,190,255,int(180*p.opacity))
            else: col=(220,230,240,int(180*p.opacity))
            draw.ellipse((px-r,py-r,px+r,py+r),fill=col)
    def render_frame(self,scene:Scene,frame:int=0):
        scene.validate()
        if not 0<=frame<scene.duration_frames: raise ValueError("frame outside scene")
        img=Image.new("RGBA",(scene.width,scene.height),(16,19,24,255))
        for layer in scene.layers:
            if not layer.start<=frame<layer.end: continue
            t=KeyframeEngine.transform(layer,frame); a=max(0,min(255,int(t.opacity*255)))
            overlay=Image.new("RGBA",img.size,(0,0,0,0)); d=ImageDraw.Draw(overlay,"RGBA")
            if layer.kind=="background": d.rectangle((0,0,scene.width,scene.height),fill=self._color(layer.properties.get("color","#101318"),a))
            elif layer.kind=="text":
                text=str(layer.properties.get("text") or layer.properties.get("subject", "")); size=int(layer.properties.get("font_size",48));
                d.text((scene.width*.05+t.x,scene.height*.05+t.y),text,font=self._font(size),fill=self._color(layer.properties.get("color","#ffffff"),a),stroke_width=int(layer.properties.get("stroke_width",0)),stroke_fill=self._color(layer.properties.get("stroke_color","#000000"),a))
            elif layer.kind=="shape":
                w=float(layer.properties.get("width",220))*t.scale_x; h=float(layer.properties.get("height",120))*t.scale_y; cx=scene.width*.5+t.x; cy=scene.height*.5+t.y
                box=(cx-w*t.anchor_x,cy-h*t.anchor_y,cx+w*(1-t.anchor_x),cy+h*(1-t.anchor_y)); d.rounded_rectangle(box,radius=float(layer.properties.get("radius",0)),fill=self._color(layer.properties.get("color","#4b8fd8"),a))
            elif layer.kind in {"3d","character"}:
                pos=self._project(t.x/1000,t.y/1000,t.z/1000,scene,frame)
                if pos:
                    cx,cy=pos; size=max(4,min(scene.width,scene.height)*.08*max(.01,t.scale_x)); light=max(.15,min(1.5,sum(l.intensity for l in scene.lights) or .8)); col=(int(70*light),int(150*light),int(230*light),a)
                    pts=[(cx-size,cy-size),(cx+size,cy-size),(cx+size,cy+size),(cx-size,cy+size)]; d.polygon(pts,fill=col,outline=(255,255,255,a)); off=size*.35; d.polygon([(x+off,y-off) for x,y in pts],fill=(max(0,col[0]-20),max(0,col[1]-40),max(0,col[2]-50),a))
                    for p1,p2 in zip(pts,[(x+off,y-off) for x,y in pts]): d.line((p1,p2),fill=(255,255,255,a),width=max(1,int(size/20)))
            elif layer.kind=="effect":
                eff=str(layer.properties.get("effect",""));
                if eff in {"glow","blur","shadow"}:
                    glow=Image.new("RGBA",img.size,(0,0,0,0)); gd=ImageDraw.Draw(glow); gd.ellipse((img.width*.35,img.height*.35,img.width*.65,img.height*.65),fill=(255,255,255,90)); glow=glow.filter(ImageFilter.GaussianBlur(45 if eff=="glow" else 20)); overlay=Image.alpha_composite(overlay,glow)
            elif layer.kind in {"image","video"} and layer.properties.get("path"):
                pth=Path(str(layer.properties["path"]));
                if pth.exists():
                    try:
                        src=Image.open(pth).convert("RGBA") if layer.kind=="image" else MediaFrameLoader.extract(pth,frame,scene.fps,(scene.width,scene.height))
                        src.thumbnail((scene.width,scene.height)); overlay.alpha_composite(src,(int((scene.width-src.width)/2+t.x),int((scene.height-src.height)/2+t.y)))
                        if layer.chroma.enabled:
                            pix=src.load()
                            for yy in range(src.height):
                                for xx in range(src.width):
                                    r,g,b,a0=pix[xx,yy]; aa=int(a0*ChromaKeyEngine.alpha((r,g,b),layer.chroma.hue,layer.chroma.tolerance,layer.chroma.softness)); pix[xx,yy]=(r,g,b,aa)
                            if layer.chroma.spill: src=src.copy()
                    except Exception: pass
            overlay=self._apply_masks(overlay,layer)
            img=self._blend(img,overlay,layer.blend_mode)
        d=ImageDraw.Draw(img,"RGBA")
        for p in scene.particles: self._draw_particles(d,scene,frame,p)
        return img

class Stage8Renderer:
    def __init__(self,font_path=None): self.raster=RasterCompositor(font_path)
    def render_png(self,scene,frame,output):
        output=Path(output); output.parent.mkdir(parents=True,exist_ok=True); self.raster.render_frame(scene,frame).save(output,"PNG"); return output
    def render_preview_video(self,scene,output,max_frames=90):
        output=Path(output); output.parent.mkdir(parents=True,exist_ok=True); frames=min(scene.duration_frames,max_frames)
        if not shutil.which("ffmpeg"): raise RuntimeError("ffmpeg is required for local MP4 preview export")
        with tempfile.TemporaryDirectory(prefix="editpro8_") as td:
            for i in range(frames): self.render_png(scene,i,Path(td)/f"{i:06d}.png")
            cmd=["ffmpeg","-y","-loglevel","error","-framerate",str(scene.fps),"-i",str(Path(td)/"%06d.png"),"-c:v","libx264","-pix_fmt","yuv420p",str(output)]
            subprocess.run(cmd,check=True)
        return output
