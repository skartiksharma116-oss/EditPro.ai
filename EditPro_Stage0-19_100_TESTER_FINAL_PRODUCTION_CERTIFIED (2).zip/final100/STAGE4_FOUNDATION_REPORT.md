# EditPro.ai Stage 4 Foundation

Stage 4 implements the language/text foundation: normalized word/sentence transcript model, multilingual language normalization, speaker segments, filler detection, transcript search, semantic caption segmentation, visual-aware caption placement, deterministic caption styles, confidence-aware animation, caption QA, provider routing, structured natural-language command planning, and a Stage 4 HTTP integration endpoint.

The ASR provider layer is deliberately adapter-based. Local model artifacts are not bundled into the package. Whisper large-v3-turbo and Qwen3-ASR are supported as routing targets when installed, with cloud adapters represented by the generic provider contract.

## Honest validation boundary
- The 10,000x tests validate deterministic contracts, malformed input handling, routing, caption generation, QA, and command planning.
- Real audio smoke uses FFmpeg/FFprobe through the existing Stage 2 speech worker.
- Full neural ASR accuracy is not certified here because model weights and external credentials are not present in the build environment.
- Browser rendering is not certified because the environment lacks an installed Chromium executable.
