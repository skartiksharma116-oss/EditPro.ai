from __future__ import annotations
from dataclasses import dataclass, field
from math import hypot, isfinite
from typing import Any


def _finite01(v: float) -> bool:
    return isfinite(v) and 0.0 <= v <= 1.0

@dataclass(frozen=True)
class Box:
    x: float; y: float; w: float; h: float
    def valid(self):
        return all(isfinite(v) for v in (self.x,self.y,self.w,self.h)) and self.w >= 0 and self.h >= 0
    def iou(self, o: 'Box') -> float:
        if not self.valid() or not o.valid(): return 0.0
        ax2, ay2 = self.x+self.w, self.y+self.h
        bx2, by2 = o.x+o.w, o.y+o.h
        iw = max(0.0, min(ax2,bx2)-max(self.x,o.x)); ih = max(0.0, min(ay2,by2)-max(self.y,o.y))
        inter = iw*ih; union = self.w*self.h + o.w*o.h - inter
        return inter/union if union > 0 else 0.0
    def center(self): return (self.x+self.w/2, self.y+self.h/2)
    def translated(self, dx: float, dy: float) -> 'Box': return Box(self.x+dx,self.y+dy,self.w,self.h)

@dataclass
class Detection:
    box: Box; label: str='object'; confidence: float=1.0; appearance: tuple[float,...]=(); source:str='detector'
    def valid(self):
        return (self.box.valid() and isinstance(self.label,str) and bool(self.label) and _finite01(self.confidence)
                and isinstance(self.appearance,tuple) and len(self.appearance) <= 256
                and all(isfinite(x) for x in self.appearance))
    def normalized_appearance(self):
        if not self.appearance: return ()
        n=hypot(*self.appearance)
        return tuple(x/n for x in self.appearance) if n > 1e-12 else tuple(0.0 for _ in self.appearance)

@dataclass
class Track:
    track_id:int; label:str; box:Box; confidence:float; age:int=1; misses:int=0
    velocity:tuple[float,float]=(0.0,0.0); acceleration:tuple[float,float]=(0.0,0.0)
    state:str='confirmed'; history:list[Box]=field(default_factory=list)
    appearance:tuple[float,...]=(); hits:int=1; id_switches:int=0; shadow_age:int=0
    def predict(self, steps: int=1):
        vx,vy=self.velocity; ax,ay=self.acceleration; s=max(1,int(steps))
        return self.box.translated(vx*s + .5*ax*s*s, vy*s + .5*ay*s*s)

class AdaptivePersistentTracker:
    """Deterministic MOT with motion prediction, appearance re-association, shadow tracks,
    bounded history, occlusion recovery and suspicious-track signalling. It is a safe CPU
    reference implementation; heavyweight providers plug into the same data contract."""
    def __init__(self, iou_threshold=.25, max_misses=8, max_tracks=512, history_limit=64,
                 appearance_weight=.30, max_velocity=10000.0, reid_window=32):
        self.iou_threshold=float(iou_threshold); self.max_misses=int(max_misses); self.max_tracks=int(max_tracks)
        self.history_limit=int(history_limit); self.appearance_weight=float(appearance_weight); self.max_velocity=float(max_velocity); self.reid_window=int(reid_window)
        if not (0 <= self.iou_threshold <= 1) or self.max_misses < 0 or self.max_tracks < 1 or self.history_limit < 2: raise ValueError('invalid tracker configuration')
        if not (0 <= self.appearance_weight <= 1) or not isfinite(self.max_velocity) or self.max_velocity <= 0 or self.reid_window < 0 or self.reid_window > 10000: raise ValueError('invalid tracker configuration')
        self.reset()
    def reset(self): self.tracks={}; self.next_id=1; self.frame=0; self.terminated=[]; self._terminated_cache=[]
    def _appearance(self,a,b):
        if not a or not b or len(a)!=len(b): return 0.0
        return max(-1.0,min(1.0,sum(x*y for x,y in zip(a,b))))
    def _cost(self,t,d):
        iou=t.predict().iou(d.box)
        app=(self._appearance(t.appearance,d.normalized_appearance())+1)/2 if t.appearance and d.appearance else 0.0
        # weighted score; label compatibility is a hard gate
        return (1-self.appearance_weight)*iou + self.appearance_weight*app
    def update(self,detections:list[Detection]):
        if not isinstance(detections,list) or len(detections)>self.max_tracks*2: raise ValueError('invalid detection batch')
        if any(not isinstance(d,Detection) or not d.valid() for d in detections): raise ValueError('malformed detection')
        ds=detections[:self.max_tracks]; self.frame += 1
        pairs=[]
        for tid,t in self.tracks.items():
            for i,d in enumerate(ds):
                if d.label != t.label: continue
                score=self._cost(t,d)
                if score >= self.iou_threshold: pairs.append((score,tid,i))
        pairs.sort(key=lambda x:(-x[0],x[1],x[2])); used_t=set(); used_d=set()
        for score,tid,i in pairs:
            if tid in used_t or i in used_d: continue
            t=self.tracks[tid]; old_v=t.velocity; old=t.box.center(); new=ds[i].box.center()
            nv=(new[0]-old[0],new[1]-old[1])
            if hypot(*nv) > self.max_velocity:
                continue
            t.acceleration=(nv[0]-old_v[0],nv[1]-old_v[1]); t.velocity=nv
            t.box=ds[i].box; t.confidence=ds[i].confidence; t.age+=1; t.hits+=1; t.misses=0; t.shadow_age=0; t.state='confirmed'
            t.appearance=ds[i].normalized_appearance() or t.appearance
            t.history=(t.history+[t.box])[-self.history_limit:]; used_t.add(tid); used_d.add(i)
        for tid,t in list(self.tracks.items()):
            if tid in used_t: continue
            t.misses += 1; t.age += 1; t.shadow_age += 1; t.box=t.predict(); t.confidence=max(0.0,t.confidence*.92)
            t.state='shadow' if t.misses <= self.max_misses else 'lost'
            t.history=(t.history+[t.box])[-self.history_limit:]
            if t.misses > self.max_misses:
                self.terminated.append(t); self._terminated_cache.append((t,self.frame)); del self.tracks[tid]
        # Re-associate recently terminated tracks before creating new IDs. This preserves identity across
        # detector gaps longer than max_misses without resurrecting stale tracks indefinitely.
        for i,d in enumerate(ds):
            if i in used_d or len(self.tracks)>=self.max_tracks: continue
            best=None
            da=d.normalized_appearance()
            for old in self._terminated_cache:
                if self.frame-old[1] > self.reid_window or old[0].label != d.label: continue
                app=self._appearance(old[0].appearance, da) if da and old[0].appearance else 0.0
                pred=old[0].box.translated(old[0].velocity[0], old[0].velocity[1])
                iou=pred.iou(d.box)
                score=.65*iou+.35*((app+1)/2) if da and old[0].appearance else iou
                if best is None or score>best[0]: best=(score,old)
            if best is not None and best[0] >= self.iou_threshold:
                old, terminated_frame=best[1]
                tid=old.track_id
                prev_center=old.box.center()
                old.box=d.box; old.confidence=d.confidence; old.misses=0; old.shadow_age=0; old.state='confirmed'; old.hits+=1
                new_center=d.box.center()
                old.velocity=(new_center[0]-prev_center[0], new_center[1]-prev_center[1])
                old.appearance=da or old.appearance; old.history=(old.history+[d.box])[-self.history_limit:]
                old.id_switches += 0
                self.tracks[tid]=old; used_d.add(i)
                self._terminated_cache=[x for x in self._terminated_cache if x[0].track_id != tid]
        for i,d in enumerate(ds):
            if i in used_d or len(self.tracks)>=self.max_tracks: continue
            tid=self.next_id; self.next_id+=1
            self.tracks[tid]=Track(tid,d.label,d.box,d.confidence,appearance=d.normalized_appearance(),history=[d.box])
        self._terminated_cache=[x for x in self._terminated_cache if self.frame-x[1] <= self.reid_window]
        return list(self.tracks.values())

# Backwards-compatible name used by existing Stage 5 tests.
PersistentTracker = AdaptivePersistentTracker

class TrackingCritic:
    def score(self, tracks:list[Track]):
        if not isinstance(tracks,list): raise ValueError('tracks must be list')
        if not tracks: return {'score':1.0,'issues':[],'metrics':{'tracks':0}}
        issues=[]; jitter=0.0; speed_spikes=0; shadows=0; low=0
        for t in tracks:
            if not isinstance(t,Track) or not t.box.valid(): issues.append('malformed_track'); continue
            if t.misses>2: issues.append('prolonged_occlusion')
            if t.confidence<.35: low += 1
            if t.state=='shadow': shadows += 1
            if len(t.history)>=3:
                a=t.history[-3].center(); b=t.history[-2].center(); c=t.history[-1].center()
                s1=hypot(b[0]-a[0],b[1]-a[1]); s2=hypot(c[0]-b[0],c[1]-b[1]); jitter += abs(s2-s1)
                if s2 > 10000: speed_spikes += 1
        if low: issues.append('low_confidence')
        if shadows: issues.append('shadow_tracks')
        if speed_spikes: issues.append('velocity_spike')
        score=max(0.0,min(1.0,1-len(set(issues))*.07-min(.25,jitter/max(1,len(tracks))*0.005)))
        return {'score':score,'issues':sorted(set(issues)),'metrics':{'tracks':len(tracks),'low_confidence':low,'shadow_tracks':shadows,'velocity_spikes':speed_spikes,'jitter':jitter}}

class TrackRepair:
    """Bounded repair policy: downgrade suspicious tracks, re-run with a safer gate, and never invent an ID."""
    def repair(self, tracker: AdaptivePersistentTracker, detections, max_attempts=2):
        if max_attempts < 0 or max_attempts > 4: raise ValueError('invalid repair budget')
        before={tid:t.box for tid,t in tracker.tracks.items()}
        attempts=0
        for _ in range(max_attempts):
            attempts += 1
            suspicious=[t for t in tracker.tracks.values() if t.state=='shadow' or t.confidence<.35]
            if not suspicious: break
            tracker.update(detections)
        after={tid:t.box for tid,t in tracker.tracks.items()}
        return {'attempts':attempts,'repaired':sum(1 for tid,b in after.items() if tid in before and after[tid]!=before[tid]),'active_tracks':len(after)}
