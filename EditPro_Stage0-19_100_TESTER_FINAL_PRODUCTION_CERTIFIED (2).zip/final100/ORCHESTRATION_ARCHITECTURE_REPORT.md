# EditPro.ai Orchestration Architecture - Stage 4 expansion

## What was added

A provider-neutral orchestration layer now sits above the Stage 2/3/4 foundations. It exposes 40 capability domains backed by 55 provider/engine contracts. The router considers runtime power, privacy, quality, speed and cost, then selects the strongest compatible provider. If none is actually available, the job is explicitly marked `deferred` rather than pretending an unavailable model ran.

### Core orchestration components

- Capability Registry: one inventory for specialist workers and alternatives.
- Resource Profiles: CPU, NVIDIA/CUDA/TensorRT, AMD/MIGraphX, Intel/OpenVINO, Apple/CoreML, WebGPU and cloud profiles.
- Dependency-aware Job Graph: tasks execute only after prerequisites finish.
- Provider Router: quality/speed/cost/privacy-aware selection.
- Fallback contracts: every provider records alternatives.
- Deterministic fingerprints: identical payloads produce identical fingerprints.
- Provenance audit: every routed/deferred job is recorded.
- Bounded task count and resource limits: hostile requests cannot create unbounded graphs.
- Graceful unavailable-provider behavior: deferred, never falsely successful.
- Stage 4 API integration: `POST /api/orchestrate`.

## Capability inventory

The registry currently covers 40 domains:

speech.asr, speech.diarization, translation, vision.detection, vision.segmentation, vision.tracking, vision.matting, vision.depth, vision.pose, vision.face, video.generation, video.editing, image.generation, image.editing, image.upscale, video.interpolation, audio.restoration, audio.separation, audio.voice, audio.music, meme.intelligence, color.management, motion.graphics, vfx, render.gpu, render.cpu, search.project, memory.project, critic.ai, compare.ai, infrastructure.cloud, device.optimization, collaboration, publishing, accessibility, security, command.director, timeline, asset.library, thumbnail.metadata.

## Important limitation

These are **provider contracts and orchestration paths**, not a claim that every third-party neural model is installed in this sandbox. External model weights, API credentials, GPUs and vendor services are only considered available when the runtime actually exposes the required capability.

The current sandbox does not have commercial cloud credentials or all vendor model runtimes/weights, so cloud/generative providers remain safely deferred here. This is intentional.

## Test strategy

The stress suite varies:

- video families: H.264, HEVC, AV1, VP9, ProRes, 10-bit, HDR, VFR, 4K/8K, portrait, square, speech, music, silent, noisy, long/short form and high-frame-rate profiles;
- power profiles: CPU-low, CPU-high, NVIDIA/CUDA/TensorRT, AMD/MIGraphX, Intel/OpenVINO, Apple/CoreML, WebGPU and cloud;
- priorities: quality, speed, cost, privacy;
- dependency graphs and graph sizes;
- payload sizes and frame counts;
- forced provider failures;
- local-only privacy routing;
- malformed/adversarial values.

A 10,000-case mixed matrix and additional 10,000-case hardening/integrity suites passed in the current environment.

## External ecosystem evidence

OpenCut's current architecture is moving toward an editor API, plugin-first architecture, headless rendering and an MCP server, reinforcing the value of an explicit orchestration/plugin boundary. citeturn0search0

FFmpeg's current documentation exposes hardware acceleration paths including VAAPI, QSV and VideoToolbox, while also warning that runtime availability depends on suitable hardware and drivers. citeturn0search8

## Honest status

This build is complete for the implemented orchestration scope and the tested sandbox. It is not a proof of zero bugs on every possible machine, model version, driver, cloud provider or future video format.
