# EditPro.ai Stage 2 Production Environment

This package creates a local production-like lab instead of pretending unavailable infrastructure exists.

## Environments
- Real FFmpeg media inspection and audio signal analysis.
- OpenCV visual sampling.
- Optional real HTTP speech provider via `SPEECH_API_URL` + `SPEECH_API_KEY`.
- Optional real cloud AI worker via `CLOUD_AI_URL` + `CLOUD_AI_KEY`.
- Local deterministic cloud and speech services for repeatable integration tests.
- CPU/CUDA runtime detection.
- Human evaluation web form for blind review and saved scores.
- Multiple codecs/containers, portrait/square/landscape, 24/25/30/60 FPS, and ProRes/HEVC/VP9/AV1/H.264 fixtures.

## Run
`./scripts/run_lab.sh`

For local cloud/speech integration, start the two mock services and set:
`CLOUD_AI_URL=http://127.0.0.1:8110`
`SPEECH_API_URL=http://127.0.0.1:8111`

## Important boundary
A local lab can validate the contracts, failure handling, CPU execution, media codecs, and repeatability. It cannot honestly prove performance on a physical iPhone/Android fleet, a specific commercial GPU, or a real third-party cloud account without access to those resources. The package therefore exposes those exact interfaces for deployment validation rather than fabricating results.
