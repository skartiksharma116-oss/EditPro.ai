import random, string, time, math
from stage18_scale_hardening import Stage18ScaleHardening

def text(r,n=120): return ''.join(r.choice(string.printable) for _ in range(n))

def test_registry_and_profile():
    s=Stage18ScaleHardening(); assert len(s.capabilities)>=130 and len(s.capabilities)==len(set(s.capabilities))
    p=s.profile({'ram_mb':8192,'vram_mb':4096,'cpu_cores':8},{'clip_count':25000,'duration_s':90000})
    assert p['project_mode']=='streaming' and p['gpu_available']

def test_plan_deterministic_and_passes():
    s=Stage18ScaleHardening(); a=s.plan('render huge 8k project',{'ram_mb':16384,'vram_mb':8192,'cpu_cores':16},{'clip_count':50000,'duration_s':172800},{'final_feature_digest':'abc'})
    b=s.plan('render huge 8k project',{'ram_mb':16384,'vram_mb':8192,'cpu_cores':16},{'clip_count':50000,'duration_s':172800},{'final_feature_digest':'abc'})
    assert a['fingerprint']==b['fingerprint'] and s.qa(a)['status']=='PASS'

def test_hostile_inputs():
    s=Stage18ScaleHardening(); p=s.plan('\x00<script>DROP TABLE',{'ram_mb':'bad','vram_mb':float('inf'),'cpu_cores':-9},{'clip_count':'x','duration_s':float('nan')},{}); assert s.qa(p)['status']=='PASS'

def test_tamper_rejected():
    s=Stage18ScaleHardening(); p=s.plan('x'); p['checkpointed']=False; assert s.qa(p)['status']=='REJECT'

def test_20k_fuzz():
    s=Stage18ScaleHardening(); r=random.Random(18018); t=time.time()
    for _ in range(20000):
        h={'ram_mb':r.choice([0,256,1024,4096,16384,'bad',float('nan')]),'vram_mb':r.choice([0,2048,8192,'x',float('inf')]),'cpu_cores':r.choice([1,2,8,64,-1,'bad']),}
        p={'clip_count':r.choice([0,1,100,10000,100000,'x']),'duration_s':r.choice([0,60,3600,100000,'bad',float('nan')])}
        q=s.qa(s.plan(text(r,80),h,p,{'fingerprint':text(r,20)})); assert q['status']=='PASS'
    print('20k stage18 fuzz:',round(time.time()-t,2),'s')
