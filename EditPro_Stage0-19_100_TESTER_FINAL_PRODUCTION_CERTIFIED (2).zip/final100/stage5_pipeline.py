from dataclasses import dataclass
from stage5_tracking import Detection,AdaptivePersistentTracker,TrackingCritic,TrackRepair
from stage5_registry import TrackingProviderRegistry
@dataclass
class TrackingPipeline:
 profile: object
 def __post_init__(self): self.registry=TrackingProviderRegistry(); self.tracker=AdaptivePersistentTracker(); self.critic=TrackingCritic(); self.repair=TrackRepair()
 def process(self,frames,priority='quality',reset=True,privacy='balanced',difficulty='normal',reid_required=False,segmentation_required=False):
  if not isinstance(frames,list) or len(frames)>10000: raise ValueError('invalid frame list')
  if reset:self.tracker.reset()
  provider=self.registry.route('mot',self.profile,priority,difficulty,reid_required,segmentation_required)
  timeline=[]
  for ds in frames:
   tracks=self.tracker.update(ds)
   timeline.append([{'track_id':t.track_id,'label':t.label,'box':(t.box.x,t.box.y,t.box.w,t.box.h),'confidence':t.confidence,'state':t.state,'misses':t.misses,'velocity':t.velocity} for t in tracks])
  critic=self.critic.score(list(self.tracker.tracks.values()))
  repair=None
  if critic['score'] < .80 and frames:
   repair=self.repair.repair(self.tracker,frames[-1],max_attempts=2)
   critic=self.critic.score(list(self.tracker.tracks.values()))
  return {'ok':True,'provider':provider.name,'frames':timeline,'critic':critic,'repair':repair,'track_count':len(self.tracker.tracks),'terminated_count':len(self.tracker.terminated)}
