import copy, random
from stage16_creative_brain import Stage16CreativeBrain, Stage16CapabilityRegistry, digest


def sample():
    media={"duration":60,"width":1920,"height":1080,"fps":30,"target_format":"reel","transcript":[1]}
    visual=[{"label":"car"},{"label":"person"}]
    speech={"transcript":[{"start":0,"end":1,"text":"hello","speaker":"A"}],"beats":[1,2,3]}
    return media,visual,speech


def test_registry_is_broad_and_unique():
    r=Stage16CapabilityRegistry()
    assert len(r.capabilities) >= 180
    assert len(r.capabilities)==len(set(r.capabilities))


def test_plan_is_deterministic_and_editable():
    m,v,s=sample(); b=Stage16CreativeBrain()
    a=b.plan("make a premium cinematic reel with music and reference style",m,v,s,{"fingerprint":"x"})
    c=b.plan("make a premium cinematic reel with music and reference style",m,v,s,{"fingerprint":"x"})
    assert a==c and a["editable"] and a["non_destructive"] and a["reversible"]
    assert b.qa(a)["ok"]


def test_locks_are_preserved():
    m,v,s=sample(); p=Stage16CreativeBrain().plan("make a reel",m,v,s,locks=["face:main","audio:voice"])
    assert "face:main" in p["protected_targets"] and "audio:voice" in p["protected_targets"]


def test_bad_plan_is_rejected():
    b=Stage16CreativeBrain(); p=b.plan("make a reel",*sample(),None)
    p["editable"]=False
    assert b.qa(p)["status"] in {"REPAIR","REJECT"}


def test_operation_ids_stable_under_copy():
    m,v,s=sample(); b=Stage16CreativeBrain(); p=b.plan("make a cinematic reel",m,v,s)
    q=copy.deepcopy(p)
    assert [x["id"] for x in p["operations"]]==[x["id"] for x in q["operations"]]


def test_hostile_metadata_does_not_crash():
    b=Stage16CreativeBrain();
    for _ in range(2000):
        m={"duration":random.choice([0,1,60,"bad",None,float('nan')]),"width":1920,"height":1080}
        p=b.plan("make a reel",m,[],{})
        assert isinstance(p["fingerprint"],str) and b.qa(p)["status"] in {"PASS","REPAIR","REJECT"}


def test_large_command_fuzz():
    b=Stage16CreativeBrain(); m,v,s=sample()
    for i in range(3000):
        cmd="make a " + " ".join(random.choice(["premium","reel","cinematic","music","meme","reference","generate","remove","storyboard","safe","editable"]) for _ in range(i%25))
        p=b.plan(cmd,m,v,s)
        assert len(p["fingerprint"])==64


def test_fingerprint_changes_when_plan_changes():
    m,v,s=sample(); b=Stage16CreativeBrain(); a=b.plan("make a reel",m,v,s); c=b.plan("make a cinematic reel",m,v,s)
    assert a["fingerprint"] != c["fingerprint"]


def test_handoff_contract():
    b=Stage16CreativeBrain(); p=b.plan("make a premium reel",*sample()); h=b.handoff(p)
    assert h["creative_digest"]==p["fingerprint"] and h["editable"] and h["reversible"]
