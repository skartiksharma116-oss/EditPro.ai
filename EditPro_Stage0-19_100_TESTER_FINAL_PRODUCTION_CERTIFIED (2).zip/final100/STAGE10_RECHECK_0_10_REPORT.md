# EditPro.ai Stage 0-10 Recheck / Hardening Report

## Scope
Full Stage 0-10 integration recheck, with emphasis on Stage 10 audio coordination and cross-stage boundaries.

## Bugs found and fixed
1. Shared transcript boundary accepted out-of-order ASR segments. Stage 4 requires chronological input. The Stage 0-10 facade now sorts transcript timings deterministically and trims overlapping segments at the integration boundary.
2. AudioSource validation allowed an end time of zero when start was positive. Validation now rejects end < start consistently.
3. Audio source ranges could extend beyond the project duration. Stage 10 now clamps source ranges to the plan duration.
4. Audio ducking values were unconstrained. Stage 10 now bounds ducking to a safe -60 dB..0 dB range.
5. Audio probe could report malformed/zero-duration streams as healthy. WAV and ffprobe paths now require positive duration, sample rate and channel count.
6. AudioPlan accepted unreasonable sample rates/channel counts. Validation now enforces 8 kHz..192 kHz and 1..8 channels.

## Completed validation
- Stage 10 stress suite: 21,008 PASS / 0 FAIL
- Stage 0-8 signal integration regression: 10,000 PASS / 0 FAIL
- Stage 0-10 signal integration stress: 10,000 PASS / 0 FAIL
- Stage 9 ultimate: 80,004 PASS / 0 FAIL (completed before the recheck timeout window)
- Stage 9 final audit core: 15,004 PASS / 0 FAIL (completed before its later long-running section)
- Python compileall: PASS
- Real WAV probe and FFmpeg loudness render: PASS in Stage 10 suite

## Environment limitation
Some legacy ultra-audits are intentionally long-running in this constrained execution environment. A timeout is NOT counted as a pass. Completed checks above are reported separately from timed-out campaigns.

## Freeze decision
Stage 0-10 implementation is hardened for the defined scope. No claim of mathematical zero-future-bug guarantee is made. Stage 10 should remain frozen while Stage 11 is designed.
