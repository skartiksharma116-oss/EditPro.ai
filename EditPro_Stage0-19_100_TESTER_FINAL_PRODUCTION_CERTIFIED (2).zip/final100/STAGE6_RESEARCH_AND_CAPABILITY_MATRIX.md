# Stage 6 research and capability matrix

## Research anchors checked
- Adobe Premiere 2026: AI Object Mask, mask refinement, generative media, Generative Extend.
- Meta SAM 3.1 (2026): promptable concept segmentation and multi-object video tracking with multiplexing.
- Blackmagic Fusion/DaVinci: planar tracking, keying, paint/clone and VFX workflows.
- NVIDIA ecosystem: tracker/provider patterns and hardware-aware inference routing.

## Stage 6 capability list
1. AI VFX Director and natural-language effect planning
2. Stage-5 object-aware VFX binding
3. Promptable masks / roto foundation
4. Edge refinement: feather, expansion, inversion, opacity
5. Multi-mask composition
6. Green/blue/color/luma key contracts
7. Spill suppression
8. Matte refinement
9. Object removal
10. Temporal paint/clone contracts
11. Screen replacement
12. Sign/poster/billboard replacement
13. Perspective/homography surface transforms
14. Glow/neon/outline
15. Fire/smoke/fog/dust
16. Rain/snow/atmosphere
17. Sparks/lightning/energy
18. Shockwave/particles/light streaks
19. Motion trails/directional blur/flash/camera shake contracts
20. Relight/light-wrap/scene-light integration contracts
21. Background blur/selective effects
22. Temporal consistency critic
23. Flicker/drift/leakage detection
24. Bounded VFX repair
25. Provider tournament/routing contracts
26. CPU-safe procedural fallback
27. Hardware-aware provider selection
28. Cache identity and non-destructive VFX packets
29. Strict validation against malformed/non-finite data
30. Future-stage handoff via VFXPacket
31. Generated-media provenance flagging
32. Quality/confidence scoring

## Capabilities with no heavy model available in the current sandbox
These are not left without alternatives. Each has a deterministic fallback:

- Generative object removal/video inpainting -> temporal patch/clone/procedural reconstruction contract.
- AI matting/hair segmentation -> classical keying + mask refinement fallback.
- Promptable segmentation -> Stage-5 track + polygon mask fallback.
- Generative fire/smoke/energy -> procedural effect primitives.
- AI relighting -> masked exposure/color/light-wrap approximation.
- AI surface replacement -> homography/corner-pin transform.
- AI depth-aware effects -> Stage-3 depth contract when available, otherwise 2D mask/track fallback.
- Cloud generative VFX -> local deterministic plan; cloud worker is optional and isolated.

## External high-end alternatives registered
- SAM 3.1 / SAM 2.1 for segmentation/tracking
- model-based matting families
- NVIDIA TensorRT
- Intel OpenVINO
- Apple Core ML
- WebGPU
- cloud generative VFX providers
- FFmpeg/OpenCV CPU primitives

## Explicitly not Stage 6
Character generation/animation, full compositing/layout/3D scene assembly, cinematography director, audio studio, meme engine, full image/asset studio, global style engine, and the full cross-stage multi-AI worker system remain later stages.
