# EditPro.ai Stage 4 - Strongest Adaptive Creative Layer

This upgrade sits on top of the existing Stage 4 orchestration architecture. It adds a bounded meta-orchestrator rather than replacing the provider registry.

## New intelligence

- Intent parser: turns natural-language goals into bounded creative objectives.
- Specialist council: creates cross-modal dependencies and handoffs.
- Provider tournament: compares multiple candidate workers using quality, reliability, latency, privacy and intent.
- Self-critic: checks contract-only status, dependency failures, resource pressure and intent preservation.
- Repair engine: performs bounded alternative-provider repair passes.
- Outcome optimizer: scores the complete job set rather than isolated workers.
- Creative project memory: stores explicit project facts and fingerprints them deterministically.
- Learning book: accepts only explicitly marked real execution observations, preventing fake benchmarks.
- Graceful degradation: deferred/unavailable workers remain explicit and do not become false successes.
- API integration: `/api/orchestrate` now uses the adaptive creative engine.

## Guarantees and limits

The layer is deterministic for the same inputs where provider execution is contract-only. It never claims external AI, cloud credentials, model weights or unavailable hardware were actually executed.

The test suite includes 10,000 mixed cycles across media profiles, codecs, resolutions, frame rates, durations, speech/music states, resource profiles and commands, plus malformed/boundary cases.
