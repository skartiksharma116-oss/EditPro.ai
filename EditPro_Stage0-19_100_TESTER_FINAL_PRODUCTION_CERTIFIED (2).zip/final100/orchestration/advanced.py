"""Advanced EditPro.ai orchestration layer.

This layer turns the provider registry into an adaptive creative-worker system:
- adaptive routing using media + resource + privacy + learned local benchmark data
- parallel specialist proposals
- deterministic result comparison and self-critique
- bounded repair/fallback loops
- progressive chunk planning for long media
- project semantic memory (local, deterministic)
- provenance and reproducibility

External model execution is represented honestly: a worker may return a contract-only
proposal when its runtime/model weights are unavailable. No unavailable provider is
reported as executed.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib, json, math, time
from typing import Any, Callable


def _finite(x, default=0.0):
    try:
        x=float(x)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, _finite(x)))


def stable_hash(obj: Any) -> str:
    raw=json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()
    return hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class MediaProfile:
    codec: str='h264'
    width: int=1920
    height: int=1080
    fps: float=30.0
    duration_s: float=30.0
    bit_depth: int=8
    hdr: bool=False
    vfr: bool=False
    audio: bool=True
    speech: bool=True
    music: bool=False
    noisy_audio: bool=False
    portrait: bool=False
    resolution_class: str='1080p'

    @classmethod
    def from_dict(cls, d: dict[str, Any]):
        if not isinstance(d, dict): raise ValueError('media profile must be object')
        width=int(d.get('width',1920)); height=int(d.get('height',1080)); fps=_finite(d.get('fps',30),30)
        dur=_finite(d.get('duration_s',30),30)
        if width<1 or height<1 or fps<=0 or dur<=0: raise ValueError('invalid media profile')
        return cls(codec=str(d.get('codec','h264')).lower(), width=width, height=height,
                   fps=fps, duration_s=dur, bit_depth=max(1,int(d.get('bit_depth',8))),
                   hdr=bool(d.get('hdr',False)), vfr=bool(d.get('vfr',False)), audio=bool(d.get('audio',True)),
                   speech=bool(d.get('speech',True)), music=bool(d.get('music',False)),
                   noisy_audio=bool(d.get('noisy_audio',False)), portrait=bool(d.get('portrait',height>width)),
                   resolution_class=str(d.get('resolution_class','1080p')))


@dataclass(frozen=True)
class WorkerSpec:
    name: str
    capability: str
    quality: float
    speed: float
    cost: float
    privacy: float
    resource_tags: tuple[str,...]=()
    specialties: tuple[str,...]=()
    alternatives: tuple[str,...]=()
    handler: str='contract'
    max_parallel: int=2


@dataclass
class WorkerResult:
    worker: str
    capability: str
    status: str
    score: float
    contract_only: bool
    output: dict[str,Any]=field(default_factory=dict)
    issues: list[str]=field(default_factory=list)
    elapsed_ms: float=0.0
    fingerprint: str=''


@dataclass
class BenchmarkRecord:
    worker: str
    media_class: str
    resource: str
    quality: float
    speed: float
    failures: int=0
    samples: int=0


class BenchmarkBook:
    """Small deterministic local benchmark book. It never invents real execution metrics."""
    def __init__(self): self.records: dict[str,BenchmarkRecord]={}
    def key(self,w,m,r): return f'{w}|{m}|{r}'
    def observe(self, worker, media_class, resource, quality, speed, failed=False):
        k=self.key(worker,media_class,resource); rec=self.records.get(k)
        if rec is None: rec=BenchmarkRecord(worker,media_class,resource,0,0); self.records[k]=rec
        n=rec.samples; rec.quality=(rec.quality*n+_clamp(quality))/(n+1); rec.speed=(rec.speed*n+_clamp(speed))/(n+1)
        rec.samples=n+1; rec.failures += int(failed)
    def factor(self, worker, media_class, resource):
        r=self.records.get(self.key(worker,media_class,resource))
        if not r or r.samples<1: return None
        reliability=max(0.0,1.0-r.failures/max(1,r.samples)); return {'quality':r.quality,'speed':r.speed,'reliability':reliability,'samples':r.samples}


class ProjectMemory:
    """Local semantic project memory using deterministic tags/fingerprints."""
    def __init__(self): self.entries: dict[str,dict[str,Any]]={}
    def remember(self, project_id, facts: dict[str,Any]):
        if not isinstance(project_id,str) or not project_id or not isinstance(facts,dict): raise ValueError('invalid memory input')
        old=self.entries.get(project_id,{})
        merged={**old, **facts, 'updated_at':time.time()}
        self.entries[project_id]=merged
        return dict(merged)
    def recall(self, project_id): return dict(self.entries.get(project_id,{}))
    def fingerprint(self, project_id): return stable_hash(self.recall(project_id))


class AdaptiveRouter:
    def __init__(self, workers: list[WorkerSpec], benchmark: BenchmarkBook|None=None):
        self.workers=workers; self.benchmark=benchmark or BenchmarkBook()
    @staticmethod
    def media_class(m: MediaProfile):
        return f'{m.codec}-{m.resolution_class}-{"hdr" if m.hdr else "sdr"}-{"speech" if m.speech else "silent"}'
    def rank(self, capability, media: MediaProfile, resource: str, priority='quality', privacy='balanced', context=None):
        context=context or {}; out=[]; mc=self.media_class(media)
        for w in self.workers:
            if w.capability!=capability: continue
            if privacy=='local' and w.privacy<.8: continue
            if w.resource_tags and resource not in w.resource_tags and 'cpu' not in w.resource_tags: continue
            bench=self.benchmark.factor(w.name,mc,resource)
            q=bench['quality'] if bench else w.quality; s=bench['speed'] if bench else w.speed
            rel=bench['reliability'] if bench else 1.0
            specialty=0.0
            for tag in w.specialties:
                if bool(context.get(tag)): specialty += .05
            if media.hdr and 'hdr' in w.specialties: specialty += .08
            if media.noisy_audio and 'noise' in w.specialties: specialty += .08
            if media.portrait and 'portrait' in w.specialties: specialty += .05
            if priority=='speed': base=s*.55+q*.2+(1-w.cost)*.1+w.privacy*.05+rel*.1
            elif priority=='cost': base=(1-w.cost)*.45+q*.25+s*.1+w.privacy*.1+rel*.1
            else: base=q*.55+s*.12+(1-w.cost)*.05+w.privacy*.08+rel*.2
            out.append((base+specialty,w))
        return [w for _,w in sorted(out,key=lambda x:(x[0],x[1].name),reverse=True)]


class CreativeDirector:
    """Converts user intent + media facts into a bounded specialist work plan."""
    def plan(self, command: str|None, media: MediaProfile, memory: dict[str,Any]|None=None):
        c=str(command or '').strip().lower(); tasks=[]
        if media.speech: tasks += [('speech.asr',1),('speech.diarization',2)]
        if media.speech and (media.noisy_audio or 'clean audio' in c): tasks.append(('audio.restoration',3))
        tasks += [('vision.detection',1),('vision.tracking',2),('vision.depth',3)]
        if 'background' in c or 'remove person' in c: tasks.append(('vision.segmentation',3))
        if 'cinematic' in c or 'reframe' in c or 'follow' in c: tasks.append(('vision.segmentation',3))
        if 'caption' in c or media.speech: tasks.append(('translation',4) if any(x in c for x in ('translate','hindi','english','bilingual')) else ('publishing',5))
        if any(x in c for x in ('funny','meme','memes')): tasks.append(('meme.intelligence',5))
        if any(x in c for x in ('music','beat','sync')): tasks.append(('audio.music',4))
        if any(x in c for x in ('color','cinematic','grade')): tasks.append(('color.management',4))
        if any(x in c for x in ('vfx','effect','fire','smoke')): tasks.append(('vfx',5))
        if any(x in c for x in ('thumbnail','title','hashtags')): tasks.append(('thumbnail.metadata',5))
        # Remove duplicates while retaining minimum priority.
        d={}
        for cap,p in tasks: d[cap]=min(p,d.get(cap,p))
        return [{'capability':cap,'priority':p} for cap,p in sorted(d.items(),key=lambda x:(x[1],x[0]))]


class ResultComparator:
    def compare(self, results: list[WorkerResult], requested_quality='quality'):
        if not results: raise ValueError('no results')
        def key(r):
            issue_penalty=.12*len(r.issues); contract_penalty=.02 if r.contract_only else 0
            return _clamp(r.score-issue_penalty-contract_penalty)
        ordered=sorted(results,key=lambda r:(key(r),r.worker),reverse=True)
        best=ordered[0]
        return {'winner':best.worker,'score':key(best),'ranked':[{'worker':r.worker,'score':key(r),'status':r.status} for r in ordered]}


class SelfCritic:
    def review(self, result: WorkerResult, media: MediaProfile, command: str|None):
        issues=list(result.issues)
        if result.status not in ('success','contract'): issues.append('worker-not-successful')
        if media.hdr and result.capability=='color.management' and result.contract_only: issues.append('hdr-runtime-not-executed')
        if command and result.contract_only: issues.append('runtime-provider-unavailable')
        score=_clamp(result.score - .08*len(issues))
        return {'score':score,'issues':sorted(set(issues)),'needs_repair':bool(issues and score<.78)}


class RecoveryEngine:
    def __init__(self, router: AdaptiveRouter): self.router=router
    def candidates(self, capability, media, resource, privacy, priority):
        return self.router.rank(capability,media,resource,priority,privacy)


class ProgressivePlanner:
    def chunks(self, duration_s, chunk_s=120.0, overlap_s=2.0, max_chunks=4096):
        d=_finite(duration_s)
        if d<=0: raise ValueError('duration must be positive')
        chunk=max(1.0,_finite(chunk_s,120)); overlap=max(0.0,min(chunk/2,_finite(overlap_s,2)))
        out=[]; start=0.0
        while start<d and len(out)<max_chunks:
            end=min(d,start+chunk); out.append((round(start,6),round(end,6)))
            if end>=d: break
            start=end-overlap
        if len(out)>=max_chunks and out[-1][1]<d: raise ValueError('chunk limit exceeded')
        return out


class AdvancedOrchestrator:
    """High-level orchestration using the existing CapabilityRegistry as its provider source."""
    def __init__(self, registry=None, profile=None, benchmark=None):
        from .core import CapabilityRegistry, ResourceProfile
        self.registry=registry or CapabilityRegistry(); self.profile=profile or ResourceProfile('cpu-default')
        self.benchmark=benchmark or BenchmarkBook(); self.memory=ProjectMemory(); self.director=CreativeDirector(); self.comparator=ResultComparator(); self.critic=SelfCritic()
        self.workers=self._workers_from_registry(); self.router=AdaptiveRouter(self.workers,self.benchmark); self.recovery=RecoveryEngine(self.router); self.progressive=ProgressivePlanner()
    def _workers_from_registry(self):
        return [WorkerSpec(p.name,p.capability,p.quality,p.speed,p.cost,p.privacy,tuple(p.requires),(),tuple(p.alternatives),p.handler) for p in self.registry.providers]
    def _resource_name(self): return self.profile.name
    def _media(self, request): return MediaProfile.from_dict(request.get('media',{}))
    def _available(self, provider):
        caps=self.profile.capabilities()
        # The base registry's requirements are a resource contract. Actual neural runtimes
        # remain contract-only unless explicitly marked by the caller as installed.
        p=next(x for x in self.registry.providers if x.name==provider)
        return p.enabled and all(r in caps for r in p.requires)
    def _run_worker(self,w,payload,media,command):
        t=time.perf_counter(); available=self._available(w.name)
        # Caller can explicitly advertise an installed model runtime for real execution.
        installed=set(payload.get('_installed_providers',())) if isinstance(payload,dict) else set()
        actual=w.name in installed
        issues=[]
        if not available: return WorkerResult(w.name,w.capability,'deferred',0,False,{'reason':'resource-incompatible'},['resource-incompatible'],(time.perf_counter()-t)*1000,stable_hash(payload))
        contract_only=not actual
        if contract_only: issues.append('provider-runtime-not-installed')
        score=w.quality
        if media.noisy_audio and 'audio' in w.capability: score += .02
        if media.hdr and w.capability=='color.management': score += .02
        return WorkerResult(w.name,w.capability,'contract' if contract_only else 'success',_clamp(score),contract_only,{'proposal':f'{w.capability}:{w.name}','input_fingerprint':stable_hash(payload)},issues,(time.perf_counter()-t)*1000,stable_hash(payload))
    def execute(self, request):
        if not isinstance(request,dict): raise ValueError('request must be object')
        media=self._media(request); resource=self._resource_name(); privacy=str(request.get('privacy','balanced')); priority=str(request.get('priority','quality')); command=request.get('command')
        project_id=str(request.get('project_id','default')); mem=self.memory.recall(project_id)
        if request.get('remember') is not None: mem=self.memory.remember(project_id,request.get('remember'))
        tasks=request.get('tasks') or self.director.plan(command,media,mem)
        if not isinstance(tasks,list) or len(tasks)>64: raise ValueError('invalid task count')
        chunk_plan=self.progressive.chunks(media.duration_s,request.get('chunk_s',120),request.get('overlap_s',2))
        final=[]; audit=[]
        for task in tasks:
            cap=str(task.get('capability','')); candidates=self.recovery.candidates(cap,media,resource,privacy,priority)
            if not candidates: final.append({'capability':cap,'status':'deferred','provider':None,'score':0.0,'issues':['no-compatible-provider'],'contract_only':False,'repaired':False}); continue
            # Parallel proposals from top specialists, bounded to three.
            top=candidates[:min(3,int(request.get('max_competitors',3)))]
            payload=dict(task.get('payload',{})) if isinstance(task.get('payload',{}),dict) else {}
            payload['media_fingerprint']=stable_hash(asdict(media)); payload['chunk_count']=len(chunk_plan)
            results=[]
            with ThreadPoolExecutor(max_workers=len(top)) as ex:
                futures=[ex.submit(self._run_worker,w,payload,media,command) for w in top]
                for f in as_completed(futures): results.append(f.result())
            usable=[r for r in results if r.status in ('success','contract')]
            if not usable:
                final.append({'capability':cap,'status':'deferred','provider':None,'score':0.0,'issues':['all-candidates-unavailable'],'contract_only':False,'repaired':False}); continue
            comparison=self.comparator.compare(usable,priority); winner=next(r for r in usable if r.worker==comparison['winner'])
            critique=self.critic.review(winner,media,command)
            # One bounded repair pass: choose next provider if winner is weak and a backup exists.
            repaired=False
            if critique['needs_repair'] and len(candidates)>len(top):
                backup=candidates[len(top)]
                rr=self._run_worker(backup,payload,media,command); rc=self.critic.review(rr,media,command)
                if rc['score']>critique['score']:
                    winner,critique=rr,rc; repaired=True
            final.append({'capability':cap,'provider':winner.worker,'status':winner.status,'score':critique['score'],'issues':critique['issues'],'contract_only':winner.contract_only,'repaired':repaired,'comparison':comparison})
            audit.append({'capability':cap,'winner':winner.worker,'candidates':[r.worker for r in usable],'repair':repaired})
        return {'ok':True,'project_id':project_id,'media':asdict(media),'jobs':final,'audit':audit,'memory_fingerprint':self.memory.fingerprint(project_id),'chunks':len(chunk_plan),'orchestration_fingerprint':stable_hash({'media':asdict(media),'jobs':final,'memory':self.memory.recall(project_id)})}
