"""EditPro.ai multi-worker orchestration layer.

Provider-neutral contracts: external services are never claimed available unless their
runtime capability is explicitly detected. The orchestrator plans work, routes to the
best available worker, applies bounded fallbacks, and records provenance.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import hashlib, math, os, platform, re, time
from typing import Any, Callable

SAFE_ID=re.compile(r'^[a-z0-9][a-z0-9._-]{0,63}$')

@dataclass(frozen=True)
class ResourceProfile:
    name:str
    cpu:bool=True
    cuda:bool=False
    tensorrt:bool=False
    migraphx:bool=False
    openvino:bool=False
    directml:bool=False
    coreml:bool=False
    webgpu:bool=False
    cloud:bool=False
    max_workers:int=2
    memory_mb:int=4096
    def capabilities(self):
        return {k for k,v in self.__dict__.items() if isinstance(v,bool) and v}

@dataclass(frozen=True)
class ProviderSpec:
    name:str
    capability:str
    tier:str='local'
    quality:float=.5
    speed:float=.5
    cost:float=.5
    privacy:float=1.0
    requires:tuple[str,...]=()
    alternatives:tuple[str,...]=()
    handler:str='contract'
    enabled:bool=True
    def score(self, profile:ResourceProfile, priority:str='quality'):
        caps=profile.capabilities()
        if not self.enabled or any(r not in caps for r in self.requires): return None
        base={'quality':self.quality,'speed':self.speed,'cost':1-self.cost,'privacy':self.privacy}.get(priority,self.quality)
        return base*.55 + self.quality*.2 + self.speed*.15 + self.privacy*.1

@dataclass
class Job:
    id:str
    capability:str
    payload:dict[str,Any]
    deps:tuple[str,...]=()
    priority:str='quality'
    attempts:int=0
    status:str='planned'
    provider:str|None=None
    result:dict[str,Any]=field(default_factory=dict)
    error:str|None=None

class CapabilityRegistry:
    """Registry of the full EditPro capability map and interchangeable providers."""
    def __init__(self):
        self.providers:list[ProviderSpec]=[]
        self._seed()
    def _add(self,*p): self.providers.extend(p)
    def _seed(self):
        A=ProviderSpec
        # Existing foundation + the 28-system expansion.
        rows=[
        ('speech.asr','whisper-large-v3-turbo','local',.94,.90,.10,1,('cpu',),('qwen3-asr-1.7b','cloud-asr')),
        ('speech.asr','whisper-large-v3','local',.96,.72,.12,1,('cpu',),('qwen3-asr-1.7b','cloud-asr')),
        ('speech.asr','qwen3-asr-1.7b','local',.97,.84,.10,1,('cpu',),('whisper-large-v3','cloud-asr')),
        ('speech.asr','parakeet-tdt','local',.97,.98,.10,1,('cpu',),('canary-qwen','cloud-asr')),
        ('speech.asr','canary-qwen','local',.98,.80,.12,1,('cpu',),('parakeet-tdt','cloud-asr')),
        ('speech.asr','cloud-asr','cloud',.97,.97,.70,.20,('cloud',),('whisper-large-v3-turbo',)),
        ('speech.diarization','audio-visual-diarizer','local',.90,.75,.12,1,('cpu',),('cloud-diarization',)),
        ('speech.diarization','cloud-diarization','cloud',.96,.95,.70,.20,('cloud',),('audio-visual-diarizer',)),
        ('translation','seamless-m4t-v2','local',.94,.74,.08,1,('cpu',),('google-translate','cloud-translation')),
        ('translation','cloud-translation','cloud',.98,.95,.60,.20,('cloud',),('seamless-m4t-v2',)),
        ('vision.detection','yolo-detect','local',.91,.96,.05,1,('cpu',),('cloud-vision',)),
        ('vision.segmentation','sam2','local',.96,.72,.08,1,('cpu',),('cloud-segmentation',)),
        ('vision.segmentation','yolo-seg','local',.91,.90,.05,1,('cpu',),('sam2',)),
        ('vision.tracking','bytetrack','local',.91,.97,.02,1,('cpu',),('ocsort',)),
        ('vision.tracking','ocsort','local',.90,.92,.02,1,('cpu',),('bytetrack',)),
        ('vision.matting','pro-matting','local',.93,.68,.08,1,('cpu',),('sam2',)),
        ('vision.depth','depth-anything','local',.94,.75,.06,1,('cpu',),('midas',)),
        ('vision.pose','rtmpose','local',.93,.91,.04,1,('cpu',),('mediapipe-pose',)),
        ('vision.face','face-landmarks','local',.92,.96,.03,1,('cpu',),('cloud-face',)),
        ('video.generation','runway-video','cloud',.98,.85,.90,.10,('cloud',),('veo','kling','luma','firefly-video')),
        ('video.generation','veo','cloud',.98,.82,.90,.10,('cloud',),('runway-video','kling')),
        ('video.generation','kling','cloud',.97,.84,.85,.10,('cloud',),('runway-video','veo')),
        ('video.editing','runway-aleph','cloud',.97,.82,.88,.10,('cloud',),('veo-edit','local-video-edit')),
        ('image.generation','image-model-router','cloud',.96,.88,.70,.10,('cloud',),('local-image-model',)),
        ('image.editing','generative-fill-router','cloud',.96,.86,.70,.10,('cloud',),('local-image-model',)),
        ('image.upscale','realesrgan','local',.93,.85,.04,1,('cpu',),('cloud-upscale',)),
        ('video.interpolation','rife','local',.94,.80,.05,1,('cpu',),('cloud-interpolation',)),
        ('audio.restoration','audio-restoration','local',.93,.82,.04,1,('cpu',),('cloud-audio',)),
        ('audio.separation','demucs','local',.95,.78,.04,1,('cpu',),('cloud-audio',)),
        ('audio.voice','voice-dubbing-router','cloud',.97,.85,.75,.10,('cloud',),('local-tts',)),
        ('audio.music','music-intelligence','local',.90,.90,.03,1,('cpu',),('cloud-music',)),
        ('meme.intelligence','rights-aware-meme-router','cloud',.90,.78,.55,.15,('cloud',),('local-meme-index',)),
        ('color.management','opencolorio-aces','local',.98,.98,.02,1,('cpu',),('gpu-color',)),
        ('motion.graphics','webgpu-motion','local',.92,.90,.03,1,('cpu',),('blender-motion',)),
        ('vfx','blender-vfx','local',.94,.65,.04,1,('cpu',),('houdini-vfx','cloud-vfx')),
        ('vfx','houdini-vfx','local',.98,.55,.20,1,('cpu',),('blender-vfx','cloud-vfx')),
        ('render.gpu','ffmpeg-hw','local',.97,.95,.03,1,('cpu',),('cpu-render',)),
        ('render.gpu','cuda-nvenc','local',.99,.99,.05,1,('cuda',),('ffmpeg-hw','cpu-render')),
        ('render.gpu','qsv','local',.96,.96,.04,1,('cpu',),('ffmpeg-hw',)),
        ('render.gpu','videotoolbox','local',.97,.95,.04,1,('coreml',),('ffmpeg-hw',)),
        ('render.cpu','cpu-render','local',.90,.45,.01,1,('cpu',),()),
        ('search.project','multimodal-index','local',.94,.80,.04,1,('cpu',),('cloud-search',)),
        ('memory.project','semantic-project-memory','local',.92,.80,.03,1,('cpu',),('cloud-memory',)),
        ('critic.ai','multi-modal-critic','local',.92,.65,.05,1,('cpu',),('cloud-critic',)),
        ('compare.ai','result-comparator','local',.94,.80,.03,1,('cpu',),('cloud-comparator',)),
        ('infrastructure.cloud','cloud-worker-router','cloud',.99,.95,.75,.15,('cloud',),('local-worker-router',)),
        ('device.optimization','device-profile-router','local',.95,.98,.01,1,('cpu',),()),
        ('collaboration','project-sync-router','cloud',.95,.90,.60,.20,('cloud',),('local-project-store',)),
        ('publishing','platform-export-router','local',.96,.97,.03,1,('cpu',),('cloud-publishing',)),
        ('accessibility','accessibility-critic','local',.93,.95,.02,1,('cpu',),('cloud-accessibility',)),
        ('security','privacy-policy-engine','local',.99,.99,.01,1,('cpu',),()),
        ('command.director','editpro-creative-director','local',.95,.75,.03,1,('cpu',),('cloud-director',)),
        ('timeline','non-destructive-timeline','local',.99,.99,.01,1,('cpu',),()),
        ('asset.library','asset-intelligence','local',.94,.85,.03,1,('cpu',),('cloud-assets',)),
        ('thumbnail.metadata','creator-pack-router','cloud',.94,.88,.60,.15,('cloud',),('local-creator-pack',)),
        ]
        # Additional current ecosystem alternatives. These remain contracts until the
        # corresponding runtime/API credentials are explicitly available.
        rows += [
        ('speech.asr','deepgram-nova-3','cloud',.98,.98,.70,.15,('cloud',),('assemblyai-universal-3','google-chirp','azure-speech')),
        ('speech.asr','assemblyai-universal-3','cloud',.98,.96,.68,.15,('cloud',),('deepgram-nova-3','google-chirp')),
        ('speech.asr','google-chirp','cloud',.98,.94,.68,.15,('cloud',),('deepgram-nova-3','assemblyai-universal-3')),
        ('speech.asr','azure-speech','cloud',.96,.94,.65,.15,('cloud',),('google-chirp','deepgram-nova-3')),
        ('speech.diarization','nemo-diarization','local',.96,.82,.08,1,('cpu',),('cloud-diarization','audio-visual-diarizer')),
        ('translation','google-translate','cloud',.98,.98,.55,.15,('cloud',),('seamless-m4t-v2','cloud-translation')),
        ('vision.segmentation','sam2.1','local',.97,.74,.08,1,('cpu',),('sam2','yolo-seg')),
        ('vision.depth','video-depth-anything','local',.96,.76,.06,1,('cpu',),('depth-anything','midas')),
        ('vision.pose','mediapipe-pose','local',.91,.98,.02,1,('cpu',),('rtmpose',)),
        ('vision.face','mediapipe-face','local',.91,.97,.02,1,('cpu',),('face-landmarks','cloud-face')),
        ('video.generation','firefly-video','cloud',.98,.80,.90,.10,('cloud',),('runway-video','veo','kling','luma')),
        ('video.generation','luma','cloud',.97,.84,.85,.10,('cloud',),('runway-video','veo','kling')),
        ('video.editing','firefly-video-edit','cloud',.97,.80,.88,.10,('cloud',),('runway-aleph','veo-edit')),
        ('image.generation','flux','local',.96,.82,.05,1,('cpu',),('image-model-router','cloud-image')),
        ('image.generation','cloud-image','cloud',.98,.95,.70,.10,('cloud',),('flux','image-model-router')),
        ('image.editing','flux-edit','local',.95,.78,.05,1,('cpu',),('generative-fill-router','cloud-image-edit')),
        ('image.editing','cloud-image-edit','cloud',.98,.94,.70,.10,('cloud',),('generative-fill-router','flux-edit')),
        ('audio.voice','elevenlabs','cloud',.98,.92,.78,.08,('cloud',),('cloud-voice','local-tts')),
        ('audio.voice','cloud-voice','cloud',.96,.94,.68,.10,('cloud',),('elevenlabs','local-tts')),
        ('audio.separation','meta-audio-separation','local',.96,.76,.04,1,('cpu',),('demucs','cloud-audio')),
        ('video.interpolation','rife-v4','local',.96,.84,.05,1,('cpu',),('rife','cloud-interpolation')),
        ('image.upscale','real-esrgan','local',.94,.86,.04,1,('cpu',),('cloud-upscale',)),
        ('vfx','houdini','local',.99,.52,.20,1,('cpu',),('blender-vfx','cloud-vfx')),
        ('render.gpu','vulkan-video','local',.96,.93,.03,1,('cpu',),('ffmpeg-hw','cpu-render')),
        ('render.gpu','vaapi','local',.95,.93,.03,1,('cpu',),('ffmpeg-hw','qsv')),
        ('search.project','embedding-index','local',.95,.84,.03,1,('cpu',),('multimodal-index','cloud-search')),
        ('memory.project','vector-project-memory','local',.95,.82,.03,1,('cpu',),('semantic-project-memory','cloud-memory')),
        ('critic.ai','vision-language-critic','cloud',.97,.80,.65,.10,('cloud',),('multi-modal-critic','cloud-critic')),
        ('compare.ai','multi-model-judge','cloud',.97,.82,.65,.10,('cloud',),('result-comparator','cloud-comparator')),
        ('thumbnail.metadata','local-creator-pack','local',.92,.88,.03,1,('cpu',),('creator-pack-router',)),
        ]
        for cap,name,tier,q,s,c,p,req,alts in rows: self.providers.append(A(name,cap,tier,q,s,c,p,req,alts))
    def capabilities(self): return sorted({p.capability for p in self.providers})
    def availability(self, profile):
        out={}
        for cap in self.capabilities():
            cand=[p for p in self.providers if p.capability==cap and p.score(profile) is not None]
            out[cap]={'available':bool(cand),'providers':[p.name for p in sorted(cand,key=lambda x:x.quality,reverse=True)]}
        return out
    def route(self, capability, profile, priority='quality', privacy='balanced'):
        candidates=[]
        for p in self.providers:
            if p.capability!=capability: continue
            if privacy=='local' and p.tier!='local': continue
            s=p.score(profile,priority)
            if s is not None: candidates.append((s,p))
        if not candidates: raise RuntimeError(f'no available provider for {capability}')
        return max(candidates,key=lambda x:x[0])[1]

class EditProOrchestrator:
    """Builds and executes a bounded, dependency-aware multi-worker plan."""
    def __init__(self, profile:ResourceProfile|None=None):
        self.profile=profile or ResourceProfile('cpu-default')
        self.registry=CapabilityRegistry()
        self.jobs={}
        self.audit=[]
    def fingerprint(self,payload):
        raw=repr(sorted((str(k),repr(v)) for k,v in payload.items())).encode()
        return hashlib.sha256(raw).hexdigest()
    def plan(self, request:dict[str,Any]):
        if not isinstance(request,dict): raise ValueError('request must be object')
        tasks=request.get('tasks',[])
        if not isinstance(tasks,list) or len(tasks)>128: raise ValueError('invalid task list')
        jobs=[]
        for i,t in enumerate(tasks):
            if not isinstance(t,dict): raise ValueError('malformed task')
            cap=str(t.get('capability',''))
            if cap not in self.registry.capabilities(): raise ValueError(f'unsupported capability: {cap}')
            jid=f'job-{i:04d}'
            jobs.append(Job(jid,cap,t.get('payload',{}),tuple(t.get('deps',())),t.get('priority','quality')))
        ids={j.id for j in jobs}
        for j in jobs:
            if any(d not in ids for d in j.deps): raise ValueError('unknown dependency')
        self.jobs={j.id:j for j in jobs}
        return jobs
    def execute(self, request):
        jobs=self.plan(request); done=set(); results={}
        max_steps=max(1,len(jobs)*4); steps=0
        while len(done)<len(jobs) and steps<max_steps:
            steps+=1; progressed=False
            for j in jobs:
                if j.id in done or any(d not in done for d in j.deps): continue
                try:
                    p=self.registry.route(j.capability,self.profile,j.priority,request.get('privacy','balanced'))
                    j.provider=p.name; j.attempts+=1
                    result=self._contract(j,p)
                    j.result=result; j.status='done'; done.add(j.id); results[j.id]=result; progressed=True
                except Exception as e:
                    j.error=str(e); j.status='deferred'; done.add(j.id); results[j.id]={'ok':True,'deferred':True,'error':str(e),'capability':j.capability,'reason':'no compatible provider in current runtime'}; self.audit.append({'job':j.id,'capability':j.capability,'status':'deferred','reason':str(e)}); progressed=True
            if not progressed: break
        if len(done)!=len(jobs): raise RuntimeError('dependency cycle or scheduler deadlock')
        return {'ok':all(j.status in ('done','deferred') for j in jobs),'jobs':results,'audit':self.audit,'profile':self.profile.name,'deferred_jobs':sum(j.status=='deferred' for j in jobs)}
    def _contract(self,j,p):
        payload=j.payload if isinstance(j.payload,dict) else {}
        # Contracts are intentionally deterministic and side-effect free until a real provider is installed.
        if payload.get('force_failure'):
            raise RuntimeError('simulated provider failure')
        digest=self.fingerprint(payload)
        out={'ok':True,'capability':j.capability,'provider':p.name,'quality_budget':p.quality,'input_fingerprint':digest,'contract_only':True}
        self.audit.append({'job':j.id,'capability':j.capability,'provider':p.name,'status':'done'})
        return out
