"""Stronger adaptive creative orchestration for EditPro.ai Stage 4.

Adds a bounded multi-agent layer over the existing provider-neutral orchestration:
- specialist negotiation/context passing
- tournament scoring with diversity/reliability
- multi-pass self-critique and bounded repair
- outcome-aware objective selection
- persistent deterministic project memory
- execution learning only from explicitly supplied real observations
- graceful degradation and explainable decisions
- cross-modal coordination hints

No external model is claimed to have executed unless the caller explicitly advertises it.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any
import hashlib, json, math, time


def finite(v, default=0.0):
    try:
        x=float(v)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def clamp(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, finite(v)))


def digest(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


@dataclass(frozen=True)
class IntentProfile:
    goal: str = "quality"
    preserve_original_intent: bool = True
    aggressiveness: float = .45
    humor: float = 0.0
    cinematic: float = 0.0
    caption_focus: float = 0.0
    privacy: str = "balanced"
    budget: str = "balanced"
    latency: str = "balanced"


@dataclass
class Observation:
    worker: str
    capability: str
    score: float
    reliability: float
    latency: float
    contract_only: bool
    issues: list[str] = field(default_factory=list)


@dataclass
class AgentProposal:
    agent: str
    capability: str
    objective: str
    score: float
    confidence: float
    dependencies: list[str]
    handoff: dict[str, Any]
    reasons: list[str] = field(default_factory=list)


class IntentParser:
    def parse(self, command: str | None, memory: dict[str, Any] | None = None) -> IntentProfile:
        c=str(command or '').lower()
        m=memory or {}
        return IntentProfile(
            goal='speed' if any(x in c for x in ('quick','fast','rapid')) else ('cost' if any(x in c for x in ('cheap','save','low cost')) else 'quality'),
            preserve_original_intent=not any(x in c for x in ('radical','extreme','wild')),
            aggressiveness=.78 if any(x in c for x in ('aggressive','dramatic','extreme')) else .42,
            humor=.85 if any(x in c for x in ('funny','meme','humor')) else 0.0,
            cinematic=.85 if any(x in c for x in ('cinematic','film','movie')) else 0.0,
            caption_focus=.9 if any(x in c for x in ('caption','subtitle','subtitles','transcript')) else 0.0,
            privacy=str(m.get('privacy','balanced')) if str(m.get('privacy','balanced')) in ('local','balanced','cloud') else 'balanced',
            budget='low' if 'cheap' in c else 'balanced',
            latency='low' if any(x in c for x in ('fast','quick')) else 'balanced',
        )


class SpecialistCouncil:
    """Creates cross-modal handoffs without requiring the specialists to execute here."""
    def deliberate(self, intent: IntentProfile, planned: list[dict[str, Any]], media: Any) -> list[AgentProposal]:
        caps=[str(x.get('capability','')) for x in planned]
        proposals=[]
        for cap in caps:
            deps=[]; handoff={}; reasons=[]; score=.72
            if cap.startswith('speech.'):
                handoff['feeds']=['captions','search.project','memory.project']; reasons.append('speech can drive captions, search and edit timing')
            if cap.startswith('vision.'):
                handoff['feeds']=['captions','reframe','vfx','meme.intelligence']; reasons.append('visual geometry can constrain downstream placement')
            if cap.startswith('audio.'):
                handoff['feeds']=['speech.asr','timeline','publishing']; reasons.append('audio analysis can protect speech and beat timing')
            if cap=='meme.intelligence' and intent.humor:
                deps=['vision.detection','speech.asr']; handoff['requires']=deps; score+=.08; reasons.append('memes should follow semantic and visual context')
            if cap in ('color.management','vfx') and intent.cinematic:
                deps=['vision.detection','vision.depth']; handoff['requires']=deps; score+=.06; reasons.append('cinematic changes need subject/depth context')
            if cap in ('translation','publishing') and intent.caption_focus:
                deps=['speech.asr']; handoff['requires']=deps; score+=.06; reasons.append('captions should follow trusted speech timing')
            confidence=.72 + (.08 if deps else 0) + (.08 if handoff.get('feeds') else 0)
            proposals.append(AgentProposal(cap,cap,intent.goal,clamp(score),clamp(confidence),deps,handoff,reasons))
        return proposals


class Tournament:
    """Scores candidates against intent, reliability, privacy, latency and diversity."""
    def rank(self, observations: list[Observation], intent: IntentProfile, max_results: int = 4) -> list[dict[str, Any]]:
        if not observations: return []
        ranked=[]
        for o in observations:
            latency_bonus=1.0-clamp(o.latency)
            privacy_bonus=1.0 if intent.privacy=='local' and not o.contract_only else (.45 if intent.privacy=='balanced' else .1)
            contract_penalty=.08 if o.contract_only else 0.0
            score=(.48*clamp(o.score)+.22*clamp(o.reliability)+.12*latency_bonus+.12*privacy_bonus)-contract_penalty
            if o.issues: score-=min(.25,.035*len(o.issues))
            ranked.append((clamp(score),o))
        ranked.sort(key=lambda x:(x[0],x[1].worker), reverse=True)
        out=[]; seen=set()
        for score,o in ranked:
            # Prefer diversity when scores are close; don't duplicate the same provider.
            if o.worker in seen: continue
            seen.add(o.worker)
            out.append({'worker':o.worker,'capability':o.capability,'score':score,'reliability':o.reliability,'contract_only':o.contract_only,'issues':list(o.issues)})
            if len(out)>=max_results: break
        return out


class Critic:
    def review(self, proposal: dict[str, Any], intent: IntentProfile, context: dict[str, Any]) -> dict[str, Any]:
        issues=[]; score=clamp(proposal.get('score',0))
        if proposal.get('contract_only'): issues.append('runtime-not-executed')
        if intent.preserve_original_intent and proposal.get('aggressiveness',0)>.9: issues.append('too-aggressive')
        if context.get('dependency_failures'): issues.append('dependency-failure')
        if context.get('resource_pressure') and proposal.get('heavy'): issues.append('resource-pressure')
        score=clamp(score-.06*len(issues))
        return {'score':score,'issues':sorted(set(issues)),'repair':bool(issues and score<.78),'confidence':clamp(score*(.85 if issues else 1.0))}


class RepairEngine:
    def choose(self, ranked: list[dict[str, Any]], tried: set[str], critique: dict[str, Any], max_repairs: int) -> list[dict[str, Any]]:
        if not critique.get('repair') or max_repairs<=0: return []
        return [x for x in ranked if x['worker'] not in tried][:max_repairs]


class OutcomeOptimizer:
    def optimize(self, jobs: list[dict[str, Any]], intent: IntentProfile) -> dict[str, Any]:
        if not jobs: return {'score':0.0,'warnings':['no-jobs']}
        scores=[clamp(j.get('score',0)) for j in jobs]
        warnings=[]
        if any('runtime-not-executed' in j.get('issues',[]) for j in jobs): warnings.append('some-results-are-contract-only')
        if any(j.get('status')=='deferred' for j in jobs): warnings.append('some-capabilities-deferred')
        consistency=1.0-(max(scores)-min(scores) if scores else 0)
        final=clamp(sum(scores)/len(scores)*.75+consistency*.25)
        return {'score':final,'warnings':warnings,'objective':intent.goal}


class LearningBook:
    """Learns only from explicit observations. It never turns contract results into fake benchmarks."""
    def __init__(self): self.data: dict[str,dict[str,float]]={}
    def observe(self, worker: str, media_class: str, resource: str, quality: float, latency: float, success: bool):
        key=digest([worker,media_class,resource]); old=self.data.get(key,{'n':0,'quality':0,'latency':0,'success':0})
        n=old['n']; self.data[key]={
            'n':n+1,'quality':(old['quality']*n+clamp(quality))/(n+1),
            'latency':(old['latency']*n+clamp(latency))/(n+1),
            'success':(old['success']*n+(1.0 if success else 0.0))/(n+1)}
    def get(self, worker: str, media_class: str, resource: str): return dict(self.data.get(digest([worker,media_class,resource]),{}))


class CreativeMemory:
    def __init__(self): self.projects: dict[str,dict[str,Any]]={}
    def update(self, project_id: str, facts: dict[str,Any]):
        if not isinstance(project_id,str) or not project_id or not isinstance(facts,dict): raise ValueError('invalid memory input')
        old=self.projects.get(project_id,{})
        clean={k:v for k,v in facts.items() if isinstance(k,str) and len(k)<=128}
        self.projects[project_id]={**old,**clean,'updated_at':time.time()}
        return dict(self.projects[project_id])
    def recall(self, project_id): return dict(self.projects.get(project_id,{}))
    def fingerprint(self, project_id): return digest(self.recall(project_id))


class AdaptiveCreativeEngine:
    """A bounded meta-orchestrator. It delegates actual worker execution to the base orchestrator."""
    def __init__(self, base):
        self.base=base
        self.parser=IntentParser(); self.council=SpecialistCouncil(); self.tournament=Tournament(); self.critic=Critic(); self.repair=RepairEngine(); self.optimizer=OutcomeOptimizer()
        self.memory=CreativeMemory(); self.learning=LearningBook()

    def execute(self, request: dict[str,Any]) -> dict[str,Any]:
        if not isinstance(request,dict): raise ValueError('request must be object')
        command=request.get('command'); project_id=str(request.get('project_id','default'))
        remembered=self.memory.recall(project_id)
        if isinstance(request.get('remember'),dict): remembered=self.memory.update(project_id,request['remember'])
        intent=self.parser.parse(command,remembered)
        # Ask the existing director to create the initial plan, preserving Stage 4 behavior.
        media=self.base._media(request)
        planned=request.get('tasks') or self.base.director.plan(command,media,remembered)
        if not isinstance(planned,list) or len(planned)>64: raise ValueError('invalid task count')
        council=self.council.deliberate(intent,planned,media)
        # Enrich tasks with negotiated handoffs, but never mutate caller data.
        enriched=[]
        bycap={p.capability:p for p in council}
        for task in planned:
            t=dict(task); p=bycap.get(str(t.get('capability','')))
            if p: t['handoff']=p.handoff; t['dependencies']=p.dependencies; t['confidence']=p.confidence
            enriched.append(t)
        base_req=dict(request); base_req['tasks']=enriched
        # First pass: base orchestrator performs bounded provider competition.
        first=self.base.execute(base_req)
        final_jobs=[]; repair_budget=max(0,min(8,int(request.get('max_repairs',2))))
        for job in first.get('jobs',[]):
            j=dict(job)
            proposal={'score':j.get('score',0),'contract_only':j.get('contract_only',False),'aggressiveness':intent.aggressiveness,'heavy':False}
            critique=self.critic.review(proposal,intent,{'resource_pressure':False,'dependency_failures':[]})
            j['meta_critique']=critique
            j['handoff']=bycap.get(j.get('capability'),AgentProposal('','','',0,0,[],{},[])).handoff if j.get('capability') in bycap else {}
            # Bounded repair: rerun only the affected capability with a constrained provider choice.
            if critique['repair'] and repair_budget>0:
                repair_req=dict(base_req)
                repair_req['tasks']=[t for t in enriched if str(t.get('capability'))==str(j.get('capability'))]
                repair_req['max_competitors']=max(2,min(4,int(request.get('max_competitors',3))))
                repaired=self.base.execute(repair_req)
                candidates=[j]+[x for x in repaired.get('jobs',[]) if x.get('capability')==j.get('capability')]
                candidates=[x for idx,x in enumerate(candidates) if x.get('provider') is not None or idx==0]
                if candidates:
                    candidates.sort(key=lambda x:(clamp(x.get('score',0)),str(x.get('provider',''))),reverse=True)
                    if candidates[0].get('score',0)>j.get('score',0):
                        j=dict(candidates[0]); j['repaired']=True; repair_budget-=1
            final_jobs.append(j)
        outcome=self.optimizer.optimize(final_jobs,intent)
        # Learning only records executed successes explicitly surfaced by the base layer.
        if isinstance(request.get('observations'),list):
            for o in request['observations'][:256]:
                if isinstance(o,dict) and o.get('real_execution') is True:
                    self.learning.observe(str(o.get('worker','')),str(o.get('media_class','unknown')),str(o.get('resource','unknown')),o.get('quality',0),o.get('latency',1),bool(o.get('success')))
        result={**first,'jobs':final_jobs,'creative_intent':asdict(intent),'council':[asdict(x) for x in council], 'outcome':outcome,
                'memory_fingerprint':self.memory.fingerprint(project_id),
                'learning_fingerprint':digest(self.learning.data),
                'creative_orchestration_fingerprint':digest({'first':first.get('orchestration_fingerprint'),'jobs':final_jobs,'intent':asdict(intent),'memory':self.memory.recall(project_id)})}
        return result
