"""EditPro.ai Stage 13.5: Core Editing Completion Layer.

Closes the editing-capability gaps identified between the Stage 0-13 foundation and
Stage 14. It is deliberately deterministic and non-destructive: it creates a typed
edit graph/plan which downstream renderers can execute without changing Stage 14's
scope.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import hashlib, json, math, re


def finite(x):
    try: return math.isfinite(float(x))
    except (TypeError, ValueError): return False

def clamp(v, lo=0.0, hi=1.0): return max(lo, min(hi, float(v)))

def norm(x): return re.sub(r"[^a-z0-9_ -]+", "", str(x or "").lower()).strip()

def digest_obj(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()

EDIT_FEATURES = {
    # Timeline / edit
    "smart_trim", "smart_cut", "silence_removal", "duplicate_removal", "highlight_selection",
    "speed_ramp", "freeze_frame", "keyframes", "advanced_transitions", "non_destructive_history",
    "undo_redo", "versioning", "before_after_preview", "multi_edit_command",
    # Composition / visual
    "auto_reframe", "subject_tracking", "face_tracking", "object_tracking", "ai_color_correction",
    "ai_color_grading", "selective_color", "object_removal", "object_replacement", "background_replacement",
    "relighting", "motion_blur", "depth_effects", "privacy_blur",
    # Audio
    "noise_removal", "voice_enhancement", "dialogue_music_separation", "auto_ducking", "audio_sync",
    "beat_detection", "volume_normalization", "audio_fade",
    # Text / captions
    "auto_captions", "word_timing", "caption_animation", "speaker_detection", "caption_placement", "text_tracking",
    # Creator / delivery
    "platform_export", "hook_detection", "highlight_reel", "long_to_shorts", "thumbnail_selection", "thumbnail_composition",
    # Control / quality
    "natural_language_editing", "edit_validation", "render_contract", "quality_gate",
}

FEATURE_GROUPS = {
    "timeline": {"smart_trim","smart_cut","silence_removal","duplicate_removal","highlight_selection","speed_ramp","freeze_frame","keyframes","advanced_transitions","non_destructive_history","undo_redo","versioning","before_after_preview","multi_edit_command"},
    "visual": {"auto_reframe","subject_tracking","face_tracking","object_tracking","ai_color_correction","ai_color_grading","selective_color","object_removal","object_replacement","background_replacement","relighting","motion_blur","depth_effects","privacy_blur"},
    "audio": {"noise_removal","voice_enhancement","dialogue_music_separation","auto_ducking","audio_sync","beat_detection","volume_normalization","audio_fade"},
    "text": {"auto_captions","word_timing","caption_animation","speaker_detection","caption_placement","text_tracking"},
    "creator": {"platform_export","hook_detection","highlight_reel","long_to_shorts","thumbnail_selection","thumbnail_composition"},
    "control": {"natural_language_editing","edit_validation","render_contract","quality_gate"},
}

@dataclass
class EditOperation:
    feature: str
    params: Dict[str, Any] = field(default_factory=dict)
    source: str = "ai_command"
    reversible: bool = True
    provider: str = "deterministic_cpu"
    priority: int = 50
    def validate(self):
        if self.feature not in EDIT_FEATURES: raise ValueError("unsupported editing feature")
        if not isinstance(self.params, dict): raise ValueError("invalid operation params")
        if not self.source.strip(): raise ValueError("operation source required")
        if self.priority < 0 or self.priority > 100: raise ValueError("invalid operation priority")

@dataclass
class TimelineState:
    duration: float
    fps: float = 30.0
    target_format: str = "landscape"
    segments: List[Dict[str, Any]] = field(default_factory=list)
    keyframes: List[Dict[str, Any]] = field(default_factory=list)
    history: List[str] = field(default_factory=list)
    current_version: int = 1
    def validate(self):
        if not finite(self.duration) or self.duration <= 0: raise ValueError("invalid timeline duration")
        if not finite(self.fps) or self.fps <= 0: raise ValueError("invalid fps")
        if self.current_version < 1: raise ValueError("invalid timeline version")
        for s in self.segments:
            if not isinstance(s,dict): raise ValueError("invalid segment")
            st=float(s.get("start",0)); en=float(s.get("end",0))
            if st < 0 or en <= st or en > self.duration + 1e-6: raise ValueError("invalid segment range")

@dataclass
class EditingPlan:
    command: str
    features: List[str]
    operations: List[EditOperation]
    timeline: TimelineState
    contracts: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    digest: str = ""
    def validate(self):
        if not self.command.strip(): raise ValueError("editing command required")
        if not self.features: raise ValueError("editing features required")
        if any(x not in EDIT_FEATURES for x in self.features): raise ValueError("unknown editing feature")
        for op in self.operations: op.validate()
        self.timeline.validate()

class EditingIntentParser:
    """Conservative keyword parser. It never claims a generative edit was rendered."""
    RULES = [
        (("remove boring", "cut boring", "tight edit", "trim boring"), "smart_trim"),
        (("silence", "silent parts"), "silence_removal"),
        (("duplicate", "repeated"), "duplicate_removal"),
        (("highlight", "best moments", "best parts"), "highlight_selection"),
        (("slow motion", "speed ramp", "speed ramping"), "speed_ramp"),
        (("freeze", "freeze frame"), "freeze_frame"),
        (("keyframe", "animate position", "animate scale"), "keyframes"),
        (("transition", "transitions", "whip", "morph"), "advanced_transitions"),
        (("reframe", "vertical", "9:16", "portrait", "reel"), "auto_reframe"),
        (("track", "tracking", "follow subject", "follow object"), "subject_tracking"),
        (("face blur", "faces blur", "privacy"), "privacy_blur"),
        (("color correct", "fix colors", "white balance", "exposure"), "ai_color_correction"),
        (("color grade", "cinematic colors", "cinematic grade", "look"), "ai_color_grading"),
        (("selective color", "only red", "only blue"), "selective_color"),
        (("remove object", "remove person", "remove the person", "erase object", "unwanted person"), "object_removal"),
        (("replace object", "replace phone", "change object"), "object_replacement"),
        (("replace background", "new background", "background change"), "background_replacement"),
        (("relight", "lighting", "change light"), "relighting"),
        (("motion blur", "depth", "depth effect"), "motion_blur"),
        (("noise", "denoise", "clean audio", "clean voice"), "noise_removal"),
        (("voice enhance", "enhance voice", "clear voice", "dialogue enhance"), "voice_enhancement"),
        (("separate music", "separate dialogue", "stem"), "dialogue_music_separation"),
        (("duck music", "lower music", "music under voice"), "auto_ducking"),
        (("sync audio", "audio sync"), "audio_sync"),
        (("beat", "beats", "beat sync"), "beat_detection"),
        (("normalize volume", "loudness", "volume normalize"), "volume_normalization"),
        (("caption", "subtitles", "subtitle"), "auto_captions"),
        (("word timing", "word by word", "karaoke"), "word_timing"),
        (("animated captions", "caption animation"), "caption_animation"),
        (("speaker", "speaker labels"), "speaker_detection"),
        (("caption position", "move captions", "caption placement"), "caption_placement"),
        (("text follow", "text tracking", "text follows"), "text_tracking"),
        (("reel", "short", "shorts", "instagram", "youtube"), "platform_export"),
        (("hook", "strong opening"), "hook_detection"),
        (("long video", "long to shorts", "make shorts"), "long_to_shorts"),
        (("thumbnail", "cover"), "thumbnail_selection"),
        (("thumbnail design", "thumbnail composition"), "thumbnail_composition"),
    ]
    @classmethod
    def parse(cls, command: str) -> List[str]:
        text=norm(command)
        found=[]
        for words, feature in cls.RULES:
            if any(w in text for w in words) and feature not in found: found.append(feature)
        # A multi-edit natural-language command always gets the orchestration guard.
        if found or len(text.split()) >= 5:
            found.append("natural_language_editing")
        for f in ("edit_validation","render_contract","quality_gate"):
            if f not in found: found.append(f)
        return found

class Stage13_5EditingEngine:
    def __init__(self, providers=None):
        self.providers=set(providers or {"deterministic_cpu"}) or {"deterministic_cpu"}
    def plan(self, command: str, duration: float, fps: float=30.0, target_format: str="landscape", features: Optional[List[str]]=None, media: Optional[Dict[str,Any]]=None) -> EditingPlan:
        if not isinstance(command,str) or not command.strip(): raise ValueError("command required")
        duration=max(.001,float(duration)); fps=max(.1,float(fps))
        fs=list(dict.fromkeys(features or EditingIntentParser.parse(command)))
        fs=[f for f in fs if f in EDIT_FEATURES]
        if not fs: fs=["natural_language_editing","edit_validation","render_contract","quality_gate"]
        ops=[]
        for i,f in enumerate(fs):
            provider="deterministic_cpu" if f in {"edit_validation","render_contract","quality_gate","natural_language_editing","non_destructive_history","undo_redo","versioning","before_after_preview"} else ("optional_ai" if "optional_ai" in self.providers else "deterministic_cpu")
            ops.append(EditOperation(f, self._defaults(f,duration,fps,target_format,media or {}), "ai_command", True, provider, min(100,20+i*2)))
        timeline=TimelineState(duration,fps,target_format,history=["v1:source"])
        contracts={
            "non_destructive": True,
            "original_media_preserved": True,
            "reversible": True,
            "cpu_fallback": True,
            "render_required_for_pixels": True,
            "stage14_boundary": "preserved",
            "supported_groups": sorted({g for g,vals in FEATURE_GROUPS.items() if set(fs)&vals}),
        }
        warnings=[]
        if "optional_ai" not in self.providers: warnings.append("Optional AI edit providers unavailable; deterministic planning and CPU-safe fallbacks remain active.")
        if any(f in fs for f in {"object_removal","object_replacement","background_replacement","relighting"}) and "optional_ai" not in self.providers:
            warnings.append("Generative pixel transformation is not claimed; renderer/provider contract remains pending.")
        p=EditingPlan(command,fs,ops,timeline,contracts,warnings)
        p.validate(); p.digest=digest_obj({"command":p.command,"features":p.features,"operations":[asdict(o) for o in p.operations],"timeline":asdict(p.timeline),"contracts":p.contracts}); return p
    def _defaults(self,f,duration,fps,target,media):
        d={"duration":duration,"fps":fps,"target_format":target}
        if f in {"smart_trim","smart_cut","silence_removal","duplicate_removal"}: d.update({"preserve_highlights":True,"minimum_segment":0.25})
        elif f=="auto_reframe": d.update({"source_aspect":media.get("aspect_ratio"),"face_aware":True,"subject_aware":True})
        elif f in {"subject_tracking","object_tracking","face_tracking","text_tracking"}: d.update({"confidence_gate":0.5,"interpolate_missing":True})
        elif f=="speed_ramp": d.update({"beat_aware":True,"preserve_audio_pitch":True})
        elif f=="advanced_transitions": d.update({"max_seconds":0.8,"content_aware":True})
        elif f in {"ai_color_correction","ai_color_grading"}: d.update({"skin_tone_guard":True,"highlight_protection":True})
        elif f=="auto_ducking": d.update({"amount_db":-7,"attack":0.05,"release":0.18})
        elif f in {"auto_captions","word_timing"}: d.update({"word_level":True,"safe_area":True})
        elif f=="platform_export": d.update({"profiles":[target],"quality_gate":True})
        elif f=="long_to_shorts": d.update({"max_outputs":20,"hook_first":True,"duplicate_safe":True})
        return d
    def inspect(self,p:EditingPlan):
        p.validate(); return {"ok":True,"feature_count":len(p.features),"operation_count":len(p.operations),"groups":p.contracts["supported_groups"],"warnings":list(p.warnings),"digest":p.digest,"stage14_boundary":p.contracts["stage14_boundary"]}
    def handoff(self,p:EditingPlan):
        p.validate(); return {"editing_digest":p.digest,"features":list(p.features),"operations":[asdict(o) for o in p.operations],"contracts":dict(p.contracts),"timeline":asdict(p.timeline),"warnings":list(p.warnings)}

EditingEngine=Stage13_5EditingEngine
