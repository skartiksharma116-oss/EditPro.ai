# Stage 9 — AI Cinematography Director

Stage 9 is the director layer above Stage 8. It turns normalized media, visual and speech signals into a deterministic cinematic shot plan.

## Scope
- Scene/intent/mood analysis
- Adaptive pacing: slow, adaptive, fast, beat
- Shot scale selection: extreme wide → extreme close-up
- Camera angle vocabulary and camera movement planning
- Subject-priority framing and crop strategy
- Dialogue-aware hold guidance
- 180-degree continuity guidance
- Motion-fatigue guardrails
- Transition selection
- Camera keyframe plan for Stage 8
- Portrait/reel/story/landscape-aware planning
- Deterministic plans and digests
- CPU/local-first operation with optional provider contracts

## Explicitly deferred
- Full audio mixing/mastering (Stage 10)
- Meme Engine (Stage 11)
- Full image/asset studio (Stage 12)
- Global style engine (Stage 13)
- Generative photorealistic video generation

## Quality rule
Stage 9 plans decisions. Stage 8 executes scene/compositing/rendering decisions. A later stage may add richer models, but Stage 9's contract stays deterministic and safe when advanced providers are unavailable.
