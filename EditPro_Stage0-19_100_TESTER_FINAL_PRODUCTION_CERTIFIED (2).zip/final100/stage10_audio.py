from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
import hashlib, json, math, re, subprocess, wave, audioop

MOODS={"neutral","calm","emotional","energetic","dramatic","uplifting","dark","cinematic","luxury","epic"}
MIX_STYLES={"balanced","cinematic","dialogue","music_video","podcast","documentary","reel","trailer"}
SOURCE_TYPES={"voice","music","sfx","ambience","original","unknown"}
def clamp(v,lo=0.,hi=1.): return max(lo,min(hi,float(v)))
def finite(*xs): return all(math.isfinite(float(x)) for x in xs)
def norm(x): return re.sub(r"[^a-z0-9_ -]+","",str(x or "").lower()).strip()
@dataclass
class AudioSource:
 id:str; kind:str="unknown"; path:str=""; start:float=0.; end:float=0.; gain_db:float=0.; pan:float=0.; duck_db:float=0.; role:str=""
 def validate(self):
  if not self.id or self.kind not in SOURCE_TYPES or not finite(self.start,self.end,self.gain_db,self.pan,self.duck_db): raise ValueError("invalid audio source")
  if self.start<0 or self.end<0 or self.end < self.start or not -1<=self.pan<=1: raise ValueError("invalid audio range")
@dataclass
class LoudnessTarget:
 integrated_lufs:float=-14.; true_peak_db:float=-1.; loudness_range:float=11.
 def validate(self):
  if not finite(self.integrated_lufs,self.true_peak_db,self.loudness_range) or not -70<=self.integrated_lufs<=-5 or not -9<=self.true_peak_db<=0: raise ValueError("invalid loudness target")
@dataclass
class BeatGrid:
 bpm:float=120.; beats:List[float]=field(default_factory=list); confidence:float=0.; downbeats:List[float]=field(default_factory=list)
 def validate(self):
  if not finite(self.bpm,self.confidence) or self.bpm<=0 or not 0<=self.confidence<=1 or self.beats!=sorted(set(self.beats)): raise ValueError("invalid beat grid")
  if any(not finite(x) or x<0 for x in self.beats+self.downbeats): raise ValueError("invalid beat timestamp")
@dataclass
class SpeechSegment:
 start:float; end:float; text:str=""; speaker:str="speaker_0"; confidence:float=0.
 def validate(self):
  if not finite(self.start,self.end,self.confidence) or self.start<0 or self.end<=self.start or not 0<=self.confidence<=1: raise ValueError("invalid speech segment")
@dataclass
class AudioPlan:
 duration:float; sample_rate:int; channels:int; mood:str; style:str; sources:List[AudioSource]=field(default_factory=list); beat_grid:BeatGrid=field(default_factory=BeatGrid); speech:List[SpeechSegment]=field(default_factory=list); ducking_events:List[Dict[str,Any]]=field(default_factory=list); automation:List[Dict[str,Any]]=field(default_factory=list); effects:List[Dict[str,Any]]=field(default_factory=list); master:Dict[str,Any]=field(default_factory=dict); warnings:List[str]=field(default_factory=list); capabilities:Dict[str,bool]=field(default_factory=dict); metadata:Dict[str,Any]=field(default_factory=dict); digest:str=""
 def validate(self):
  if not finite(self.duration) or self.duration<=0 or not 8000<=self.sample_rate<=192000 or not 1<=self.channels<=8 or self.mood not in MOODS or self.style not in MIX_STYLES: raise ValueError("invalid audio plan")
  self.beat_grid.validate()
  for x in self.sources: x.validate()
  for x in self.speech: x.validate()
class AudioAnalyzer:
 @staticmethod
 def _mood(command,energy=.5):
  t=norm(command); m={"calm":"calm","peaceful":"calm","emotional":"emotional","sad":"emotional","hype":"energetic","energetic":"energetic","fast":"energetic","dramatic":"dramatic","dark":"dark","happy":"uplifting","uplifting":"uplifting","luxury":"luxury","premium":"luxury","epic":"epic","cinematic":"cinematic"}
  for k,v in m.items():
   if re.search(r"\b"+re.escape(k)+r"\b",t): return v
  return "energetic" if energy>.7 else "calm" if energy<.25 else "cinematic"
 @staticmethod
 def probe(path):
  if str(path).lower().endswith('.wav'):
   try:
    with wave.open(str(path),'rb') as w: dur=w.getnframes()/w.getframerate(); return {'duration':dur,'sample_rate':w.getframerate(),'channels':w.getnchannels(),'ok':dur>0 and w.getframerate()>0 and w.getnchannels()>0}
   except Exception: pass
  try:
   o=subprocess.run(['ffprobe','-v','error','-select_streams','a:0','-show_entries','stream=sample_rate,channels,duration','-of','json',str(path)],capture_output=True,text=True,timeout=5,check=True); s=(json.loads(o.stdout).get('streams') or [{}])[0]; dur=float(s.get('duration') or 0); sr=int(s.get('sample_rate') or 0); ch=int(s.get('channels') or 0); return {'duration':dur,'sample_rate':sr,'channels':ch,'ok':dur>0 and sr>0 and ch>0}
  except Exception as e: return {'ok':False,'error':str(e)}
 @staticmethod
 def analyze(command,audio=None,transcript=None,beats=None):
  if not isinstance(command,str) or not command.strip(): raise ValueError('command required')
  audio=audio or {}; transcript=transcript or []; beats=beats or []; energy=clamp(float(audio.get('energy',audio.get('rms',.5)) or .5)); mood=AudioAnalyzer._mood(command,energy); t=norm(command)
  style='reel' if any(x in t for x in ('reel','short','shorts')) else 'trailer' if 'trailer' in t else 'podcast' if 'podcast' in t else 'documentary' if 'documentary' in t else 'dialogue' if any(x in t for x in ('voice','dialogue','interview')) else 'music_video' if any(x in t for x in ('music video','song','beat')) else 'cinematic'
  speech=[]
  for x in transcript:
   if not isinstance(x,dict): continue
   try:
    s=SpeechSegment(float(x.get('start',0)),float(x.get('end',x.get('start',0))),str(x.get('text',x.get('word',''))),str(x.get('speaker','speaker_0')),clamp(float(x.get('confidence',.8)))); s.validate(); speech.append(s)
   except Exception: pass
  bg=[]
  for b in beats:
   try: bg.append(float(b.get('time',b.get('start'))) if isinstance(b,dict) else float(b))
   except Exception: pass
  bg=sorted(set(x for x in bg if finite(x) and x>=0)); bpm=max(30,min(300,float(audio.get('bpm',120) or 120)))
  return {'mood':mood,'style':style,'energy':energy,'bpm':bpm,'beats':bg,'speech':speech,'duration':float(audio.get('duration',0) or 0),'sample_rate':int(audio.get('sample_rate',48000) or 48000),'channels':int(audio.get('channels',2) or 2)}
class BeatEngine:
 @staticmethod
 def build(bpm,duration,existing=None,confidence=.5):
  bpm=max(30,min(300,float(bpm))); step=60/bpm; vals=sorted(set(round(float(x),6) for x in (existing or []) if finite(float(x)) and 0<=float(x)<=duration))
  if not vals: vals=[round(i*step,6) for i in range(min(20000,max(0,int(math.floor(duration/step))+1))) if i*step<=duration]
  return BeatGrid(bpm,vals,clamp(confidence),vals[::4])
class MixPlanner:
 def plan(self,a,sources=None,target=None):
  duration=max(.001,float(a.get('duration',1))); target=target or LoudnessTarget(); target.validate(); style=a.get('style','cinematic') if a.get('style') in MIX_STYLES else 'cinematic'; mood=a.get('mood','cinematic') if a.get('mood') in MOODS else 'cinematic'; src=[]
  for i,s in enumerate(sources or []):
   if isinstance(s,dict):
    kind=s.get('kind','unknown'); kind=kind if kind in SOURCE_TYPES else 'unknown'; start=max(0.0,min(duration,float(s.get('start',0)))); end=max(start,min(duration,float(s.get('end',duration) or duration))); duck=min(0.0,max(-60.0,float(s.get('duck_db',0)))); src.append(AudioSource(str(s.get('id',f'src-{i:03d}')),kind,str(s.get('path','')),start,end,float(s.get('gain_db',0)),clamp(float(s.get('pan',0)),-1,1),duck,str(s.get('role',kind))))
  if not src: src=[AudioSource('original','original',end=duration,role='original_mix')]
  speech=a.get('speech') or []; beats=BeatEngine.build(a.get('bpm',120),duration,a.get('beats'),.9 if a.get('beats') else .55); duck=[{'start':max(0,s.start-.12),'end':min(duration,s.end+.18),'amount_db':-7.,'curve':'smooth'} for s in speech]
  effects=[{'stage':'voice','chain':['highpass_70hz','deesser','compressor','eq_presence','limiter']},{'stage':'music','chain':['eq_lowcut','sidechain_duck','stereo_safe','limiter']},{'stage':'master','chain':['loudnorm_ebur128','true_peak_guard','limiter']}]
  if style=='podcast': effects[0]['chain']=['highpass_70hz','deesser','compressor','noise_gate','loudness']
  automation=[{'time':b,'event':'beat','camera_sync':True,'gain_db':0.} for b in beats.beats[:2000]]; warnings=[]
  if not speech: warnings.append('No speech timings supplied; dialogue ducking remains inactive.')
  if not a.get('beats'): warnings.append('No measured beat positions supplied; deterministic BPM grid fallback used.')
  plan=AudioPlan(duration,int(a.get('sample_rate',48000)),int(a.get('channels',2)),mood,style,src,beats,speech,duck,automation,effects,{'target_lufs':target.integrated_lufs,'true_peak_db':target.true_peak_db,'lra':target.loudness_range,'two_pass':True,'preserve_dynamics':style in {'cinematic','documentary','music_video'}},warnings,CapabilityRegistry.available(),{'audio_director_version':'10.1','sync_contract':'stage9_camera_beats'}); plan.validate(); plan.digest=self.digest(plan); return plan
 @staticmethod
 def digest(plan): d=asdict(plan); d['digest']=''; return hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
class AudioRenderer:
 @staticmethod
 def master_filter(target=None): target=target or LoudnessTarget(); target.validate(); return f'loudnorm=I={target.integrated_lufs}:LRA={target.loudness_range}:TP={target.true_peak_db}:dual_mono=false'
 @staticmethod
 def command(input_path,output_path,target=None): return ['ffmpeg','-y','-i',str(input_path),'-af',AudioRenderer.master_filter(target),'-c:a','aac','-b:a','256k',str(output_path)]
class CapabilityRegistry:
 _cache=None
 @classmethod
 def available(cls):
  if cls._cache is not None: return dict(cls._cache)
  out={}
  for name,m in {'Whisper':'whisper','Essentia':'essentia','Demucs':'demucs','librosa':'librosa'}.items():
   try: __import__(m); out[name]=True
   except Exception: out[name]=False
  try: subprocess.run(['ffmpeg','-version'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=2); out['FFmpeg']=True
  except Exception: out['FFmpeg']=False
  cls._cache=dict(out); return dict(out)
class Stage10Pipeline:
 def analyze(self,*args,**kwargs): return AudioAnalyzer.analyze(*args,**kwargs)
 def plan(self,command,audio=None,transcript=None,beats=None,sources=None,target=None): return MixPlanner().plan(self.analyze(command,audio,transcript,beats),sources,target)
 def inspect(self,plan): plan.validate(); return {'ok':True,'duration':plan.duration,'sources':len(plan.sources),'beats':len(plan.beat_grid.beats),'speech_segments':len(plan.speech),'ducking_events':len(plan.ducking_events),'effects':len(plan.effects),'digest':plan.digest,'warnings':list(plan.warnings),'capabilities':dict(plan.capabilities)}
 def export_timeline(self,plan): plan.validate(); return {'schema':'EditProAudioTimeline/1','rate':plan.sample_rate,'duration':plan.duration,'tracks':[{'kind':'audio','sources':[asdict(x) for x in plan.sources],'ducking':plan.ducking_events}],'beats':asdict(plan.beat_grid),'master':plan.master,'metadata':{'stage':10,'digest':plan.digest}}
