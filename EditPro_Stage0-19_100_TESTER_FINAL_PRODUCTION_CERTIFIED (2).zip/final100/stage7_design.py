from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any
import hashlib, html, json, math, re

MAX_ITEMS = 512
FORMATS = {
    'instagram_post': (1080,1080), 'instagram_story': (1080,1920), 'reel': (1080,1920),
    'youtube_thumbnail': (1280,720), 'youtube_banner': (2560,1440), 'poster': (1080,1350),
    'square': (1080,1080), 'landscape': (1920,1080),
}

@dataclass(frozen=True)
class AssetSlot:
    slot_id: str; kind: str='image'; required: bool=False; fit: str='cover'; safe_area: float=.08
    def validate(self):
        if not self.slot_id or len(self.slot_id)>96: raise ValueError('invalid slot_id')
        if self.kind not in {'image','video','logo','text','icon','shape'}: raise ValueError('invalid slot kind')
        if self.fit not in {'cover','contain','stretch'}: raise ValueError('invalid fit')
        if not math.isfinite(self.safe_area) or not 0<=self.safe_area<.5: raise ValueError('invalid safe area')
        return True

@dataclass
class DesignElement:
    element_id: str; kind: str; x: float=0; y: float=0; w: float=1; h: float=1; z: int=0
    text: str=''; slot_id: str|None=None; style: dict[str,Any]=field(default_factory=dict); locked: bool=False
    def validate(self):
        if not self.element_id or len(self.element_id)>96: raise ValueError('invalid element id')
        if self.kind not in {'text','image','video','logo','shape','group','icon'}: raise ValueError('invalid element kind')
        vals=(self.x,self.y,self.w,self.h)
        if not all(isinstance(v,(int,float)) and math.isfinite(float(v)) for v in vals): raise ValueError('nonfinite geometry')
        if self.w<=0 or self.h<=0: raise ValueError('invalid geometry')
        if len(self.text)>10000 or len(self.style)>64: raise ValueError('oversized element')
        return True

@dataclass
class DesignTemplate:
    template_id: str; name: str; category: str; width: int; height: int
    elements: list[DesignElement]=field(default_factory=list); slots: list[AssetSlot]=field(default_factory=list)
    tags: list[str]=field(default_factory=list); version: str='1.0'; adaptive: bool=True
    def validate(self):
        if not self.template_id or len(self.template_id)>96: raise ValueError('invalid template id')
        if not self.name or len(self.name)>200: raise ValueError('invalid template name')
        if self.width<64 or self.height<64 or self.width>16384 or self.height>16384: raise ValueError('invalid canvas')
        if len(self.elements)>MAX_ITEMS or len(self.slots)>MAX_ITEMS: raise ValueError('too many items')
        eids=set(); sids=set(); slotset=set()
        for s in self.slots:
            s.validate()
            if s.slot_id in sids: raise ValueError('duplicate slot id')
            sids.add(s.slot_id); slotset.add(s.slot_id)
        for e in self.elements:
            e.validate()
            if e.element_id in eids: raise ValueError('duplicate element')
            eids.add(e.element_id)
            if e.slot_id is not None and e.slot_id not in slotset: raise ValueError('unknown slot reference')
        return True
    def digest(self):
        self.validate(); raw=json.dumps(asdict(self),sort_keys=True,separators=(',',':'))
        return hashlib.sha256(raw.encode()).hexdigest()
    def to_dict(self): self.validate(); return asdict(self)

class TemplateLibrary:
    def __init__(self): self.templates={}
    def add(self,t): t.validate(); self.templates[t.template_id]=t; return t.digest()
    def get(self,template_id): return self.templates.get(template_id)
    def search(self,query,category=None,limit=20):
        if not isinstance(query,str) or len(query)>500: raise ValueError('invalid query')
        terms=set(re.findall(r'[a-z0-9]+',query.lower())); scored=[]
        for t in self.templates.values():
            if category and t.category!=category: continue
            corpus=set(re.findall(r'[a-z0-9]+',(t.name+' '+t.category+' '+' '.join(t.tags)).lower()))
            score=len(terms & corpus)
            if not terms: score=1
            if score: scored.append((score,t.template_id))
        return [self.templates[i] for _,i in sorted(scored,key=lambda x:(-x[0],x[1]))[:max(0,min(limit,100))]]

class AdaptiveLayoutEngine:
    def adapt(self,t,target_format,content=None):
        t.validate()
        if target_format not in FORMATS: raise ValueError('unsupported format')
        tw,th=FORMATS[target_format]; sx,sy=tw/t.width,th/t.height
        out=DesignTemplate(t.template_id+'@'+target_format,t.name,target_format,tw,th,adaptive=t.adaptive,tags=list(t.tags),version=t.version)
        out.slots=[AssetSlot(s.slot_id,s.kind,s.required,s.fit,s.safe_area) for s in t.slots]
        content=content if isinstance(content,dict) else {}
        for e in sorted(t.elements,key=lambda x:x.z):
            ne=DesignElement(e.element_id,e.kind,e.x*sx,e.y*sy,e.w*sx,e.h*sy,e.z,e.text,e.slot_id,dict(e.style),e.locked)
            ne.x=max(0,min(max(0,tw-ne.w),ne.x)); ne.y=max(0,min(max(0,th-ne.h),ne.y))
            if ne.kind=='text':
                val=content.get(ne.element_id, ne.text)
                if isinstance(val,str):
                    ne.text=val[:10000]
            out.elements.append(ne)
        out.validate(); return out
    def render_svg(self,t,content=None):
        t.validate(); content=content or {}; parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{t.width}" height="{t.height}" viewBox="0 0 {t.width} {t.height}">']
        for e in sorted(t.elements,key=lambda x:x.z):
            st=e.style or {}; opacity=st.get('opacity',1)
            if e.kind=='shape':
                fill=html.escape(str(st.get('fill','#111')),quote=True); parts.append(f'<rect x="{e.x:g}" y="{e.y:g}" width="{e.w:g}" height="{e.h:g}" fill="{fill}" opacity="{opacity}"/>')
            elif e.kind=='text':
                text=content.get(e.element_id,e.text) if isinstance(content.get(e.element_id,e.text),str) else e.text
                text=text.replace('{{TITLE}}',str(content.get('title','{{TITLE}}')))[:10000]
                fs=max(1,float(st.get('fontSize',40))); anchor=st.get('textAnchor','start')
                parts.append(f'<text x="{e.x:g}" y="{e.y+fs:g}" font-size="{fs:g}" text-anchor="{html.escape(str(anchor),quote=True)}">{html.escape(text)}</text>')
            elif e.kind in {'image','video','logo','icon'}:
                label=html.escape(e.slot_id or e.element_id,quote=True)
                parts.append(f'<rect x="{e.x:g}" y="{e.y:g}" width="{e.w:g}" height="{e.h:g}" fill="none" stroke="#888" stroke-dasharray="8 6"/><title>{label}</title>')
        parts.append('</svg>'); return ''.join(parts)

class DesignIntentPlanner:
    aliases={'thumbnail':'youtube_thumbnail','reel':'reel','story':'instagram_story','post':'instagram_post','poster':'poster','banner':'youtube_banner','square':'square'}
    categories={'logo':'branding','brand':'branding','thumbnail':'social','reel':'social','story':'social','poster':'print','invitation':'event','birthday':'event','quote':'social','banner':'social'}
    def plan(self,intent):
        if not isinstance(intent,str) or not intent.strip() or len(intent)>4000: raise ValueError('invalid intent')
        low=intent.lower(); fmt='instagram_post'; cat='general'
        for k,v in self.aliases.items():
            if re.search(r'\b'+re.escape(k)+r'\b',low): fmt=v; break
        for k,v in self.categories.items():
            if re.search(r'\b'+re.escape(k)+r'\b',low): cat=v; break
        return {'format':fmt,'category':cat,'query':re.sub(r'\s+',' ',intent.strip())[:120],'safe':True}

class Stage7ProviderRegistry:
    providers=[
      {'name':'local-svg-layout','capabilities':{'cpu'},'available':True,'license':'project/local','role':'deterministic template rendering'},
      {'name':'konva','capabilities':{'browser'},'available':True,'license':'MIT','role':'interactive canvas integration contract'},
      {'name':'fabricjs','capabilities':{'browser'},'available':True,'license':'MIT','role':'canvas object model integration contract'},
      {'name':'opendesign','capabilities':{'browser','cpu'},'available':True,'license':'MIT','role':'self-hosted editor integration reference'},
      {'name':'webmotion','capabilities':{'browser'},'available':True,'license':'open-source','role':'browser video composition integration contract'},
      {'name':'external-ai-character','capabilities':{'cloud'},'available':False,'license':'provider-dependent','role':'optional character generation'},
    ]
    def route(self,needs=(),capabilities=('cpu',)):
        needs=set(needs); caps=set(capabilities)
        candidates=[p for p in self.providers if needs.issubset(p['capabilities']) and p['available'] and p['capabilities'] & caps]
        return candidates[0] if candidates else self.providers[0]
    def availability(self): return [dict(p) for p in self.providers]

@dataclass
class CharacterMotionPlan:
    character_id:str; actions:list[dict[str,Any]]; duration_frames:int; fps:int=30; provider:str='local-procedural'
    def validate(self):
        if not self.character_id or len(self.character_id)>96: raise ValueError('invalid character')
        if not 1<=self.duration_frames<=10_000_000 or not 1<=self.fps<=240: raise ValueError('invalid timing')
        if len(self.actions)>1024: raise ValueError('too many actions')
        last=0
        for a in self.actions:
            if not isinstance(a,dict) or a.get('type') not in {'walk','run','jump','wave','talk','dance','idle','turn','camera_zoom'}: raise ValueError('invalid action')
            if not (0<=int(a.get('start',-1))<int(a.get('end',0))<=self.duration_frames): raise ValueError('invalid action timing')
            if int(a['start'])<last: raise ValueError('overlapping actions')
            last=int(a['end'])
        return True

class CharacterMotionPlanner:
    aliases={'walk':'walk','run':'run','jump':'jump','wave':'wave','talk':'talk','dance':'dance','idle':'idle','turn':'turn','zoom':'camera_zoom'}
    def plan(self,intent,duration_frames=90):
        if not isinstance(intent,str) or not intent.strip(): raise ValueError('invalid character intent')
        actions=[]; low=intent.lower(); cursor=0; step=max(1,duration_frames//max(1,sum(k in low for k in self.aliases)))
        for token,action in self.aliases.items():
            if re.search(r'\b'+re.escape(token)+r'\b',low) and action not in [x['type'] for x in actions]:
                end=min(duration_frames,cursor+step); actions.append({'type':action,'start':cursor,'end':end}); cursor=end
        if not actions: actions=[{'type':'idle','start':0,'end':duration_frames}]
        p=CharacterMotionPlan('character-1',actions,duration_frames); p.validate(); return p

class Stage7Pipeline:
    def __init__(self):
        self.library=TemplateLibrary(); self.layout=AdaptiveLayoutEngine(); self.intent=DesignIntentPlanner(); self.providers=Stage7ProviderRegistry(); self.character=CharacterMotionPlanner(); self._seed()
    def _seed(self):
        common=[AssetSlot('hero','image',True)]
        self.library.add(DesignTemplate('social-clean-01','Clean Social Post','social',1080,1080,[DesignElement('bg','shape',0,0,1080,1080,0,style={'fill':'#111'}),DesignElement('title','text',90,180,900,180,2,'{{TITLE}}',style={'fontSize':72}),DesignElement('hero','image',90,400,900,500,1,slot_id='hero')],common,tags=['social','post','clean','modern']))
        self.library.add(DesignTemplate('video-cover-01','Cinematic Video Cover','social',1080,1920,[DesignElement('hero','image',0,0,1080,1920,0,slot_id='hero'),DesignElement('title','text',70,1500,940,250,2,'{{TITLE}}',style={'fontSize':80})],common,tags=['reel','story','cinematic','video']))
        self.library.add(DesignTemplate('thumb-bold-01','Bold YouTube Thumbnail','social',1280,720,[DesignElement('hero','image',0,0,1280,720,0,slot_id='hero'),DesignElement('title','text',60,520,1160,130,2,'{{TITLE}}',style={'fontSize':64})],common,tags=['thumbnail','youtube','bold']))
        self.library.add(DesignTemplate('brand-minimal-01','Minimal Brand Card','branding',1080,1080,[DesignElement('logo','logo',120,120,300,300,1,slot_id='logo'),DesignElement('brand','text',120,500,840,160,2,'{{TITLE}}',style={'fontSize':70})],[AssetSlot('logo','logo',True)],tags=['logo','brand','minimal']))
        self.library.add(DesignTemplate('event-invite-01','Event Invitation','event',1080,1350,[DesignElement('bg','shape',0,0,1080,1350,0,style={'fill':'#171717'}),DesignElement('title','text',90,220,900,180,2,'{{TITLE}}',style={'fontSize':68}),DesignElement('hero','image',90,450,900,600,1,slot_id='hero')],common,tags=['invitation','birthday','event']))
    def process(self,intent,target_format=None,character_intent=None,content=None):
        spec=self.intent.plan(intent); fmt=target_format or spec['format']; matches=self.library.search(spec['query'],category=spec['category'],limit=5)
        if not matches: matches=self.library.search(spec['query'],category=None,limit=5)
        if not matches: matches=self.library.search('',category=None,limit=1)
        adapted=self.layout.adapt(matches[0],fmt,content or {'title':intent}) if matches else None
        motion=self.character.plan(character_intent) if character_intent else None
        provider=self.providers.route(capabilities=('cpu',))['name']
        return {'ok':bool(adapted),'intent':spec,'template_id':adapted.template_id if adapted else None,'template':adapted,'motion':motion,'provider':provider}
