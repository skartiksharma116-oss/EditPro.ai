# EditPro.ai Stage 8 — Final Scope

Stage 8 is the hardened **Full Compositing + 3D Scene Foundation** layer. It is local-first and does not require paid AI/cloud services.

## Included
- Deterministic scene graph with validated layers, assets, timing and serialization.
- 2D layer compositing: background, image, video, text, shapes, effects.
- Blend modes: normal, add, screen, multiply, overlay, darken, lighten.
- Transform system: position, depth, rotation fields, scale, opacity and anchors.
- Per-property keyframes with linear, step, ease-in, ease-out and ease-in-out interpolation.
- Mask foundation: rectangle, ellipse and polygon masks, inversion, feather metadata and raster alpha application.
- Chroma-key foundation with hue/tolerance/softness/spill controls and local pixel processing.
- Tracking interpolation and attachment of tracked coordinates to scene layers.
- 3D scene foundation: perspective projection, 3D layer placement, camera, FOV, camera motion keyframes and deterministic shake.
- Lighting foundation: ambient, directional and point lights with validated parameters.
- Particle foundation: dust, smoke, rain, snow, sparks, fog and fire-like particles with deterministic seeds.
- AI command → scene analysis → scene planner routing.
- Local image/video frame loading through FFmpeg when available.
- Local PNG raster rendering and local MP4 preview export.
- SVG deterministic renderer for lightweight previews/tests.
- Provider capability contracts for free/open-source browser paths including Three.js, PixiJS, WebMotion, OpenVideo and Elah. Optional providers never become hard runtime dependencies.
- Scene serialization round-trip and SHA-256 deterministic fingerprinting.

## Intentionally not included
These belong to later stages and are not falsely marked complete here:
- Photorealistic generative 3D character creation.
- Full cinematic director / autonomous cinematography.
- Professional audio studio/mastering.
- Meme Engine.
- Full asset-generation studio.
- Global style engine.
- Multi-AI tournament.

## Free/open-source strategy
The runtime is local-first. Optional browser integration contracts were reviewed against currently available open projects. WebMotion provides deterministic browser composition and a Three.js bridge; OpenVideo provides Pixi/WebCodecs composition; Elah provides a renderer-agnostic WebGL2/WebCodecs architecture. These are integration references, not mandatory downloads.
