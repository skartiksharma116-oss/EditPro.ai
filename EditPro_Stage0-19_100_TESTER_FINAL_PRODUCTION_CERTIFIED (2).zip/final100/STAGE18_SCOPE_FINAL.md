# EditPro Stage 18 - Extreme Scale, Performance & Infrastructure Hardening

## Mission
Make the Stage 0-17 system resilient under large projects, limited memory, GPU loss/OOM, long renders, queue saturation, crashes, cache pressure and heterogeneous hardware.

## Scope
- Resource-aware CPU/GPU scheduling and graceful degradation
- Memory/GPU-memory budgets, streaming and spill-to-disk contracts
- Content/render/model/proxy cache contracts and deterministic invalidation
- Large-project indexing, lazy loading, timeline chunking and partial recompute
- Chunked/resumable rendering with preflight validation
- Autosave, checkpoints, journals, rollback and crash recovery
- Local/remote worker boundaries, leases, retries, idempotency and result verification
- Health/latency/throughput/resource/error observability with privacy-safe telemetry
- CPU fallback plus AMD ROCm, NVIDIA CUDA, Apple Metal and Intel capability paths
- Resource isolation, sandbox/path validation, workspace quotas and secure temp boundaries
- Stress handling for queue saturation, disk full, memory exhaustion, GPU OOM, device loss and worker crashes
- Portable project/dependency/archive/restore validation

## Non-goals
No claim of actual external GPU/cloud execution. Real hardware/provider execution remains dependent on the runtime installed on the target machine.

## Integration rule
Stage 0-17 semantics remain frozen. Stage 18 consumes the Stage 17 handoff and adds a runtime-control/hardening contract above it.
