import json, tempfile
from pathlib import Path
from stage19_final_master import Stage19FinalMaster


def main():
    e=Stage19FinalMaster()
    health=e.production_health()
    assert health['ok']
    assert health['capabilities'] >= 500

    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        good=root/'good.mp4'; good.write_bytes(b'not-real-media-but-integrity-test')
        v=e.validate_file(good); assert v['ok'] and v['sha256']
        bad=root/'script.sh'; bad.write_text('echo unsafe'); assert not e.validate_file(bad)['ok']
        symlink=root/'link.mp4'
        symlink.symlink_to(good)
        assert not e.validate_file(symlink)['ok']
        try: e.safe_workspace_path(root,'../escape.json'); raise AssertionError('traversal accepted')
        except PermissionError: pass
        inside=e.safe_workspace_path(root,'projects/state.json'); assert str(inside).startswith(str(root))
        out=e.atomic_write_json(inside, {'ok':True,'count':3}); assert json.loads(out.read_text())=={'count':3,'ok':True}
        # Parser validation must reject syntactically invalid media even when hashing succeeds.
        assert not e.validate_media_file(good)['ok']
        assert not e.validate_media_file(root/'missing.mp4')['ok']
    print('PRODUCTION_HARDENING=PASS')

if __name__=='__main__': main()
