from .transcript import TranscriptEngine
from .captions import CaptionDirector
from .qa import CaptionCritic
from .router import SpeechRouter
from .commands import TextCommandPlanner

class Stage4Pipeline:
    def __init__(self):
        self.transcript=TranscriptEngine(); self.captions=CaptionDirector(); self.critic=CaptionCritic(); self.router=SpeechRouter(); self.commands=TextCommandPlanner()
    def run(self, raw_words, duration, language=None, speakers=None, visual_context=None, profile='clean', command=None, available=('cpu',)):
        if not isinstance(duration,(int,float)) or duration<=0 or duration!=duration: raise ValueError('invalid duration')
        plan=self.commands.plan(command) if command else {'actions':[],'confidence':1.0}
        for a in plan['actions']:
            if a['type']=='caption_style':profile=a['profile']
        tx=self.transcript.build(raw_words,language,duration,'stage4-router',speakers)
        caps=self.captions.direct(tx,visual_context,profile)
        qa=self.critic.review(caps,tx)
        route=self.router.choose(tx.language,available)
        return {'transcript':tx.to_dict(),'captions':[c.__dict__ for c in caps],'qa':qa,'provider_route':route.name,'command_plan':plan,'non_destructive':True}
