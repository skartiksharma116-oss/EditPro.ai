# Stage 4 stronger alternatives

EditPro.ai uses a capability router rather than locking Stage 4 to one AI model.

- Whisper large-v3-turbo: fast multilingual local baseline.
- Whisper large-v3: higher-quality/translation-capable Whisper fallback.
- Qwen3-ASR 1.7B/0.6B: modern multilingual open ASR alternatives with forced alignment support.
- NVIDIA Parakeet TDT: high-throughput English specialist.
- NVIDIA Canary-Qwen: English/multilingual specialist route.
- Cloud provider adapter: production cloud ASR fallback when enabled.
- SeamlessM4T v2 contract: multilingual speech/text translation route when enabled.

The router reports whether a runtime is actually installed. It never pretends optional model weights or cloud credentials exist.
