class TranslationEngine:
    """Provider-neutral translation layer. Supports Seamless-style speech/text translation contracts without requiring weights."""
    def normalize_request(self,source,target):
        s=str(source or '').strip().lower(); t=str(target or '').strip().lower()
        if not s or not t: raise ValueError('source and target language required')
        return {'source':s,'target':t,'mode':'identity' if s==t else 'provider_required'}
    def validate_result(self,text,source=None,target=None):
        if not isinstance(text,str) or not text.strip(): raise ValueError('empty translation')
        if len(text)>20000: raise ValueError('translation too large')
        return {'text':text.strip(),'source':source,'target':target,'warnings':[]}
    def select_provider(self,source,target,available=()):
        a=set(available or ())
        if source==target:return 'identity'
        if 'seamless' in a:return 'seamless-m4t-v2'
        if 'cloud' in a:return 'cloud-translation'
        return 'translation-unavailable'
