class CaptionCritic:
    def __init__(self,min_confidence=0.45,max_cps=40):
        self.min_confidence=float(min_confidence); self.max_cps=float(max_cps)
    def review(self,captions,transcript=None):
        issues=[]; fatal=[]; seen=set(); last=0.0
        for c in captions:
            if not c.text.strip(): fatal.append('empty_caption')
            if c.id in seen: fatal.append('duplicate_id')
            seen.add(c.id)
            if c.start<last-1e-6: fatal.append('non_monotonic_timing')
            if c.end<=c.start: fatal.append('invalid_timing')
            cps=len(c.text)/max(0.001,c.end-c.start)
            if cps>self.max_cps: issues.append('reading_speed_high')
            if c.line_count>2: fatal.append('too_many_lines')
            if not 0<=c.position.get('x',-1)<=1 or not 0<=c.position.get('y',-1)<=1: fatal.append('position_outside_frame')
            last=c.end
        if transcript and any(w.confidence<self.min_confidence for w in transcript.words): issues.append('human_review_low_confidence')
        issues=sorted(set(issues)); fatal=sorted(set(fatal))
        all_issues=sorted(set(issues+fatal))
        return {'ok':not fatal,'issues':all_issues,'fatal_issues':fatal,'warnings':issues,'action':'accept' if not fatal and not issues else ('accept_with_warnings' if not fatal else 'review_or_fix')}
