import hashlib, re
from .models import Caption, Transcript

class CaptionDirector:
    def __init__(self,max_chars=32,max_lines=2,max_duration=6.0):
        self.max_chars=max(12,int(max_chars)); self.max_lines=max(1,int(max_lines)); self.max_duration=max(1.0,float(max_duration))
    def _chunks(self, words):
        chunks=[]; cur=[]
        for w in words:
            candidate=' '.join(x.text for x in cur+[w])
            too_long=len(candidate)>self.max_chars*self.max_lines
            too_slow=cur and (w.end-cur[0].start)>self.max_duration
            natural=cur and re.search(r'[.!?,;:]$',cur[-1].text)
            if cur and (too_long or too_slow or natural): chunks.append(cur); cur=[]
            cur.append(w)
        if cur:chunks.append(cur)
        return chunks
    def _style(self, profile='clean', emphasis=False):
        profiles={'clean':{'font':'Inter','weight':600,'size':1.0,'animation':'none'},'cinematic':{'font':'Inter','weight':700,'size':1.0,'animation':'subtle'},'podcast':{'font':'Inter','weight':700,'size':1.05,'animation':'word_emphasis'},'high_energy':{'font':'Inter','weight':800,'size':1.05,'animation':'semantic_pop'}}
        s=dict(profiles.get(profile,profiles['clean']))
        if emphasis:s['emphasis']=True
        return s
    def direct(self, transcript:Transcript, visual_context=None, profile='clean', target=(9,16), bilingual=None):
        visual_context=visual_context or {}
        occupied=visual_context.get('occupied_zones',[])
        captions=[]
        for n,chunk in enumerate(self._chunks(transcript.words)):
            text=' '.join(w.text for w in chunk).strip()
            if not text:continue
            # Deterministic face/object-safe placement. Prefer bottom, then top, then side zones.
            positions=[{'x':0.5,'y':0.86},{'x':0.5,'y':0.16},{'x':0.25,'y':0.72},{'x':0.75,'y':0.72}]
            pos=positions[0]
            for p in positions:
                if not any(abs(p['x']-z.get('x',-9))<0.22 and abs(p['y']-z.get('y',-9))<0.18 for z in occupied):pos=p;break
            emph=tuple(w.text for w in chunk if w.emphasis>=0.5 or w.text.isupper() or any(c.isdigit() for c in w.text))
            style=self._style(profile,bool(emph))
            # Do not over-animate low confidence or quiet captions.
            if sum(w.confidence for w in chunk)/len(chunk)<0.65:style['animation']='none'
            digest=hashlib.sha256(f'{n}|{text}|{chunk[0].start:.6f}|{chunk[-1].end:.6f}'.encode()).hexdigest()[:16]
            captions.append(Caption('cap_'+digest,text,chunk[0].start,chunk[-1].end,max(1,min(self.max_lines,(len(text)+self.max_chars-1)//self.max_chars)),pos,style,emph,chunk[0].speaker,chunk[0].language))
        return captions
