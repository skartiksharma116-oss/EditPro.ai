import re
class TextCommandPlanner:
    def plan(self,command):
        c=str(command or '').strip().lower()
        if not c: return {'actions':[],'confidence':1.0}
        actions=[]
        if 'caption' in c or 'subtitle' in c: actions.append({'type':'generate_captions'})
        if 'cinematic' in c: actions.append({'type':'caption_style','profile':'cinematic'})
        if 'podcast' in c: actions.append({'type':'caption_style','profile':'podcast'})
        if 'high energy' in c or 'high-energy' in c: actions.append({'type':'caption_style','profile':'high_energy'})
        if 'smaller' in c: actions.append({'type':'caption_size','scale':0.85})
        if 'larger' in c: actions.append({'type':'caption_size','scale':1.15})
        if 'highlight' in c or 'important words' in c: actions.append({'type':'emphasize_keywords'})
        if 'remove filler' in c or 'remove um' in c or 'remove ums' in c: actions.append({'type':'remove_fillers'})
        if 'hindi' in c: actions.append({'type':'language','language':'hi'})
        if 'english' in c: actions.append({'type':'language','language':'en'})
        if 'bilingual' in c or 'two languages' in c: actions.append({'type':'bilingual'})
        if 'don\'t cover' in c or 'do not cover' in c or 'avoid face' in c: actions.append({'type':'avoid_faces'})
        if 'subtle' in c: actions.append({'type':'animation','mode':'subtle'})
        if 'no animation' in c or 'static' in c: actions.append({'type':'animation','mode':'none'})
        confidence=1.0 if actions else 0.25
        return {'actions':actions,'confidence':confidence}
