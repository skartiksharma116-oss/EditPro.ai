import re, hashlib
from .models import Word, Sentence, SpeakerSegment, Transcript

LANG_ALIASES={'en':'en','english':'en','hi':'hi','hindi':'hi','hinglish':'hi-en','bn':'bn','bengali':'bn','mr':'mr','marathi':'mr','ta':'ta','tamil':'ta','te':'te','telugu':'te','gu':'gu','gujarati':'gu','pa':'pa','punjabi':'pa','ur':'ur','urdu':'ur'}
FILLERS={'um','uh','umm','er','erm','like','you know'}
STOP={'the','a','an','is','are','was','were','to','of','and','or','in','on','for','with','this','that','it','we','i','you'}

class TranscriptEngine:
    def normalize_language(self, language):
        if language is None:return None
        return LANG_ALIASES.get(str(language).strip().lower(), str(language).strip().lower())

    def normalize_words(self, raw, duration=None, default_language=None):
        if raw is None:return []
        if not isinstance(raw,list): raise ValueError('words must be a list')
        out=[]; prev=0.0
        for item in raw:
            if not isinstance(item,dict): raise ValueError('word item must be object')
            text=str(item.get('text','')).strip()
            if not text: raise ValueError('word text required')
            s=float(item.get('start',item.get('start_time',0)))
            e=float(item.get('end',item.get('end_time',s+0.1)))
            conf=float(item.get('confidence',1.0))
            if not all(map(lambda x: x==x and abs(x)!=float('inf'),(s,e,conf))): raise ValueError('non-finite word')
            if s < 0 or e <= s or (duration is not None and e > float(duration)+1e-6): raise ValueError('word outside media')
            if s < prev-1e-6: raise ValueError('words must be chronologically ordered')
            out.append(Word(text,s,e,max(0,min(1,conf)),item.get('language') or default_language,item.get('speaker'),max(0,min(1,float(item.get('emphasis',0)))))); prev=e
        return out

    def sentenceize(self, words, language=None):
        if not words:return []
        groups=[]; current=[]
        for w in words:
            current.append(w)
            boundary=bool(re.search(r'[.!?]$',w.text)) or (len(current)>=14) or (current and w.end-current[0].start>=7.5)
            if boundary: groups.append(current); current=[]
        if current:groups.append(current)
        out=[]
        for g in groups:
            text=' '.join(w.text for w in g).strip()
            if text and text[-1] not in '.!?': text += '.'
            imp=self._importance(g)
            out.append(Sentence(text,g[0].start,g[-1].end,tuple(words.index(w) for w in g),sum(w.confidence for w in g)/len(g),g[0].speaker,language,imp))
        return out

    def _importance(self, words):
        vals=[]
        for w in words:
            t=re.sub(r'\W+','',w.text.lower())
            score=0.0
            if len(t)>=7: score+=0.25
            if t.isdigit() or any(c.isdigit() for c in t): score+=0.25
            if t not in STOP: score+=0.25
            if w.emphasis: score+=0.35*w.emphasis
            if w.text.isupper() and len(t)>1: score+=0.2
            vals.append(min(1,score))
        return max(vals) if vals else 0.0

    def detect_fillers(self, words):
        return [i for i,w in enumerate(words) if w.text.lower().strip('.,!?') in FILLERS]

    def search(self, transcript, query, semantic=False):
        q=str(query).strip().lower()
        if not q:return []
        exact=[i for i,w in enumerate(transcript.words) if q in w.text.lower()]
        if not semantic:return exact
        terms=set(re.findall(r'\w+',q)); hits=set(exact)
        for i,w in enumerate(transcript.words):
            if set(re.findall(r'\w+',w.text.lower())) & terms:hits.add(i)
        return sorted(hits)

    def build(self, raw_words, language=None, duration=None, provider='unknown', speakers=None):
        lang=self.normalize_language(language)
        words=self.normalize_words(raw_words,duration,lang)
        sentences=self.sentenceize(words,lang)
        sp=[]
        for x in speakers or []:
            if not isinstance(x,dict):continue
            try: sp.append(SpeakerSegment(str(x['speaker']),float(x['start']),float(x['end']),float(x.get('confidence',1))))
            except Exception: continue
        warnings=[]
        if any(w.confidence<0.55 for w in words):warnings.append('low_confidence_words')
        if self.detect_fillers(words):warnings.append('filler_candidates')
        return Transcript(words,sentences,sp,lang,warnings,provider)
