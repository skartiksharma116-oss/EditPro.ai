from dataclasses import dataclass

@dataclass(frozen=True)
class Provider:
    name:str; kind:str; languages:tuple[str,...]=(); quality:float=.5; speed:float=.5; timestamp:float=.5; diarization:float=.0; translation:float=.0
    available_if:tuple[str,...]=()

class SpeechRouter:
    """Capability-aware ASR/translation router. It never claims a provider is installed unless its runtime dependency is present."""
    def __init__(self):
        self.providers={
            'whisper-large-v3-turbo':Provider('whisper-large-v3-turbo','local',('en','hi','bn','mr','ta','te','gu','pa','ur'),.94,.90,.92,.0,.0,('transformers',)),
            'whisper-large-v3':Provider('whisper-large-v3','local',('en','hi','bn','mr','ta','te','gu','pa','ur'),.96,.72,.94,.0,.75,('transformers',)),
            'qwen3-asr-1.7b':Provider('qwen3-asr-1.7b','local',('en','hi','bn','mr','ta','te','gu','pa','ur'),.97,.84,.96,.0,.0,('transformers',)),
            'parakeet-tdt':Provider('parakeet-tdt','local',('en',),.97,.98,.95,.0,.0,('transformers',)),
            'canary-qwen':Provider('canary-qwen','local',('en','hi','de','fr','es','it','pt','ru','uk','zh','ja','ko'),.98,.80,.94,.0,.0,('transformers',)),
            'cloud-generic':Provider('cloud-generic','cloud',(),.97,.97,.97,.90,.90,('cloud',)),
        }
    def capability_report(self, available=()):
        a=set(map(str,available or ()))
        return {n:{'installed':p.kind=='cloud' and 'cloud' in a or p.kind=='local' and (set(p.available_if)&a or p.available_if==()),
                    'kind':p.kind,'quality':p.quality,'speed':p.speed,'timestamp':p.timestamp,'diarization':p.diarization,'translation':p.translation}
                for n,p in self.providers.items()}
    def choose(self,language=None,available=('cpu',),privacy='balanced',prefer_quality=True,needs=('asr',)):
        avail=set(available or ())
        needs=set(needs or ('asr',))
        candidates=[]
        for p in self.providers.values():
            installed=(p.kind=='cloud' and 'cloud' in avail) or (p.kind=='local' and ('cpu' in avail or any(x in avail for x in ('cuda','tensorrt','migraphx','openvino','directml','coreml','webgpu'))))
            if not installed or (p.kind=='cloud' and privacy=='local'): continue
            if language and p.languages and str(language).lower() not in p.languages and str(language).lower()!='hi-en': continue
            if 'diarization' in needs and p.diarization<=0: continue
            if 'translation' in needs and p.translation<=0: continue
            candidates.append(p)
        if not candidates:
            return self.providers['whisper-large-v3-turbo']
        def score(p):
            return ((p.quality if prefer_quality else p.speed)*.45 + p.timestamp*.2 + p.diarization*.15 + p.translation*.1 + p.speed*.1)
        return max(candidates,key=score)
    def choose_with_fallbacks(self, **kwargs):
        primary=self.choose(**kwargs)
        ordered=[primary]
        for p in sorted(self.providers.values(), key=lambda x:(x.quality,x.speed), reverse=True):
            if p.name not in {x.name for x in ordered}: ordered.append(p)
        return ordered
