from dataclasses import dataclass
import importlib.util

@dataclass(frozen=True)
class ASRConfig:
    model: str; device: str='cpu'; language: str|None=None; task: str='transcribe'; diarize: bool=False

class ASRProvider:
    name='abstract'
    def available(self): return False
    def transcribe(self,audio_path,config:ASRConfig): raise NotImplementedError

class OptionalTransformersASR(ASRProvider):
    def __init__(self,model_id,name=None): self.model_id=model_id; self.name=name or model_id
    def available(self): return importlib.util.find_spec('transformers') is not None
    def transcribe(self,audio_path,config):
        if not self.available(): raise RuntimeError('transformers_not_installed')
        raise RuntimeError(f'model_runtime_not_enabled:{self.model_id}')

class Qwen3ASR(OptionalTransformersASR):
    """Adapter contract for Qwen3-ASR + forced alignment. Runtime remains optional."""
    pass

class WhisperASR(OptionalTransformersASR):
    pass

class ASRRegistry:
    def __init__(self):
        self.providers={
            'whisper-large-v3-turbo':WhisperASR('openai/whisper-large-v3-turbo','whisper-large-v3-turbo'),
            'whisper-large-v3':WhisperASR('openai/whisper-large-v3','whisper-large-v3'),
            'qwen3-asr-1.7b':Qwen3ASR('Qwen/Qwen3-ASR-1.7B','qwen3-asr-1.7b'),
            'qwen3-asr-0.6b':Qwen3ASR('Qwen/Qwen3-ASR-0.6B','qwen3-asr-0.6b'),
            'parakeet-tdt':OptionalTransformersASR('nvidia/parakeet-tdt-0.6b-v3','parakeet-tdt'),
            'canary-qwen':OptionalTransformersASR('nvidia/canary-qwen-2.5b','canary-qwen'),
        }
    def get(self,name): return self.providers.get(name)
    def availability(self): return {n:p.available() for n,p in self.providers.items()}
