from dataclasses import dataclass, field, asdict
from typing import Any

@dataclass(frozen=True)
class Word:
    text: str
    start: float
    end: float
    confidence: float = 1.0
    language: str | None = None
    speaker: str | None = None
    emphasis: float = 0.0
    def __post_init__(self):
        if not isinstance(self.text,str) or not self.text.strip(): raise ValueError('word text required')
        if not all(isinstance(x,(int,float)) for x in (self.start,self.end)) or self.start < 0 or self.end <= self.start: raise ValueError('invalid word timing')
        if not 0 <= float(self.confidence) <= 1: raise ValueError('invalid confidence')
        if not 0 <= float(self.emphasis) <= 1: raise ValueError('invalid emphasis')

@dataclass(frozen=True)
class Sentence:
    text: str
    start: float
    end: float
    word_indexes: tuple[int,...] = ()
    confidence: float = 1.0
    speaker: str | None = None
    language: str | None = None
    importance: float = 0.0
    def __post_init__(self):
        if not isinstance(self.text,str): raise ValueError('sentence text required')
        if self.start < 0 or self.end <= self.start: raise ValueError('invalid sentence timing')
        if not 0 <= self.confidence <= 1: raise ValueError('invalid confidence')
        if not 0 <= self.importance <= 1: raise ValueError('invalid importance')

@dataclass(frozen=True)
class SpeakerSegment:
    speaker: str
    start: float
    end: float
    confidence: float = 1.0
    def __post_init__(self):
        if not self.speaker or self.start < 0 or self.end <= self.start: raise ValueError('invalid speaker segment')
        if not 0 <= self.confidence <= 1: raise ValueError('invalid confidence')

@dataclass
class Transcript:
    words: list[Word] = field(default_factory=list)
    sentences: list[Sentence] = field(default_factory=list)
    speakers: list[SpeakerSegment] = field(default_factory=list)
    language: str | None = None
    warnings: list[str] = field(default_factory=list)
    provider: str = 'unknown'
    def to_dict(self):
        return asdict(self)

@dataclass(frozen=True)
class Caption:
    id: str
    text: str
    start: float
    end: float
    line_count: int
    position: dict[str,float]
    style: dict[str,Any]
    emphasis_words: tuple[str,...] = ()
    speaker: str | None = None
    language: str | None = None
    confidence: float = 1.0
