import json, time, math
from editpro_pipeline import EditProPipeline

def main():
    app=EditProPipeline(); start=time.time(); passed=0
    for i in range(1000):
        media={'duration':(i%300)+0.5,'width':16+(i*37)%9000,'height':16+(i*53)%9000,'fps':(-100 if i%31==0 else 9999 if i%47==0 else 24+(i%4)*6)}
        speech={'transcript':[{'text':'hello','start':0,'end':0.2},{'text':'bad','start':-5,'end':99},{'text':'ok','start':0.3,'end':0.5}], 'beats':[0.1,float('nan'),99999]}
        out=app.run_from_signals(media,intent='make a premium cinematic reel',target_format='reel',speech=speech)
        assert out['ok'] and out['stages']['19']['inspection']['ok']
        assert out['stages']['19']['handoff']['stage']==19
        passed+=1
    print(json.dumps({'0_to_19_signal_stress_pass':passed,'seconds':round(time.time()-start,3)}))
if __name__=='__main__': main()
