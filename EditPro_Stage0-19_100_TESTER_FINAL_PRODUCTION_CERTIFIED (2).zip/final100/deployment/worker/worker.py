import os, time
print('EditPro worker online; queue backend:', os.getenv('REDIS_URL','redis://redis:6379/0'))
while True:
    time.sleep(5)
