from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
from pathlib import Path
import os, uuid, time, hashlib, json

APP_VERSION='19.2-production-deployment'
app=FastAPI(title='EditPro.ai Production Gateway', version=APP_VERSION)
DATA=Path(os.getenv('EDITPRO_DATA_DIR','/tmp/editpro-data')); DATA.mkdir(parents=True, exist_ok=True)
JOBS={}; PROJECTS={}

class Project(BaseModel):
    name: str

class Job(BaseModel):
    project_id: str
    operation: str
    payload: dict = {}

@app.get('/health/live')
def live(): return {'ok':True,'version':APP_VERSION}

@app.get('/health/ready')
def ready():
    return {'ok': True, 'checks': {'storage': DATA.exists() and DATA.is_dir(), 'python': True}}

@app.post('/v1/projects')
def create_project(p: Project):
    pid=str(uuid.uuid4()); PROJECTS[pid]={'id':pid,'name':p.name,'created_at':time.time()}; return PROJECTS[pid]

@app.post('/v1/assets/upload')
def upload_asset(file: UploadFile = File(...)):
    ext=Path(file.filename or '').suffix.lower()
    allowed={'.mp4','.mov','.mxf','.mkv','.avi','.webm','.mts','.m2ts','.ts','.m4v','.wav','.aiff','.aif','.flac','.aac','.m4a','.mp3','.png','.jpg','.jpeg','.webp','.heif','.heic','.tif','.tiff','.exr','.psd','.psb','.svg','.pdf'}
    if ext not in allowed: raise HTTPException(415,'Unsupported media type')
    aid=str(uuid.uuid4()); target=DATA/(aid+ext)
    h=hashlib.sha256(); total=0
    with target.open('wb') as out:
        while True:
            chunk=file.file.read(1024*1024)
            if not chunk: break
            total += len(chunk)
            if total > 50*1024*1024*1024:
                target.unlink(missing_ok=True); raise HTTPException(413,'Asset exceeds 50 GB limit')
            h.update(chunk); out.write(chunk)
    return {'asset_id':aid,'filename':file.filename,'bytes':total,'sha256':h.hexdigest()}

@app.post('/v1/jobs')
def create_job(j: Job):
    if j.project_id not in PROJECTS: raise HTTPException(404,'Project not found')
    jid=str(uuid.uuid4()); JOBS[jid]={'id':jid,'status':'queued','project_id':j.project_id,'operation':j.operation,'payload':j.payload,'created_at':time.time()}; return JOBS[jid]

@app.get('/v1/jobs/{job_id}')
def job(job_id:str):
    if job_id not in JOBS: raise HTTPException(404,'Job not found')
    return JOBS[job_id]
