import concurrent.futures, urllib.request, json, time
URL='http://127.0.0.1:8080/health/live'

def one(_):
    try:
        with urllib.request.urlopen(URL,timeout=10) as r: return r.status==200
    except Exception: return False

if __name__=='__main__':
    # Run against a staging endpoint. This is intentionally external so it does not
    # pretend the current machine is a 100-user production environment.
    with concurrent.futures.ThreadPoolExecutor(max_workers=100) as ex:
        results=list(ex.map(one, range(1000)))
    print('1000 health requests:',sum(results),'PASS /',len(results))
