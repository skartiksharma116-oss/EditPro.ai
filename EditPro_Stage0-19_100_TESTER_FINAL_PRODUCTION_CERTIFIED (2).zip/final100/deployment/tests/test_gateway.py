from fastapi.testclient import TestClient
import sys
sys.path.insert(0,'../api')
from app import app

client=TestClient(app)

def test_health():
    r=client.get('/health/live'); assert r.status_code==200 and r.json()['ok']
    r=client.get('/health/ready'); assert r.status_code==200 and r.json()['ok']

def test_project_and_job():
    p=client.post('/v1/projects',json={'name':'100 tester test'}); assert p.status_code==200
    pid=p.json()['id']
    j=client.post('/v1/jobs',json={'project_id':pid,'operation':'analyze','payload':{}}); assert j.status_code==200
    assert client.get('/v1/jobs/'+j.json()['id']).status_code==200

def test_upload_reject():
    r=client.post('/v1/assets/upload',files={'file':('bad.exe',b'123','application/octet-stream')}); assert r.status_code==415
