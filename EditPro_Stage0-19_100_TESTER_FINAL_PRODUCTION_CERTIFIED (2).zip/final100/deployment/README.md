# EditPro.ai 100-Tester Production Infrastructure

This is the deployment infrastructure layer for the Stage 0–19 application build.

## Topology
- Nginx: public TLS/reverse-proxy edge (put a managed TLS certificate in front in cloud deployment)
- FastAPI API: 2 workers by default
- Redis: queue/cache boundary
- PostgreSQL: durable metadata/project database
- MinIO/S3-compatible object storage: media/assets
- Worker: isolated FFmpeg/AI execution boundary

## 100 tester target
The architecture is intentionally separated so web/API traffic does not compete directly with render/AI work. For a real cloud deployment, scale API horizontally and scale workers according to CPU/GPU capacity. Do not expose PostgreSQL, Redis, or object-storage admin ports publicly.

## Before public exposure
1. Replace every example secret.
2. Put HTTPS/TLS at the edge.
3. Use managed Postgres/Redis/object storage or private-network equivalents.
4. Enable backups and test restore.
5. Configure authentication, rate limits, WAF/CDN, logs and alerting.
6. Configure AI/provider credentials only in server-side secret storage.
7. Run the included load/security tests against staging.

## Important
This repository cannot provision your cloud account, DNS, domain, GPU machines, paid AI providers, or certificates without access/credentials. The infrastructure configuration is prepared, but those external resources must be created in the target provider.
