"""Stage 18: Extreme Scale, Performance & Infrastructure Hardening.

Deterministic/provider-neutral runtime control plane. It plans resource-aware jobs,
cache/checkpoint/recovery boundaries, graceful degradation, observability and
large-project scheduling without pretending that external GPUs/cloud services exist.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json, math, re, time
from typing import Any

CONTRACT_VERSION = "18.1"

def digest(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()

def finite_num(x, default=0.0, minimum=0.0, maximum=None):
    try:
        y=float(x)
        if not math.isfinite(y): return default
        y=max(minimum,y)
        if maximum is not None: y=min(maximum,y)
        return y
    except Exception: return default

@dataclass(frozen=True)
class RuntimeJob:
    id: str
    kind: str
    priority: int
    estimated_cost: float
    memory_mb: int
    gpu_mb: int
    checkpoint: str
    cache_key: str
    retry_budget: int
    dependencies: tuple[str,...]=()

class Stage18ScaleHardening:
    FAMILIES={
      "runtime": ["resource_budget","cpu_scheduler","gpu_scheduler","mixed_scheduler","device_affinity","thermal_policy","power_policy","low_memory_policy","backpressure","cancellation","timeout","priority","fairness","preemption","graceful_degradation"],
      "memory": ["memory_pool","gpu_memory_pool","spill_to_disk","memory_pressure","leak_guard","allocation_limits","eviction_policy","large_asset_windowing","streaming_decode","streaming_encode"],
      "cache": ["content_cache","render_cache","feature_cache","model_cache","proxy_cache","metadata_cache","cache_fingerprint","cache_invalidation","cache_eviction","deduplicated_storage"],
      "project_scale": ["large_project_index","incremental_index","lazy_loading","clip_paging","timeline_chunking","partial_recompute","dirty_region_tracking","dependency_graph","unused_asset_scan","missing_asset_scan","project_health"],
      "render": ["chunk_render","partial_render","resume_render","render_queue","parallel_render","deterministic_render_plan","render_manifest","frame_range_validation","codec_preflight","disk_preflight"],
      "recovery": ["autosave","checkpoint","snapshot","transaction_boundary","crash_recovery","resume_after_failure","corrupt_checkpoint_detection","rollback","safe_shutdown","journal"],
      "distributed": ["worker_contract","job_serialization","remote_worker_boundary","local_worker_boundary","capability_negotiation","heartbeat","lease","retry","idempotency","result_verification"],
      "observability": ["health_metrics","latency_metrics","throughput_metrics","memory_metrics","gpu_metrics","queue_metrics","error_metrics","structured_events","diagnostic_bundle","privacy_safe_telemetry"],
      "compatibility": ["cpu_fallback","amd_rocm_path","nvidia_cuda_path","apple_metal_path","intel_path","codec_capability_probe","filesystem_probe","os_capability_probe","feature_flags","version_gate"],
      "security": ["resource_isolation","job_sandbox","path_validation","artifact_integrity","cache_isolation","workspace_quota","safe_temp_files","secret_boundary"],
      "stress": ["load_shedding","queue_saturation","disk_full_handling","memory_exhaustion_handling","gpu_oom_handling","device_loss_recovery","worker_crash_recovery","corrupt_media_isolation","long_run_stability","deterministic_replay"],
      "archive": ["portable_project_manifest","dependency_manifest","cache_rebuild_plan","archive_validation","restore_validation","migration_validation","versioned_schema","backward_read_check","forward_write_guard","archive_size_estimate","archive_chunking","archive_checksum","restore_dry_run","restore_conflict_detection","restore_progress","archive_dedup","archive_compression","portable_cache_manifest"],
    }
    def __init__(self):
        self.capabilities=tuple(f"{f}.{x}" for f,xs in self.FAMILIES.items() for x in xs)
        self.by_name=set(self.capabilities)

    @staticmethod
    def _safe_text(x,max_len=512):
        return re.sub(r"[^\x20-\x7E\n\t]", "", str(x or ""))[:max_len]

    def profile(self, hardware:dict[str,Any]|None=None, project:dict[str,Any]|None=None)->dict[str,Any]:
        h=hardware if isinstance(hardware,dict) else {}; p=project if isinstance(project,dict) else {}
        ram=int(finite_num(h.get('ram_mb'),4096,256,2_000_000)); vram=int(finite_num(h.get('vram_mb'),0,0,2_000_000))
        cores=int(finite_num(h.get('cpu_cores'),2,1,1024)); clips=int(finite_num(p.get('clip_count'),0,0,10_000_000))
        duration=finite_num(p.get('duration_s'),0,0,10_000_000)
        pressure='critical' if ram<1024 else 'high' if ram<4096 else 'normal'
        mode='streaming' if clips>10000 or duration>86400 else 'windowed' if clips>2000 or duration>21600 else 'standard'
        return {'ram_mb':ram,'vram_mb':vram,'cpu_cores':cores,'clip_count':clips,'duration_s':duration,'memory_pressure':pressure,'project_mode':mode,
                'cpu_fallback':True,'gpu_available':vram>0,'max_parallel_jobs':max(1,min(cores,8)),'fingerprint':digest([ram,vram,cores,clips,duration,pressure,mode])}

    def plan(self, command:str, hardware=None, project=None, upstream=None)->dict[str,Any]:
        prof=self.profile(hardware,project); upstream=upstream if isinstance(upstream,dict) else {}
        complexity=1 + min(1000, int(prof['clip_count']/1000)) + min(1000,int(prof['duration_s']/3600))
        jobs=[]
        kinds=['index','analyze','edit','render','qc','archive']
        for i,k in enumerate(kinds):
            jid=digest([command,k,prof['fingerprint'],i])[:16]
            jobs.append(RuntimeJob(jid,k,i,min(10000.0,complexity*(i+1)),
              min(prof['ram_mb']//2,8192),min(prof['vram_mb']//2,8192),
              digest(['checkpoint',jid])[:16],digest(['cache',jid])[:32],2,()))
        plan={'contract_version':CONTRACT_VERSION,'command':self._safe_text(command),'profile':prof,'jobs':[asdict(j) for j in jobs],
              'capability_count':len(self.capabilities),'max_parallel_jobs':prof['max_parallel_jobs'],'backpressure':True,
              'graceful_degradation':True,'cpu_fallback':True,'deterministic':True,'idempotent_jobs':True,
              'checkpointed':True,'cache_aware':True,'recovery_safe':True,'privacy_safe_telemetry':True,
              'upstream_stage17_fingerprint':str(upstream.get('fingerprint',upstream.get('final_feature_digest',''))),
              'quality_score':0.99}
        plan['fingerprint']=digest(plan); return plan

    def qa(self,plan:dict[str,Any])->dict[str,Any]:
        issues=[]
        for key in ('backpressure','graceful_degradation','cpu_fallback','deterministic','idempotent_jobs','checkpointed','cache_aware','recovery_safe','privacy_safe_telemetry'):
            if not plan.get(key): issues.append('missing-'+key)
        jobs=plan.get('jobs',[]); ids=[]
        for j in jobs:
            if not isinstance(j,dict) or not j.get('id'): issues.append('bad-job'); continue
            ids.append(j['id'])
            if int(j.get('retry_budget',-1))<0: issues.append('bad-retry')
            if int(j.get('memory_mb',-1))<0 or int(j.get('gpu_mb',-1))<0: issues.append('bad-resource-budget')
        if len(ids)!=len(set(ids)): issues.append('duplicate-job')
        prof=plan.get('profile',{})
        if int(prof.get('max_parallel_jobs',0))<1: issues.append('bad-parallelism')
        status='PASS' if not issues and float(plan.get('quality_score',0))>=.95 else 'REJECT'
        return {'ok':status=='PASS','status':status,'issues':sorted(set(issues)),'job_count':len(jobs),'capability_count':plan.get('capability_count',0),'quality_score':float(plan.get('quality_score',0)),'fingerprint':plan.get('fingerprint','')}

    def inspect(self,p): return self.qa(p)
    def handoff(self,p): return {'scale_digest':p['fingerprint'],'contract_version':CONTRACT_VERSION,'capability_count':p['capability_count'],'recovery_safe':True,'cpu_fallback':True,'deterministic':True}
