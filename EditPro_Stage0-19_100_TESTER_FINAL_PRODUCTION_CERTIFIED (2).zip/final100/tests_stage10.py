from stage10_audio import *
import random, tempfile, wave, struct, os, subprocess, json

def main():
    rng=random.Random(10)
    p=Stage10Pipeline(); checks=0
    for i in range(20000):
        dur=rng.uniform(.1,1800)
        mood=rng.choice(['cinematic','emotional','energetic','calm','luxury'])
        cmd=f'make a {mood} cinematic reel with music and dialogue'
        speech=[{'start':0.1,'end':min(dur,.9),'text':'hello world','confidence':.9}] if dur>.2 else []
        beats=[0.0, .5, 1.0] if dur>1 else []
        plan=p.plan(cmd,audio={'duration':dur,'sample_rate':48000,'channels':2,'bpm':rng.uniform(60,180)},transcript=speech,beats=beats)
        assert plan.validate() is None
        assert p.inspect(plan)['ok']
        assert plan.digest==MixPlanner.digest(plan)
        checks+=1
    # malformed boundaries
    bad=[{}, {'start':'x','end':1},{'start':-1,'end':2},{'start':2,'end':1},{'start':0,'end':999999,'confidence':2}]
    for b in bad:
        a=p.analyze('dialogue audio',audio={'duration':3},transcript=[b])
        assert all(s.start>=0 and s.end>s.start for s in a['speech'])
        checks+=1
    # deterministic repeated digest
    a={'duration':42,'sample_rate':48000,'channels':2,'bpm':128}
    d=[]
    for _ in range(1000): d.append(p.plan('premium cinematic beat edit',audio=a,beats=[0,0.46875,0.9375]).digest)
    assert len(set(d))==1; checks+=1000
    # real wav fixture
    with tempfile.TemporaryDirectory() as td:
        path=os.path.join(td,'tone.wav')
        with wave.open(path,'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(48000)
            frames=b''.join(struct.pack('<h', int(12000*__import__('math').sin(2*__import__('math').pi*440*i/48000))) for i in range(48000))
            w.writeframes(frames)
        info=AudioAnalyzer.probe(path); assert info['ok'] and .9<info['duration']<1.1 and info['sample_rate']==48000; checks+=1
        cmd=AudioRenderer.command(path,os.path.join(td,'out.m4a')); assert 'loudnorm' in cmd[cmd.index('-af')+1]; checks+=1
        try:
            subprocess.run(cmd,capture_output=True,timeout=15,check=True)
            assert os.path.exists(os.path.join(td,'out.m4a')); checks+=1
        except Exception as e:
            print('ffmpeg render skipped/fail',e)
    print(f'STAGE10_STRESS_PASS checks={checks}')
if __name__=='__main__': main()
