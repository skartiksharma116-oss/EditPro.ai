"""Production speech worker: local FFmpeg audio facts + optional real HTTP transcription provider."""
from __future__ import annotations
import json, os, subprocess, tempfile, urllib.request
from dataclasses import dataclass, asdict
from pathlib import Path

@dataclass
class SpeechResult:
    provider: str
    transcript: list
    language: str | None
    audio_duration: float
    speech_ratio: float
    warnings: list

class SpeechWorker:
    def __init__(self, endpoint=None, api_key=None, timeout=30):
        self.endpoint = endpoint or os.getenv('SPEECH_API_URL')
        self.api_key = api_key or os.getenv('SPEECH_API_KEY')
        self.timeout = timeout
        self._audio_cache = {}

    def analyze_audio(self, path):
        key=(str(path), os.path.getmtime(path) if os.path.exists(path) else None, os.path.getsize(path) if os.path.exists(path) else None)
        if key in self._audio_cache: return self._audio_cache[key]
        cmd=['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(path)]
        try:
            r=subprocess.run(cmd,capture_output=True,text=True,timeout=self.timeout)
            duration=float(r.stdout.strip() or 0) if r.returncode==0 else 0.0
        except (subprocess.TimeoutExpired, OSError, ValueError):
            duration=0.0
        # Real audio signal analysis through FFmpeg. This does not pretend silence is speech.
        cmd=['ffmpeg','-hide_banner','-nostats','-i',str(path),'-af','silencedetect=noise=-35dB:d=0.25','-f','null','-']
        try:
            r=subprocess.run(cmd,capture_output=True,text=True,timeout=self.timeout)
        except (subprocess.TimeoutExpired, OSError):
            self._audio_cache[key]=(duration,0.0)
            return duration,0.0
        import re
        sil=0.0
        starts=[]; ends=[]
        for line in (r.stderr or '').splitlines():
            m=re.search(r'silence_start: ([0-9.]+)',line)
            if m: starts.append(float(m.group(1)))
            m=re.search(r'silence_end: ([0-9.]+)',line)
            if m: ends.append(float(m.group(1)))
        for a,b in zip(starts,ends): sil += max(0,b-a)
        ratio=0.0 if duration<=0 else max(0.0,min(1.0,1-sil/duration))
        self._audio_cache[key]=(duration,ratio)
        return duration,ratio

    def transcribe(self,path):
        duration,ratio=self.analyze_audio(path)
        if not self.endpoint:
            return SpeechResult('audio-signal-fallback',[],None,duration,ratio,['no_speech_provider_configured'])
        # Generic multipart upload, compatible with a simple HTTP transcription service.
        boundary='----EditProBoundary'
        data=Path(path).read_bytes(); name=Path(path).name
        body=(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{name}"\r\nContent-Type: application/octet-stream\r\n\r\n').encode()+data+f'\r\n--{boundary}--\r\n'.encode()
        req=urllib.request.Request(self.endpoint,data=body,method='POST',headers={'Content-Type':f'multipart/form-data; boundary={boundary}','Authorization':f'Bearer {self.api_key}' if self.api_key else ''})
        try:
            with urllib.request.urlopen(req,timeout=self.timeout) as resp:
                payload=json.loads(resp.read().decode())
            tx=payload.get('transcript',[])
            if not isinstance(tx,list): raise ValueError('invalid transcript shape')
            lang=payload.get('language')
            return SpeechResult('http-speech',tx,lang,duration,ratio,[])
        except Exception as e:
            return SpeechResult('audio-signal-fallback',[],None,duration,ratio,[f'speech_provider_error:{type(e).__name__}'])
