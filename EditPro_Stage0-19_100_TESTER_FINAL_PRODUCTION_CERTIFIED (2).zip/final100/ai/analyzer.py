from dataclasses import dataclass, asdict
import json, subprocess
from .validation import clean_meta, clean_interval, finite_number

@dataclass
class Moment:
    start: float; end: float; kind: str; score: float; reason: str

@dataclass
class VideoMap:
    duration: float; fps: float; width: int; height: int; scenes: list; moments: list; edit_opportunities: list

class VideoUnderstandingEngine:
    def analyze(self, meta, transcript=None, scenes=None):
        meta = clean_meta(meta)
        duration, fps, width, height = meta['duration'], meta['fps'], meta['width'], meta['height']
        tx = transcript if isinstance(transcript, list) else []
        moments = []
        for t in tx:
            if not isinstance(t, dict):
                continue
            text = str(t.get('text', '')).strip()
            if not text:
                continue
            s, e = clean_interval(t.get('start', 0), t.get('end', t.get('start', 0)), duration)
            if e <= s:
                continue
            score = min(1.0, .35 + len(text.split()) / 40)
            kind = 'emphasis' if any(w in text.lower() for w in ('important','never','always','however','but')) else 'speech'
            moments.append(asdict(Moment(s, e, kind, round(score, 3), 'Transcript content detected')))

        safe_scenes = []
        raw_scenes = scenes if isinstance(scenes, list) else []
        for idx, s in enumerate(raw_scenes, 1):
            if not isinstance(s, dict):
                continue
            a, b = clean_interval(s.get('start', 0), s.get('end', 0), duration)
            if b <= a:
                continue
            safe_scenes.append({'id': s.get('id', idx), 'start': a, 'end': b, 'label': str(s.get('label', f'scene_{idx}'))[:200]})
        if not safe_scenes and duration:
            safe_scenes = [{'id': 1, 'start': 0.0, 'end': duration, 'label': 'scene_1'}]

        opp = []
        if duration:
            opp.append({'type':'hook','start':0.0,'end':min(3.0,duration),'score':.70,'reason':'Opening can be evaluated as a hook.'})
        for m in moments:
            if m['kind'] == 'emphasis' and m['score'] >= .7:
                opp.append({'type':'emphasize','start':m['start'],'end':m['end'],'score':m['score'],'reason':'Strong spoken emphasis.'})
        for s in safe_scenes:
            if s['end'] - s['start'] > 8:
                opp.append({'type':'pacing_review','start':s['start'],'end':s['end'],'score':.55,'reason':'Long uninterrupted shot; review pacing.'})
        if width and height:
            ratio = width / height
            if ratio < .75 or ratio > 1.9:
                opp.append({'type':'reframe_review','start':0.0,'end':duration,'score':.60,'reason':'Aspect ratio may benefit from smart reframing.'})
        return VideoMap(duration, fps, width, height, safe_scenes, moments, opp)

def analyze_file(path, transcript=None):
    r = subprocess.run(
        ['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,duration','-of','json',path],
        capture_output=True, text=True, timeout=30
    )
    if r.returncode:
        raise RuntimeError('ffprobe could not read media')
    try:
        streams = json.loads(r.stdout).get('streams', [])
        if not streams:
            raise ValueError('No video stream')
        d = streams[0]
        a, b = map(float, str(d.get('r_frame_rate','0/1')).split('/'))
        fps = a/b if b else 0
        return VideoUnderstandingEngine().analyze({'width':d.get('width',0),'height':d.get('height',0),'fps':fps,'duration':d.get('duration',0)}, transcript)
    except (ValueError, TypeError, ZeroDivisionError, json.JSONDecodeError) as e:
        raise RuntimeError('Invalid ffprobe media metadata') from e
