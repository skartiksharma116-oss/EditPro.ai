from dataclasses import dataclass, asdict

SUPPORTED_STYLES = {'balanced','fast','cinematic','social','clean'}
@dataclass
class EditAction:
    action: str; start: float; end: float; priority: int; reason: str; params: dict

class EditingDirector:
    def plan(self, video_map, style='balanced'):
        style = style if style in SUPPORTED_STYLES else 'balanced'
        out=[]
        opp = video_map.edit_opportunities if hasattr(video_map,'edit_opportunities') else video_map.get('edit_opportunities',[])
        for o in opp:
            if not isinstance(o, dict): continue
            t=o.get('type')
            if t=='hook': out.append(EditAction('hook_review',o['start'],o['end'],2,o['reason'],{'style':style}))
            elif t=='emphasize': out.append(EditAction('emphasis',o['start'],o['end'],1,o['reason'],{'caption':True,'zoom_hint':True}))
            elif t=='pacing_review': out.append(EditAction('pacing_review',o['start'],o['end'],3,o['reason'],{'cut_candidate':True}))
            elif t=='reframe_review': out.append(EditAction('smart_reframe',o['start'],o['end'],2,o['reason'],{'target':'9:16|1:1|16:9'}))
        out.sort(key=lambda x:(x.priority,x.start))
        return {'version':1,'style':style,'actions':[asdict(x) for x in out],'safety':{'source_preserved':True,'destructive':False},'warnings':[]}
