"""Production-shaped AI provider contracts with safe fallbacks.
Actual model/cloud credentials are intentionally external to Stage 2.
"""
from dataclasses import dataclass
from time import monotonic

@dataclass
class ProviderResult:
    ok: bool
    data: dict
    provider: str
    latency_ms: float
    error: str | None = None

class SafeProvider:
    def __init__(self, name, fn=None, timeout_s=20.0):
        self.name, self.fn, self.timeout_s = name, fn, timeout_s
        self.failures = 0

    def run(self, payload):
        t = monotonic()
        try:
            if self.fn is None:
                return ProviderResult(False, {}, self.name, (monotonic()-t)*1000, 'provider_not_configured')
            data = self.fn(payload)
            if not isinstance(data, dict):
                raise TypeError('provider must return dict')
            self.failures = 0
            return ProviderResult(True, data, self.name, (monotonic()-t)*1000)
        except Exception as e:
            self.failures += 1
            return ProviderResult(False, {}, self.name, (monotonic()-t)*1000, type(e).__name__)
