"""Optional model-runtime capability detection with truthful fallbacks.
Prefers NVIDIA CUDA/TensorRT and AMD MIGraphX when available; CPU remains the safe fallback.
"""
from __future__ import annotations
import importlib.util
from dataclasses import dataclass

@dataclass(frozen=True)
class ModelRuntime:
    backend: str
    available: bool
    reason: str

def detect_model_runtimes():
    out=[]
    # CPU is always the baseline.
    out.append(ModelRuntime('cpu',True,'baseline'))
    if importlib.util.find_spec('onnxruntime'):
        try:
            import onnxruntime as ort
            eps=list(ort.get_available_providers())
            if 'CUDAExecutionProvider' in eps: out.append(ModelRuntime('onnx-cuda',True,'ONNX Runtime CUDA EP'))
            if 'TensorrtExecutionProvider' in eps: out.append(ModelRuntime('tensorrt',True,'ONNX Runtime TensorRT EP'))
            # Current ONNX Runtime uses MIGraphX for AMD; ROCm EP was removed in 1.23.
            if 'MIGraphXExecutionProvider' in eps: out.append(ModelRuntime('migraphx',True,'ONNX Runtime MIGraphX EP'))
        except Exception as e:
            out.append(ModelRuntime('onnxruntime',False,f'probe_failed:{type(e).__name__}'))
    else:
        out.append(ModelRuntime('onnxruntime',False,'not_installed'))
    return out
