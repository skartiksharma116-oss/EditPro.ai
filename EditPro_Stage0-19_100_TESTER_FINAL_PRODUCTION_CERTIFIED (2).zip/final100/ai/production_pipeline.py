from __future__ import annotations
from .analyzer import VideoUnderstandingEngine
from .director import EditingDirector
from .speech import SpeechWorker
from .vision import inspect_media, sample_visuals
from .runtime import runtime_info
from .cloud import CloudWorker

class ProductionStage2:
    def __init__(self,speech=None,cloud=None):
        self.analyzer=VideoUnderstandingEngine(); self.director=EditingDirector(); self.speech=speech or SpeechWorker(); self.cloud=cloud or CloudWorker(); self._runtime=runtime_info()
    def run(self,path,style='balanced'):
        media=inspect_media(path); visual=sample_visuals(path)
        speech=self.speech.transcribe(path) if media.get('audio') else None
        return self.run_from_signals(media, visual, speech, style)
    def run_from_signals(self,media,visual=None,speech=None,style='balanced'):
        visual=visual or []
        transcript=speech.transcript if speech else []
        result=self.analyzer.analyze(media,transcript,[])
        plan=self.director.plan(result,style)
        cloud=self.cloud.run({'media':media,'moments':result.moments,'style':style})
        return {'media':media,'visual_samples':visual,'speech':speech.__dict__ if speech else None,'runtime':self._runtime,'video_map':result,'edit_plan':plan,'cloud':cloud.__dict__}
