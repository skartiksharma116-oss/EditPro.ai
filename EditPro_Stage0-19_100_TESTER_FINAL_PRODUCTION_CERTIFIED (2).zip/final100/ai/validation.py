import math


def finite_number(value, name, default=0.0, minimum=None, maximum=None):
    try:
        x = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(x):
        return default
    if minimum is not None and x < minimum:
        return default
    if maximum is not None and x > maximum:
        return default
    return x


def clean_meta(meta):
    meta = meta if isinstance(meta, dict) else {}
    return {
        'duration': finite_number(meta.get('duration'), 'duration', 0.0, 0.0),
        'fps': finite_number(meta.get('fps'), 'fps', 0.0, 0.0, 1000.0),
        'width': int(finite_number(meta.get('width'), 'width', 0.0, 0.0, 100000.0)),
        'height': int(finite_number(meta.get('height'), 'height', 0.0, 0.0, 100000.0)),
    }


def clean_interval(start, end, duration):
    s = finite_number(start, 'start', 0.0, 0.0)
    e = finite_number(end, 'end', s, 0.0)
    s = min(s, duration)
    e = min(max(e, s), duration)
    return s, e
