"""Real media inspection and decoder-independent visual sampling via FFmpeg."""
from __future__ import annotations
import json, subprocess, tempfile, os, math
from pathlib import Path

def inspect_media(path):
    r=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)],capture_output=True,text=True,timeout=5)
    if r.returncode: raise RuntimeError('ffprobe_failed')
    x=json.loads(r.stdout); streams=x.get('streams',[]); video=next((s for s in streams if s.get('codec_type')=='video'),None)
    if not video: raise ValueError('no_video_stream')
    a,b=map(float,str(video.get('r_frame_rate','0/1')).split('/'))
    fps=a/b if b else 0
    duration=float(video.get('duration') or x.get('format',{}).get('duration') or 0)
    if not all(math.isfinite(v) for v in (fps,duration)) or fps <= 0 or duration <= 0:
        raise ValueError('invalid_media_timing')
    if int(video.get('width') or 0) <= 0 or int(video.get('height') or 0) <= 0:
        raise ValueError('invalid_video_dimensions')
    return {'width':int(video.get('width') or 0),'height':int(video.get('height') or 0),'fps':fps,'duration':duration,'codec':video.get('codec_name'),'pix_fmt':video.get('pix_fmt'),'format':x.get('format',{}).get('format_name'),'audio':any(s.get('codec_type')=='audio' for s in streams)}

def sample_visuals(path, samples=6):
    """Decode representative frames through FFmpeg software decode, avoiding OpenCV hardware-decoder surprises."""
    try:
        m=inspect_media(path); duration=max(0.001,m['duration']); out=[]
        import cv2, numpy as np
        for i in range(max(1,samples)):
            t=duration*i/max(1,samples-1)
            cmd=['ffmpeg','-hide_banner','-loglevel','error','-ss',str(t),'-i',str(path),'-frames:v','1','-f','image2pipe','-vcodec','png','-']
            r=subprocess.run(cmd,capture_output=True,timeout=30)
            if r.returncode or not r.stdout: continue
            arr=np.frombuffer(r.stdout,dtype=np.uint8); frame=cv2.imdecode(arr,cv2.IMREAD_GRAYSCALE)
            if frame is None: continue
            out.append({'time':float(t),'mean_luma':float(frame.mean()),'contrast_proxy':float(frame.std())})
        return out or [{'warning':'video_decode_unavailable','codec':m.get('codec')}]
    except Exception as e:
        return [{'warning':type(e).__name__}]
