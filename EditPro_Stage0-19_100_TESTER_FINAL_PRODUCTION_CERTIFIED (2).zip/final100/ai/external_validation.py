"""Production-shaped external validation alternatives.

These adapters validate the same contracts used by real cloud GPU/AI/device services.
They never pretend local mocks are physical hardware; identity is explicit in results.
"""
from __future__ import annotations
import json, time
from dataclasses import dataclass
from typing import Any, Callable

@dataclass(frozen=True)
class ExternalResult:
    ok: bool
    provider: str
    execution: str
    data: dict
    error: str|None=None
    elapsed_ms: float=0.0

class ContractBackend:
    def __init__(self, provider: str, execution: str, fn: Callable[[dict], dict]):
        self.provider=provider; self.execution=execution; self.fn=fn
    def run(self, payload: dict) -> ExternalResult:
        t=time.perf_counter()
        try:
            if not isinstance(payload,dict): raise TypeError('payload_must_be_dict')
            out=self.fn(payload)
            if not isinstance(out,dict): raise TypeError('invalid_result_shape')
            return ExternalResult(True,self.provider,self.execution,out,elapsed_ms=(time.perf_counter()-t)*1000)
        except Exception as e:
            return ExternalResult(False,self.provider,self.execution,{},type(e).__name__,(time.perf_counter()-t)*1000)

class GPUContractLab:
    """Runs the GPU worker contract against deterministic local backends.
    Real cloud execution is a separate deployment step and is never mislabeled as local.
    """
    @staticmethod
    def nvidia():
        return ContractBackend('nvidia-cuda','contract-lab',lambda p:{'backend':'cuda','device':'contract-lab','ok':True,'job':p.get('job','')})
    @staticmethod
    def amd():
        return ContractBackend('amd-rocm','contract-lab',lambda p:{'backend':'rocm','device':'contract-lab','ok':True,'job':p.get('job','')})

class CloudAILab:
    @staticmethod
    def healthy():
        return ContractBackend('cloud-ai','contract-lab',lambda p:{'decision':'balanced','confidence':0.99,'request_id':str(p.get('request_id','lab'))})
    @staticmethod
    def malformed():
        return ContractBackend('cloud-ai','fault-lab',lambda p: ['bad'])
    @staticmethod
    def failing():
        def fail(p): raise TimeoutError('simulated_timeout')
        return ContractBackend('cloud-ai','fault-lab',fail)

class DeviceFarmLab:
    @staticmethod
    def run(platform: str, device: str, payload: dict) -> ExternalResult:
        t=time.perf_counter()
        if platform not in {'android','ios','web'}: return ExternalResult(False,'device-farm','contract-lab',{},'unsupported_platform',(time.perf_counter()-t)*1000)
        if not device: return ExternalResult(False,'device-farm','contract-lab',{},'missing_device',(time.perf_counter()-t)*1000)
        return ExternalResult(True,'device-farm','contract-lab',{'platform':platform,'device':device,'test':'pass'},elapsed_ms=(time.perf_counter()-t)*1000)
