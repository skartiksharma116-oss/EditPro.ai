from __future__ import annotations
from dataclasses import dataclass
from .validation import clean_interval

@dataclass
class LocalSpeechResult:
    provider: str
    transcript: list
    language: str|None
    warnings: list

class LocalSpeechWorker:
    """Optional local Whisper/faster-whisper adapter. It never claims a model ran unless import+inference succeeds."""
    def __init__(self, model='small'):
        self.model_name=model; self._model=None
    def _load(self):
        if self._model is not None: return self._model
        try:
            from faster_whisper import WhisperModel
        except Exception as e:
            raise RuntimeError('faster_whisper_not_installed') from e
        self._model=WhisperModel(self.model_name, device='auto', compute_type='auto')
        return self._model
    def transcribe(self,path):
        model=self._load(); segments,info=model.transcribe(str(path))
        tx=[]
        for seg in segments:
            s,e=clean_interval(getattr(seg,'start',0),getattr(seg,'end',0),1e12)
            text=str(getattr(seg,'text','')).strip()
            if text and e>s: tx.append({'text':text,'start':s,'end':e})
        return LocalSpeechResult('faster-whisper',tx,getattr(info,'language',None),[])
