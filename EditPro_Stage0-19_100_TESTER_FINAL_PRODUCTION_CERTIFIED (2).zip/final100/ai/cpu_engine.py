"""High-reliability CPU execution engine for EditPro Stage 2.
No fake acceleration: this module measures the host and uses bounded parallel work.
"""
from __future__ import annotations
import concurrent.futures, hashlib, math, os, platform, threading, time
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class CPUInfo:
    available: bool
    logical_cores: int
    physical_cores: int
    memory_bytes: int
    python: str
    machine: str
    max_workers: int


def _memory_bytes() -> int:
    try:
        import psutil
        return int(psutil.virtual_memory().total)
    except Exception:
        try:
            pages = os.sysconf('SC_PHYS_PAGES'); size = os.sysconf('SC_PAGE_SIZE')
            return int(pages * size)
        except Exception:
            return 0


def cpu_info(reserve_cores: int = 1) -> CPUInfo:
    logical = max(1, os.cpu_count() or 1)
    physical = logical
    try:
        import psutil
        physical = max(1, psutil.cpu_count(logical=False) or logical)
    except Exception:
        pass
    reserve = max(0, int(reserve_cores))
    workers = max(1, min(logical, physical * 2) - reserve)
    return CPUInfo(True, logical, physical, _memory_bytes(), platform.python_version(), platform.machine(), workers)


def _work(item):
    # Deterministic CPU-bound signal extraction surrogate. Production models can replace it.
    b = str(item).encode('utf-8', 'replace')
    digest = hashlib.sha256(b).digest()
    return {'key': digest.hex(), 'score': int.from_bytes(digest[:4], 'big') / 2**32}


class CPUWorker:
    name = 'cpu-optimized'
    def __init__(self, max_workers=None, reserve_cores=1, max_inflight=32):
        info = cpu_info(reserve_cores)
        self.info = info
        self.max_workers = max(1, min(int(max_workers or info.max_workers), info.logical_cores))
        self.max_inflight = max(1, int(max_inflight))
        self._executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers, thread_name_prefix='editpro-cpu')
        self._closed = False
        self._lock = threading.Lock()
        self._completed = 0
        self._failed = 0

    def health(self):
        return {'worker': self.name, 'backend': 'cpu', 'available': not self._closed,
                'devices': 0, 'logical_cores': self.info.logical_cores,
                'physical_cores': self.info.physical_cores, 'max_workers': self.max_workers,
                'memory_bytes': self.info.memory_bytes, 'completed': self._completed,
                'failed': self._failed}

    def map(self, items, timeout=None):
        if self._closed: raise RuntimeError('cpu_worker_closed')
        seq = list(items)
        if len(seq) > self.max_inflight:
            # Chunking bounds memory and queued work.
            out=[]
            for i in range(0, len(seq), self.max_inflight):
                out.extend(self.map(seq[i:i+self.max_inflight], timeout))
            return out
        futures=[self._executor.submit(_work, x) for x in seq]
        results=[]
        try:
            for f in futures:
                results.append(f.result(timeout=timeout))
                with self._lock: self._completed += 1
        except Exception:
            with self._lock: self._failed += 1
            for f in futures: f.cancel()
            raise
        return results

    def run(self, task):
        started=time.perf_counter()
        items = task.get('items', []) if isinstance(task, dict) else []
        if not isinstance(items, list): raise TypeError('task.items must be a list')
        if len(items) > 100000: raise ValueError('task_too_large')
        result=self.map(items, timeout=task.get('timeout'))
        return {'status':'ok','backend':'cpu','items':len(result),
                'elapsed_ms':round((time.perf_counter()-started)*1000,3),'results':result}

    def close(self):
        if not self._closed:
            self._closed=True; self._executor.shutdown(wait=True, cancel_futures=True)
