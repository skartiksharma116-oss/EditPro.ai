"""Runtime abstraction for CPU, CUDA GPU, and cloud workers."""
from __future__ import annotations
import os, shutil
from .cpu_engine import cpu_info

def runtime_info():
    ci=cpu_info()
    info={'ffmpeg':bool(shutil.which('ffmpeg')),'ffprobe':bool(shutil.which('ffprobe')),'nvidia_smi':bool(shutil.which('nvidia-smi')),'device':'cpu','cpu':ci.__dict__}
    try:
        import torch
        info['torch']=torch.__version__; info['cuda_available']=bool(torch.cuda.is_available())
        if info['cuda_available']: info['device']='cuda'; info['gpu_count']=torch.cuda.device_count()
    except Exception: info['torch']=None; info['cuda_available']=False
    info['cloud_enabled']=bool(os.getenv('CLOUD_AI_URL'))
    return info
