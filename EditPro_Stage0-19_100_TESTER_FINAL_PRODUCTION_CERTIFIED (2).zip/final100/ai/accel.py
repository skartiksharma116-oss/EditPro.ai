from __future__ import annotations
import shutil, subprocess
from functools import lru_cache

def _run(cmd):
    try:
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=5)
        return p.returncode==0, (p.stdout or '')+(p.stderr or '')
    except Exception:
        return False,''

@lru_cache(maxsize=1)
def detect_accelerators():
    out=[]
    ok,text=_run(['rocminfo']) if shutil.which('rocminfo') else (False,'')
    if ok and 'gfx' in text.lower(): out.append('rocm')
    ok,_=_run(['sycl-ls']) if shutil.which('sycl-ls') else (False,'')
    if ok: out.append('oneapi')
    if shutil.which('nvidia-smi'):
        ok,_=_run(['nvidia-smi','-L'])
        if ok: out.append('cuda')
    return out
