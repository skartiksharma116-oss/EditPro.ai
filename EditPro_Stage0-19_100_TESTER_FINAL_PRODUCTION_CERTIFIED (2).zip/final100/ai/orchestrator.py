from .analyzer import VideoUnderstandingEngine
from .director import EditingDirector

class Stage2Pipeline:
    def __init__(self, analyzer=None, director=None):
        self.analyzer = analyzer or VideoUnderstandingEngine()
        self.director = director or EditingDirector()

    def run(self, meta, transcript=None, scenes=None, style='balanced'):
        video_map = self.analyzer.analyze(meta, transcript, scenes)
        plan = self.director.plan(video_map, style)
        self._validate(video_map, plan)
        return {'video_map': video_map, 'edit_plan': plan}

    @staticmethod
    def _validate(video_map, plan):
        if not plan.get('safety', {}).get('source_preserved') or plan.get('safety', {}).get('destructive'):
            raise ValueError('Non-destructive source guarantee failed')
        duration = video_map.duration
        for action in plan.get('actions', []):
            s, e = float(action['start']), float(action['end'])
            if not (0 <= s <= e <= duration + 1e-9):
                raise ValueError('Edit action is outside media bounds')
