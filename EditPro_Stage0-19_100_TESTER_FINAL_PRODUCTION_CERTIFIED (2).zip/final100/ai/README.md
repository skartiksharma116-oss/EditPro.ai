# Stage 2: AI Video Brain
Video Understanding Engine + non-destructive AI Editing Director.
Pipeline: media -> signals -> understanding map -> edit plan.
Production model adapters can plug into these interfaces.
