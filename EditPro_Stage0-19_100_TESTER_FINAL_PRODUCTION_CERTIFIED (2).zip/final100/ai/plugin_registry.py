"""Stage 2 plugin/provider registry and conformance checks.
Plugins are explicit, named contracts. Unknown/malformed plugins are rejected safely.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable

@dataclass(frozen=True)
class PluginSpec:
    name: str
    version: str
    kind: str
    run: Callable[[dict], dict]

class PluginRegistry:
    def __init__(self):
        self._plugins = {}
    def register(self, spec: PluginSpec):
        if not isinstance(spec, PluginSpec) or not spec.name or not spec.version or not spec.kind or not callable(spec.run):
            raise ValueError('invalid_plugin_spec')
        key=(spec.kind,spec.name)
        if key in self._plugins:
            raise ValueError('duplicate_plugin')
        self._plugins[key]=spec
    def get(self, kind, name):
        return self._plugins.get((kind,name))
    def list(self):
        return [dict(name=s.name,version=s.version,kind=s.kind) for s in self._plugins.values()]
    def run(self, kind, name, payload):
        spec=self.get(kind,name)
        if not spec: raise KeyError('plugin_not_found')
        if not isinstance(payload,dict): raise TypeError('plugin_payload_must_be_dict')
        result=spec.run(payload)
        if not isinstance(result,dict): raise TypeError('plugin_invalid_result')
        return result
