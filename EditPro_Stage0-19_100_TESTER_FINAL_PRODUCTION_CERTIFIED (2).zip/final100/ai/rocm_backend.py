import os, shutil, subprocess
from dataclasses import dataclass

@dataclass
class GPUInfo:
    backend:str
    available:bool
    device_count:int=0
    detail:str=''

def detect():
    # Never assume hardware. Detect real ROCm only when the host provides it.
    rocminfo=shutil.which('rocminfo')
    if rocminfo:
        try:
            p=subprocess.run([rocminfo],capture_output=True,text=True,timeout=10)
            if p.returncode==0:
                n=max(0,p.stdout.count('Name:                    gfx'))
                return GPUInfo('rocm',True,max(1,n),'ROCm runtime detected')
        except Exception as e:
            return GPUInfo('cpu',False,0,f'ROCm detection failed: {e}')
    return GPUInfo('cpu',False,0,'No ROCm runtime detected; safe CPU fallback')

def choose(preferred=None):
    info=detect()
    if preferred=='rocm' and info.available: return info
    return info
