"""Retrying cloud worker with timeout and circuit breaker."""
from __future__ import annotations
import json, os, time, urllib.request
from dataclasses import dataclass

@dataclass
class CloudResult:
    ok: bool; data: dict; attempts: int; error: str|None=None

class CloudWorker:
    def __init__(self, endpoint=None, api_key=None, timeout=5, retries=2, breaker_limit=3):
        self.endpoint=endpoint or os.getenv('CLOUD_AI_URL'); self.api_key=api_key or os.getenv('CLOUD_AI_KEY')
        self.timeout=timeout; self.retries=retries; self.breaker_limit=breaker_limit; self.failures=0
    def run(self,payload):
        if not self.endpoint: return CloudResult(False,{},0,'cloud_not_configured')
        if self.failures>=self.breaker_limit: return CloudResult(False,{},0,'circuit_open')
        attempts=0; last='unknown'
        call_failed=False
        for _ in range(self.retries+1):
            attempts+=1
            try:
                body=json.dumps(payload).encode(); req=urllib.request.Request(self.endpoint,data=body,headers={'Content-Type':'application/json','Authorization':f'Bearer {self.api_key}' if self.api_key else ''})
                with urllib.request.urlopen(req,timeout=self.timeout) as resp: data=json.loads(resp.read().decode())
                if not isinstance(data,dict): raise ValueError('cloud_invalid_shape')
                self.failures=0; return CloudResult(True,data,attempts)
            except Exception as e:
                last=type(e).__name__; call_failed=True; time.sleep(min(.05*attempts,.2))
        if call_failed: self.failures += 1
        return CloudResult(False,{},attempts,last)
