## CPU fallback

Stage 2 includes `ai/cpu_engine.py`, a bounded parallel CPU worker used whenever a real accelerator is unavailable. It detects the host, reserves capacity for responsiveness, chunks large workloads, rejects oversized tasks, and supports deterministic replay and clean shutdown.

The scheduler in `infra/worker_scheduler.py` only selects ROCm after real runtime detection; otherwise it dispatches to the optimized CPU worker.
