# EditPro Stage 0–19 Production Hardening Patch

Status: FINAL PRODUCTION HARDENING PASS

This is a maintenance hardening patch inside the final Stage 19 release. It does not create a new feature stage.

## Deployment bugs / weaknesses addressed

1. **Unsafe media could reach the expensive real-media pipeline before strong validation.**
   - Real-media `run()` now validates the input through the Stage 19 production media guard before Stage 2 processing.

2. **File validation accepted a broad class of non-media or unsafe files.**
   - Added regular-file checks, symlink rejection, null-byte rejection, traversal protection, extension allow-list, 50 GiB input ceiling, streamed SHA-256 hashing.

3. **A file could pass hashing while still being an invalid media stream.**
   - Added optional `ffprobe` container/codec parse validation with an explicit unavailable state when the parser is not installed.

4. **Workspace path traversal risk.**
   - Added a resolved-path containment guard that refuses paths escaping the project workspace.

5. **Crash-prone metadata/project writes.**
   - Added atomic JSON writes using a same-directory temporary file, flush/fsync, and atomic replace.

6. **Deployment readiness was not exposed as a single health check.**
   - Added a production health probe covering registry integrity, required media tools, and security-standard presence.

7. **Release metadata was still labeled 19.0-final after hardening.**
   - Updated Stage 19 runtime version to `19.1-final-production-hardening` while keeping Stage 19 as the final feature stage.

## Verification

- Existing regression suite: **81/81 PASS**
- Final production certification: **PASS**
- Every registered capability: **511,000 independent checks** (511 × 1,000)
- Family checks: **28,000**
- Full Stage 0→19 integration checks: **1,000**
- Security adversarial cycles: **50,000**
- Deterministic replay: **10,000**
- Real 4K MP4/WAV/PNG validation: **PASS**
- Real 4K MP4 through Stage 0→19: **PASS**
- Production hardening tests: **PASS**
- Python compile: **PASS**
- Release gate: **FINAL_CERTIFICATION_PASS**

## Boundary

No software process can honestly pre-fix unknown future defects that have not yet occurred, nor certify arbitrary third-party hardware, proprietary codecs/plugins, external AI providers, or every possible OS configuration without testing those environments. This patch therefore closes the deployment-risk classes discoverable in the current codebase and adds guards so future invalid inputs fail safely rather than silently corrupting the project.

Stage 19 remains the final feature stage. Future work is limited to ordinary maintenance: bug fixes, security patches, dependency updates, and environment-specific compatibility fixes.
